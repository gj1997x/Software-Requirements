package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Order implements Serializable {
	
	/* all primary attributes */
	private String OrderID;
	private LocalDate DateOfPurchase;
	private float TotalPrice;
	private List<Product> ProductsList;
	
	/* all references */
	private Customer MadeBY; 
	private List<Product> Accomedate = new LinkedList<Product>(); 
	private Cashier CheckOut; 
	private Cart HasIn; 
	
	/* all get and set functions */
	public String getOrderID() {
		return OrderID;
	}	
	
	public void setOrderID(String orderid) {
		this.OrderID = orderid;
	}
	public LocalDate getDateOfPurchase() {
		return DateOfPurchase;
	}	
	
	public void setDateOfPurchase(LocalDate dateofpurchase) {
		this.DateOfPurchase = dateofpurchase;
	}
	public float getTotalPrice() {
		return TotalPrice;
	}	
	
	public void setTotalPrice(float totalprice) {
		this.TotalPrice = totalprice;
	}
	public List<Product> getProductsList() {
		return ProductsList;
	}	
	
	public void setProductsList(List<Product> productslist) {
		this.ProductsList = productslist;
	}
	
	/* all functions for reference*/
	public Customer getMadeBY() {
		return MadeBY;
	}	
	
	public void setMadeBY(Customer customer) {
		this.MadeBY = customer;
	}			
	public List<Product> getAccomedate() {
		return Accomedate;
	}	
	
	public void addAccomedate(Product product) {
		this.Accomedate.add(product);
	}
	
	public void deleteAccomedate(Product product) {
		this.Accomedate.remove(product);
	}
	public Cashier getCheckOut() {
		return CheckOut;
	}	
	
	public void setCheckOut(Cashier cashier) {
		this.CheckOut = cashier;
	}			
	public Cart getHasIn() {
		return HasIn;
	}	
	
	public void setHasIn(Cart cart) {
		this.HasIn = cart;
	}			
	


}
