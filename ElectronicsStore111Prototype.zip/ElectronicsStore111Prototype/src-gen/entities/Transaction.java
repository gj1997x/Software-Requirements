package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Transaction implements Serializable {
	
	/* all primary attributes */
	private String TransactionID;
	private float Amount;
	private String PaymentMethod;
	private String OrderID;
	
	/* all references */
	private Cashier ProcessedBy; 
	private Customer CanProcess; 
	private Receipt ProvidedWithin; 
	
	/* all get and set functions */
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String transactionid) {
		this.TransactionID = transactionid;
	}
	public float getAmount() {
		return Amount;
	}	
	
	public void setAmount(float amount) {
		this.Amount = amount;
	}
	public String getPaymentMethod() {
		return PaymentMethod;
	}	
	
	public void setPaymentMethod(String paymentmethod) {
		this.PaymentMethod = paymentmethod;
	}
	public String getOrderID() {
		return OrderID;
	}	
	
	public void setOrderID(String orderid) {
		this.OrderID = orderid;
	}
	
	/* all functions for reference*/
	public Cashier getProcessedBy() {
		return ProcessedBy;
	}	
	
	public void setProcessedBy(Cashier cashier) {
		this.ProcessedBy = cashier;
	}			
	public Customer getCanProcess() {
		return CanProcess;
	}	
	
	public void setCanProcess(Customer customer) {
		this.CanProcess = customer;
	}			
	public Receipt getProvidedWithin() {
		return ProvidedWithin;
	}	
	
	public void setProvidedWithin(Receipt receipt) {
		this.ProvidedWithin = receipt;
	}			
	


}
