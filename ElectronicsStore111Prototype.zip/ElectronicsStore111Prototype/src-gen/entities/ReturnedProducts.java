package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class ReturnedProducts implements Serializable {
	
	/* all primary attributes */
	private String ReturnID;
	private String CustomerID;
	private String ReasonOfReturn;
	private String TransactionID;
	private String ProductID;
	
	/* all references */
	private List<Customer> CanReturn = new LinkedList<Customer>(); 
	
	/* all get and set functions */
	public String getReturnID() {
		return ReturnID;
	}	
	
	public void setReturnID(String returnid) {
		this.ReturnID = returnid;
	}
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getReasonOfReturn() {
		return ReasonOfReturn;
	}	
	
	public void setReasonOfReturn(String reasonofreturn) {
		this.ReasonOfReturn = reasonofreturn;
	}
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String transactionid) {
		this.TransactionID = transactionid;
	}
	
	/* all functions for reference*/
	public List<Customer> getCanReturn() {
		return CanReturn;
	}	
	
	public void addCanReturn(Customer customer) {
		this.CanReturn.add(customer);
	}
	
	public void deleteCanReturn(Customer customer) {
		this.CanReturn.remove(customer);
	}

	public void setProductID(String productID) {
		// TODO Auto-generated method stub
		this.ProductID = productID;
	}
	public String getProductID() {
		return ProductID;
	}
	


}
