package entities;

public class ThirdPartyServiceException extends Exception {

	public ThirdPartyServiceException() {
		// TODO Auto-generated constructor stub
	}
 
	public ThirdPartyServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ThirdPartyServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ThirdPartyServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ThirdPartyServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
