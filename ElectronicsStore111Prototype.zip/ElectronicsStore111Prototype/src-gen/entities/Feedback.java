package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Feedback implements Serializable {
	
	/* all primary attributes */
	private String FeedbackID;
	private String FeedbackContent;
	private String CustomerID;
	
	/* all references */
	private StoreManager Accesses; 
	private List<Customer> Provide = new LinkedList<Customer>(); 
	
	/* all get and set functions */
	public String getFeedbackID() {
		return FeedbackID;
	}	
	
	public void setFeedbackID(String feedbackid) {
		this.FeedbackID = feedbackid;
	}
	public String getFeedbackContent() {
		return FeedbackContent;
	}	
	
	public void setFeedbackContent(String feedbackcontent) {
		this.FeedbackContent = feedbackcontent;
	}
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	
	/* all functions for reference*/
	public StoreManager getAccesses() {
		return Accesses;
	}	
	
	public void setAccesses(StoreManager storemanager) {
		this.Accesses = storemanager;
	}			
	public List<Customer> getProvide() {
		return Provide;
	}	
	
	public void addProvide(Customer customer) {
		this.Provide.add(customer);
	}
	
	public void deleteProvide(Customer customer) {
		this.Provide.remove(customer);
	}
	


}
