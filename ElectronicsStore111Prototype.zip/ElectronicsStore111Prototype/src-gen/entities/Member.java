package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Member implements Serializable {
	
	/* all primary attributes */
	private String MemberID;
	private String FullName;
	private String Tier;
	private int LoyaltyPoints;
	
	/* all references */
	private Customer Is; 
	private Users BelongTo; 
	
	/* all get and set functions */
	public String getMemberID() {
		return MemberID;
	}	
	
	public void setMemberID(String memberid) {
		this.MemberID = memberid;
	}
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public String getTier() {
		return Tier;
	}	
	
	public void setTier(String tier) {
		this.Tier = tier;
	}
	public int getLoyaltyPoints() {
		return LoyaltyPoints;
	}	
	
	public void setLoyaltyPoints(int loyaltypoints) {
		this.LoyaltyPoints = loyaltypoints;
	}
	
	/* all functions for reference*/
	public Customer getIs() {
		return Is;
	}	
	
	public void setIs(Customer customer) {
		this.Is = customer;
	}			
	public Users getBelongTo() {
		return BelongTo;
	}	
	
	public void setBelongTo(Users users) {
		this.BelongTo = users;
	}			
	


}
