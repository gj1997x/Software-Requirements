package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Users implements Serializable {
	
	/* all primary attributes */
	private String UserID;
	private String UserName;
	private String Password;
	
	/* all references */
	private StoreManager CanBe; 
	private Supplier IsA; 
	private Cashier Represents; 
	private Customer RelatedTo; 
	private Member MustBeAlso; 
	
	/* all get and set functions */
	public String getUserID() {
		return UserID;
	}	
	
	public void setUserID(String userid) {
		this.UserID = userid;
	}
	public String getUserName() {
		return UserName;
	}	
	
	public void setUserName(String username) {
		this.UserName = username;
	}
	public String getPassword() {
		return Password;
	}	
	
	public void setPassword(String password) {
		this.Password = password;
	}
	
	/* all functions for reference*/
	public StoreManager getCanBe() {
		return CanBe;
	}	
	
	public void setCanBe(StoreManager storemanager) {
		this.CanBe = storemanager;
	}			
	public Supplier getIsA() {
		return IsA;
	}	
	
	public void setIsA(Supplier supplier) {
		this.IsA = supplier;
	}			
	public Cashier getRepresents() {
		return Represents;
	}	
	
	public void setRepresents(Cashier cashier) {
		this.Represents = cashier;
	}			
	public Customer getRelatedTo() {
		return RelatedTo;
	}	
	
	public void setRelatedTo(Customer customer) {
		this.RelatedTo = customer;
	}			
	public Member getMustBeAlso() {
		return MustBeAlso;
	}	
	
	public void setMustBeAlso(Member member) {
		this.MustBeAlso = member;
	}			
	


}
