package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Supplier implements Serializable {
	
	/* all primary attributes */
	private String SupplierID;
	private String CompanyName;
	private String ContactDetails;
	private String SupplierOrderID;
	private String Status;
	private List<Product> ProductsList;
	
	/* all references */
	private List<SupplierOrder> FulfilledBy = new LinkedList<SupplierOrder>(); 
	private Users MayBe; 
	
	/* all get and set functions */
	public String getSupplierID() {
		return SupplierID;
	}	
	
	public void setSupplierID(String supplierid) {
		this.SupplierID = supplierid;
	}
	public String getCompanyName() {
		return CompanyName;
	}	
	
	public void setCompanyName(String companyname) {
		this.CompanyName = companyname;
	}
	public String getContactDetails() {
		return ContactDetails;
	}	
	
	public void setContactDetails(String contactdetails) {
		this.ContactDetails = contactdetails;
	}
	
	/* all functions for reference*/
	public List<SupplierOrder> getFulfilledBy() {
		return FulfilledBy;
	}	
	
	public void addFulfilledBy(SupplierOrder supplierorder) {
		this.FulfilledBy.add(supplierorder);
	}
	
	public void deleteFulfilledBy(SupplierOrder supplierorder) {
		this.FulfilledBy.remove(supplierorder);
	}
	public Users getMayBe() {
		return MayBe;
	}	
	public void setMayBe(Users users) {
		this.MayBe = users;
	}

	public void setSupplierOrderID(String supplierOrderID) {
		// TODO Auto-generated method stub
		this.SupplierOrderID = supplierOrderID;
	}
		
	public List<Product> getProductsList() {
		return ProductsList;
	}	
	
	public void setProductsList(Product p) {
		this.ProductsList.add(p);
	}


	public void setStatus(String string) {
		// TODO Auto-generated method stub
		this.Status = string;
	}
	public String getSupplierOrderID() {
		return SupplierOrderID;
	}
	
	public String getStatus() {
		return Status;
	}


}
