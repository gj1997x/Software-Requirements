package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class StoreManager implements Serializable {
	
	/* all primary attributes */
	private String StoreManagerID;
	private String FullName;
	private String Branch;
	
	/* all references */
	private Inventory Manages; 
	private List<Feedback> Accessed = new LinkedList<Feedback>(); 
	private Users Is; 
	private List<Report> GeneratedBy = new LinkedList<Report>(); 
	private RestockProducts DoneBy; 
	
	/* all get and set functions */
	public String getStoreManagerID() {
		return StoreManagerID;
	}	
	
	public void setStoreManagerID(String storemanagerid) {
		this.StoreManagerID = storemanagerid;
	}
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public String getBranch() {
		return Branch;
	}	
	
	public void setBranch(String branch) {
		this.Branch = branch;
	}
	
	/* all functions for reference*/
	public Inventory getManages() {
		return Manages;
	}	
	
	public void setManages(Inventory inventory) {
		this.Manages = inventory;
	}			
	public List<Feedback> getAccessed() {
		return Accessed;
	}	
	
	public void addAccessed(Feedback feedback) {
		this.Accessed.add(feedback);
	}
	
	public void deleteAccessed(Feedback feedback) {
		this.Accessed.remove(feedback);
	}
	public Users getIs() {
		return Is;
	}	
	
	public void setIs(Users users) {
		this.Is = users;
	}			
	public List<Report> getGeneratedBy() {
		return GeneratedBy;
	}	
	
	public void addGeneratedBy(Report report) {
		this.GeneratedBy.add(report);
	}
	
	public void deleteGeneratedBy(Report report) {
		this.GeneratedBy.remove(report);
	}
	public RestockProducts getDoneBy() {
		return DoneBy;
	}	
	
	public void setDoneBy(RestockProducts restockproducts) {
		this.DoneBy = restockproducts;
	}			
	


}
