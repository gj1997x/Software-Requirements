package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Product implements Serializable {
	
	
	/* all primary attributes */
	public static String ProductID;
	private String ProductName;
	private float Price;
	private int StockLevel;
	
	/* all references */
	private Order In; 
	private Inventory StoredIn; 
	
	/* all get and set functions */
	public String getProductID() {
		return ProductID;
	}	
	
	public void setProductID(String productid) {
		this.ProductID = productid;
	}
	public String getProductName() {
		return ProductName;
	}	
	
	public void setProductName(String productname) {
		this.ProductName = productname;
	}
	public float getPrice() {
		return Price;
	}	
	
	public void setPrice(float price) {
		this.Price = price;
	}
	public int getStockLevel() {
		return StockLevel;
	}	
	
	public void setStockLevel(int stocklevel) {
		this.StockLevel = stocklevel;
	}
	
	/* all functions for reference*/
	public Order getIn() {
		return In;
	}	
	
	public void setIn(Order order) {
		this.In = order;
	}			
	public Inventory getStoredIn() {
		return StoredIn;
	}	
	
	public void setStoredIn(Inventory inventory) {
		this.StoredIn = inventory;
	}			
	


}
