package entities;


import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Cart implements Serializable {
	
	/* all primary attributes */
	private String CartID;
	public List<Product> ProductList;
	private float TotalAmount;
	private String CustomerID;
	private String OrderID;
	private int Quantity;
	
	/* all references */
	private Order IsIn; 
	
	/* all get and set functions */
	public String getCartID() {
		return CartID;
	}	
	
	public void setCartID(String cartid) {
		this.CartID = cartid;
	}
	public List<Product> getProductList() {
		return ProductList;
	}	
	
	public void setProductList(Product p) {
		this.ProductList.add(p);
	}
	public float getTotalAmount() {
		return TotalAmount;
	}	
	
	public void setTotalAmount(float totalamount) {
		this.TotalAmount = totalamount;
	}
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getOrderID() {
		return OrderID;
	}	
	
	public void setOrderID(String orderid) {
		this.OrderID = orderid;
	}
	
	/* all functions for reference*/
	public Order getIsIn() {
		return IsIn;
	}	
	
	public void setIsIn(Order order) {
		this.IsIn = order;
	}			
	public String getProductID(String productID) {
		
	
		Product ca = null;
		//no nested iterator --  iterator: any previous:any
		for (Product cart : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (Product.ProductID==productID)
			{
				break;
			}
				
			
		}
		return productID;
	}

	public void setQuantity(String quantity2) {
		// TODO Auto-generated method stub
		this.Quantity = Integer.parseInt(quantity2);
	}

	public String getQuantity() {
		// TODO Auto-generated method stub
		return String.valueOf(Quantity);
	}
	


}
