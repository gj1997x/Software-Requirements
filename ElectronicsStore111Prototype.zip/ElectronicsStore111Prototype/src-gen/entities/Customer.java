package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Customer implements Serializable {
	
	/* all primary attributes */
	private String CustomerID;
	private String FullName;
	private String Address;
	private int PhoneNumber;
	private String Email;
	
	/* all references */
	private Member Becomes; 
	private Order Make; 
	private Users Are; 
	private Feedback Suggest; 
	private ReturnedProducts ReturnedBy; 
	private Transaction CanBeProcessedBy; 
	
	/* all get and set functions */
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public String getAddress() {
		return Address;
	}	
	
	public void setAddress(String address) {
		this.Address = address;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}	
	
	public void setPhoneNumber(int phonenumber) {
		this.PhoneNumber = phonenumber;
	}
	public String getEmail() {
		return Email;
	}	
	
	public void setEmail(String email) {
		this.Email = email;
	}
	
	/* all functions for reference*/
	public Member getBecomes() {
		return Becomes;
	}	
	
	public void setBecomes(Member member) {
		this.Becomes = member;
	}			
	public Order getMake() {
		return Make;
	}	
	
	public void setMake(Order order) {
		this.Make = order;
	}			
	public Users getAre() {
		return Are;
	}	
	
	public void setAre(Users users) {
		this.Are = users;
	}			
	public Feedback getSuggest() {
		return Suggest;
	}	
	
	public void setSuggest(Feedback feedback) {
		this.Suggest = feedback;
	}			
	public ReturnedProducts getReturnedBy() {
		return ReturnedBy;
	}	
	
	public void setReturnedBy(ReturnedProducts returnedproducts) {
		this.ReturnedBy = returnedproducts;
	}			
	public Transaction getCanBeProcessedBy() {
		return CanBeProcessedBy;
	}	
	
	public void setCanBeProcessedBy(Transaction transaction) {
		this.CanBeProcessedBy = transaction;
	}

	public List getCanReturn() {
		// TODO Auto-generated method stub
		return null;
	}			
	


}
