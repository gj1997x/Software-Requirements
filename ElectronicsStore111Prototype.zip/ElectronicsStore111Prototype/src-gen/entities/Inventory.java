package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Inventory implements Serializable {
	
	/* all primary attributes */
	private String InventoryID;
	private List<Product> ProductList;
	
	/* all references */
	private List<Product> Contains = new LinkedList<Product>(); 
	private StoreManager ManangedBy; 
	private List<SupplierOrder> SuppliedBy = new LinkedList<SupplierOrder>(); 
	
	/* all get and set functions */
	public String getInventoryID() {
		return InventoryID;
	}	
	
	public void setInventoryID(String inventoryid) {
		this.InventoryID = inventoryid;
	}
	public List<Product> getProductList() {
		return ProductList;
	}	
	
	public void setProductList(List<Product> productlist) {
		this.ProductList = productlist;
	}
	
	/* all functions for reference*/
	public List<Product> getContains() {
		return Contains;
	}	
	
	public void addContains(Product product) {
		this.Contains.add(product);
	}
	
	public void deleteContains(Product product) {
		this.Contains.remove(product);
	}
	public StoreManager getManangedBy() {
		return ManangedBy;
	}	
	
	public void setManangedBy(StoreManager storemanager) {
		this.ManangedBy = storemanager;
	}			
	public List<SupplierOrder> getSuppliedBy() {
		return SuppliedBy;
	}	
	
	public void addSuppliedBy(SupplierOrder supplierorder) {
		this.SuppliedBy.add(supplierorder);
	}
	
	public void deleteSuppliedBy(SupplierOrder supplierorder) {
		this.SuppliedBy.remove(supplierorder);
	}
	


}
