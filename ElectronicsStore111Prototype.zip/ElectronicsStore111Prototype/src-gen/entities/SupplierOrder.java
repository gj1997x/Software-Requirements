package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class SupplierOrder implements Serializable {
	
	/* all primary attributes */
	private String SupplierOrderID;
	private String SupplierID;
	private List<Product> ProductsList;
	private String Status;
	
	/* all references */
	private Supplier Fulfill; 
	private Inventory Supplies; 
	
	/* all get and set functions */
	public String getSupplierOrderID() {
		return SupplierOrderID;
	}	
	
	public void setSupplierOrderID(String supplierorderid) {
		this.SupplierOrderID = supplierorderid;
	}
	public String getSupplierID() {
		return SupplierID;
	}	
	
	public void setSupplierID(String supplierid) {
		this.SupplierID = supplierid;
	}
	public List<Product> getProductsList() {
		return ProductsList;
	}	
	
	public void setProductsList(Product product) {
		this.ProductsList.add(product);
	}
	public String getStatus() {
		return Status;
	}	
	
	public void setStatus(String status) {
		this.Status = status;
	}
	
	/* all functions for reference*/
	public Supplier getFulfill() {
		return Fulfill;
	}	
	
	public void setFulfill(Supplier supplier) {
		this.Fulfill = supplier;
	}			
	public Inventory getSupplies() {
		return Supplies;
	}	
	
	public void setSupplies(Inventory inventory) {
		this.Supplies = inventory;
	}			
	


}
