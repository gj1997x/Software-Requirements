package entities;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.lang.reflect.Method;
import java.util.Map;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.Serializable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.File;

public class EntityManager {

	private static Map<String, List> AllInstance = new HashMap<String, List>();
	
	private static List<Customer> CustomerInstances = new LinkedList<Customer>();
	private static List<Member> MemberInstances = new LinkedList<Member>();
	private static List<Cashier> CashierInstances = new LinkedList<Cashier>();
	private static List<StoreManager> StoreManagerInstances = new LinkedList<StoreManager>();
	private static List<Product> ProductInstances = new LinkedList<Product>();
	private static List<Supplier> SupplierInstances = new LinkedList<Supplier>();
	private static List<Inventory> InventoryInstances = new LinkedList<Inventory>();
	private static List<Order> OrderInstances = new LinkedList<Order>();
	private static List<Transaction> TransactionInstances = new LinkedList<Transaction>();
	private static List<Feedback> FeedbackInstances = new LinkedList<Feedback>();
	private static List<Receipt> ReceiptInstances = new LinkedList<Receipt>();
	private static List<SupplierOrder> SupplierOrderInstances = new LinkedList<SupplierOrder>();
	private static List<Users> UsersInstances = new LinkedList<Users>();
	private static List<Cart> CartInstances = new LinkedList<Cart>();
	private static List<ReturnedProducts> ReturnedProductsInstances = new LinkedList<ReturnedProducts>();
	private static List<Report> ReportInstances = new LinkedList<Report>();
	private static List<RestockProducts> RestockProductsInstances = new LinkedList<RestockProducts>();

	
	/* Put instances list into Map */
	static {
		AllInstance.put("Customer", CustomerInstances);
		AllInstance.put("Member", MemberInstances);
		AllInstance.put("Cashier", CashierInstances);
		AllInstance.put("StoreManager", StoreManagerInstances);
		AllInstance.put("Product", ProductInstances);
		AllInstance.put("Supplier", SupplierInstances);
		AllInstance.put("Inventory", InventoryInstances);
		AllInstance.put("Order", OrderInstances);
		AllInstance.put("Transaction", TransactionInstances);
		AllInstance.put("Feedback", FeedbackInstances);
		AllInstance.put("Receipt", ReceiptInstances);
		AllInstance.put("SupplierOrder", SupplierOrderInstances);
		AllInstance.put("Users", UsersInstances);
		AllInstance.put("Cart", CartInstances);
		AllInstance.put("ReturnedProducts", ReturnedProductsInstances);
		AllInstance.put("Report", ReportInstances);
		AllInstance.put("RestockProducts", RestockProductsInstances);
	} 
		
	/* Save State */
	public static void save(File file) {
		
		try {
			
			ObjectOutputStream stateSave = new ObjectOutputStream(new FileOutputStream(file));
			
			stateSave.writeObject(CustomerInstances);
			stateSave.writeObject(MemberInstances);
			stateSave.writeObject(CashierInstances);
			stateSave.writeObject(StoreManagerInstances);
			stateSave.writeObject(ProductInstances);
			stateSave.writeObject(SupplierInstances);
			stateSave.writeObject(InventoryInstances);
			stateSave.writeObject(OrderInstances);
			stateSave.writeObject(TransactionInstances);
			stateSave.writeObject(FeedbackInstances);
			stateSave.writeObject(ReceiptInstances);
			stateSave.writeObject(SupplierOrderInstances);
			stateSave.writeObject(UsersInstances);
			stateSave.writeObject(CartInstances);
			stateSave.writeObject(ReturnedProductsInstances);
			stateSave.writeObject(ReportInstances);
			stateSave.writeObject(RestockProductsInstances);
			
			stateSave.close();
					
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/* Load State */
	public static void load(File file) {
		
		try {
			
			ObjectInputStream stateLoad = new ObjectInputStream(new FileInputStream(file));
			
			try {
				
				CustomerInstances =  (List<Customer>) stateLoad.readObject();
				AllInstance.put("Customer", CustomerInstances);
				MemberInstances =  (List<Member>) stateLoad.readObject();
				AllInstance.put("Member", MemberInstances);
				CashierInstances =  (List<Cashier>) stateLoad.readObject();
				AllInstance.put("Cashier", CashierInstances);
				StoreManagerInstances =  (List<StoreManager>) stateLoad.readObject();
				AllInstance.put("StoreManager", StoreManagerInstances);
				ProductInstances =  (List<Product>) stateLoad.readObject();
				AllInstance.put("Product", ProductInstances);
				SupplierInstances =  (List<Supplier>) stateLoad.readObject();
				AllInstance.put("Supplier", SupplierInstances);
				InventoryInstances =  (List<Inventory>) stateLoad.readObject();
				AllInstance.put("Inventory", InventoryInstances);
				OrderInstances =  (List<Order>) stateLoad.readObject();
				AllInstance.put("Order", OrderInstances);
				TransactionInstances =  (List<Transaction>) stateLoad.readObject();
				AllInstance.put("Transaction", TransactionInstances);
				FeedbackInstances =  (List<Feedback>) stateLoad.readObject();
				AllInstance.put("Feedback", FeedbackInstances);
				ReceiptInstances =  (List<Receipt>) stateLoad.readObject();
				AllInstance.put("Receipt", ReceiptInstances);
				SupplierOrderInstances =  (List<SupplierOrder>) stateLoad.readObject();
				AllInstance.put("SupplierOrder", SupplierOrderInstances);
				UsersInstances =  (List<Users>) stateLoad.readObject();
				AllInstance.put("Users", UsersInstances);
				CartInstances =  (List<Cart>) stateLoad.readObject();
				AllInstance.put("Cart", CartInstances);
				ReturnedProductsInstances =  (List<ReturnedProducts>) stateLoad.readObject();
				AllInstance.put("ReturnedProducts", ReturnedProductsInstances);
				ReportInstances =  (List<Report>) stateLoad.readObject();
				AllInstance.put("Report", ReportInstances);
				RestockProductsInstances =  (List<RestockProducts>) stateLoad.readObject();
				AllInstance.put("RestockProducts", RestockProductsInstances);
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
	/* create object */  
	public static Object createObject(String Classifer) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method createObjectMethod = c.getDeclaredMethod("create" + Classifer + "Object");
			return createObjectMethod.invoke(c);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/* add object */  
	public static Object addObject(String Classifer, Object ob) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method addObjectMethod = c.getDeclaredMethod("add" + Classifer + "Object", Class.forName("entities." + Classifer));
			return  (boolean) addObjectMethod.invoke(c, ob);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}	
	
	/* add objects */  
	public static Object addObjects(String Classifer, List obs) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method addObjectsMethod = c.getDeclaredMethod("add" + Classifer + "Objects", Class.forName("java.util.List"));
			return  (boolean) addObjectsMethod.invoke(c, obs);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	/* Release object */
	public static boolean deleteObject(String Classifer, Object ob) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method deleteObjectMethod = c.getDeclaredMethod("delete" + Classifer + "Object", Class.forName("entities." + Classifer));
			return  (boolean) deleteObjectMethod.invoke(c, ob);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	
	/* Release objects */
	public static boolean deleteObjects(String Classifer, List obs) {
		try
		{
			Class c = Class.forName("entities.EntityManager");
			Method deleteObjectMethod = c.getDeclaredMethod("delete" + Classifer + "Objects", Class.forName("java.util.List"));
			return  (boolean) deleteObjectMethod.invoke(c, obs);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}		 	
	
	 /* Get all objects belongs to same class */
	public static List getAllInstancesOf(String ClassName) {
			 return AllInstance.get(ClassName);
	}	

   /* Sub-create object */
	public static Customer createCustomerObject() {
		Customer o = new Customer();
		return o;
	}
	
	public static boolean addCustomerObject(Customer o) {
		return CustomerInstances.add(o);
	}
	
	public static boolean addCustomerObjects(List<Customer> os) {
		return CustomerInstances.addAll(os);
	}
	
	public static boolean deleteCustomerObject(Customer o) {
		return CustomerInstances.remove(o);
	}
	
	public static boolean deleteCustomerObjects(List<Customer> os) {
		return CustomerInstances.removeAll(os);
	}
	public static Member createMemberObject() {
		Member o = new Member();
		return o;
	}
	
	public static boolean addMemberObject(Member o) {
		return MemberInstances.add(o);
	}
	
	public static boolean addMemberObjects(List<Member> os) {
		return MemberInstances.addAll(os);
	}
	
	public static boolean deleteMemberObject(Member o) {
		return MemberInstances.remove(o);
	}
	
	public static boolean deleteMemberObjects(List<Member> os) {
		return MemberInstances.removeAll(os);
	}
	public static Cashier createCashierObject() {
		Cashier o = new Cashier();
		return o;
	}
	
	public static boolean addCashierObject(Cashier o) {
		return CashierInstances.add(o);
	}
	
	public static boolean addCashierObjects(List<Cashier> os) {
		return CashierInstances.addAll(os);
	}
	
	public static boolean deleteCashierObject(Cashier o) {
		return CashierInstances.remove(o);
	}
	
	public static boolean deleteCashierObjects(List<Cashier> os) {
		return CashierInstances.removeAll(os);
	}
	public static StoreManager createStoreManagerObject() {
		StoreManager o = new StoreManager();
		return o;
	}
	
	public static boolean addStoreManagerObject(StoreManager o) {
		return StoreManagerInstances.add(o);
	}
	
	public static boolean addStoreManagerObjects(List<StoreManager> os) {
		return StoreManagerInstances.addAll(os);
	}
	
	public static boolean deleteStoreManagerObject(StoreManager o) {
		return StoreManagerInstances.remove(o);
	}
	
	public static boolean deleteStoreManagerObjects(List<StoreManager> os) {
		return StoreManagerInstances.removeAll(os);
	}
	public static Product createProductObject() {
		Product o = new Product();
		return o;
	}
	
	public static boolean addProductObject(Product o) {
		return ProductInstances.add(o);
	}
	
	public static boolean addProductObjects(List<Product> os) {
		return ProductInstances.addAll(os);
	}
	
	public static boolean deleteProductObject(Product o) {
		return ProductInstances.remove(o);
	}
	
	public static boolean deleteProductObjects(List<Product> os) {
		return ProductInstances.removeAll(os);
	}
	public static Supplier createSupplierObject() {
		Supplier o = new Supplier();
		return o;
	}
	
	public static boolean addSupplierObject(Supplier o) {
		return SupplierInstances.add(o);
	}
	
	public static boolean addSupplierObjects(List<Supplier> os) {
		return SupplierInstances.addAll(os);
	}
	
	public static boolean deleteSupplierObject(Supplier o) {
		return SupplierInstances.remove(o);
	}
	
	public static boolean deleteSupplierObjects(List<Supplier> os) {
		return SupplierInstances.removeAll(os);
	}
	public static Inventory createInventoryObject() {
		Inventory o = new Inventory();
		return o;
	}
	
	public static boolean addInventoryObject(Inventory o) {
		return InventoryInstances.add(o);
	}
	
	public static boolean addInventoryObjects(List<Inventory> os) {
		return InventoryInstances.addAll(os);
	}
	
	public static boolean deleteInventoryObject(Inventory o) {
		return InventoryInstances.remove(o);
	}
	
	public static boolean deleteInventoryObjects(List<Inventory> os) {
		return InventoryInstances.removeAll(os);
	}
	public static Order createOrderObject() {
		Order o = new Order();
		return o;
	}
	
	public static boolean addOrderObject(Order o) {
		return OrderInstances.add(o);
	}
	
	public static boolean addOrderObjects(List<Order> os) {
		return OrderInstances.addAll(os);
	}
	
	public static boolean deleteOrderObject(Order o) {
		return OrderInstances.remove(o);
	}
	
	public static boolean deleteOrderObjects(List<Order> os) {
		return OrderInstances.removeAll(os);
	}
	public static Transaction createTransactionObject() {
		Transaction o = new Transaction();
		return o;
	}
	
	public static boolean addTransactionObject(Transaction o) {
		return TransactionInstances.add(o);
	}
	
	public static boolean addTransactionObjects(List<Transaction> os) {
		return TransactionInstances.addAll(os);
	}
	
	public static boolean deleteTransactionObject(Transaction o) {
		return TransactionInstances.remove(o);
	}
	
	public static boolean deleteTransactionObjects(List<Transaction> os) {
		return TransactionInstances.removeAll(os);
	}
	public static Feedback createFeedbackObject() {
		Feedback o = new Feedback();
		return o;
	}
	
	public static boolean addFeedbackObject(Feedback o) {
		return FeedbackInstances.add(o);
	}
	
	public static boolean addFeedbackObjects(List<Feedback> os) {
		return FeedbackInstances.addAll(os);
	}
	
	public static boolean deleteFeedbackObject(Feedback o) {
		return FeedbackInstances.remove(o);
	}
	
	public static boolean deleteFeedbackObjects(List<Feedback> os) {
		return FeedbackInstances.removeAll(os);
	}
	public static Receipt createReceiptObject() {
		Receipt o = new Receipt();
		return o;
	}
	
	public static boolean addReceiptObject(Receipt o) {
		return ReceiptInstances.add(o);
	}
	
	public static boolean addReceiptObjects(List<Receipt> os) {
		return ReceiptInstances.addAll(os);
	}
	
	public static boolean deleteReceiptObject(Receipt o) {
		return ReceiptInstances.remove(o);
	}
	
	public static boolean deleteReceiptObjects(List<Receipt> os) {
		return ReceiptInstances.removeAll(os);
	}
	public static SupplierOrder createSupplierOrderObject() {
		SupplierOrder o = new SupplierOrder();
		return o;
	}
	
	public static boolean addSupplierOrderObject(SupplierOrder o) {
		return SupplierOrderInstances.add(o);
	}
	
	public static boolean addSupplierOrderObjects(List<SupplierOrder> os) {
		return SupplierOrderInstances.addAll(os);
	}
	
	public static boolean deleteSupplierOrderObject(SupplierOrder o) {
		return SupplierOrderInstances.remove(o);
	}
	
	public static boolean deleteSupplierOrderObjects(List<SupplierOrder> os) {
		return SupplierOrderInstances.removeAll(os);
	}
	public static Users createUsersObject() {
		Users o = new Users();
		return o;
	}
	
	public static boolean addUsersObject(Users o) {
		return UsersInstances.add(o);
	}
	
	public static boolean addUsersObjects(List<Users> os) {
		return UsersInstances.addAll(os);
	}
	
	public static boolean deleteUsersObject(Users o) {
		return UsersInstances.remove(o);
	}
	
	public static boolean deleteUsersObjects(List<Users> os) {
		return UsersInstances.removeAll(os);
	}
	public static Cart createCartObject() {
		Cart o = new Cart();
		return o;
	}
	
	public static boolean addCartObject(Cart o) {
		return CartInstances.add(o);
	}
	
	public static boolean addCartObjects(List<Cart> os) {
		return CartInstances.addAll(os);
	}
	
	public static boolean deleteCartObject(Cart o) {
		return CartInstances.remove(o);
	}
	
	public static boolean deleteCartObjects(List<Cart> os) {
		return CartInstances.removeAll(os);
	}
	public static ReturnedProducts createReturnedProductsObject() {
		ReturnedProducts o = new ReturnedProducts();
		return o;
	}
	
	public static boolean addReturnedProductsObject(ReturnedProducts o) {
		return ReturnedProductsInstances.add(o);
	}
	
	public static boolean addReturnedProductsObjects(List<ReturnedProducts> os) {
		return ReturnedProductsInstances.addAll(os);
	}
	
	public static boolean deleteReturnedProductsObject(ReturnedProducts o) {
		return ReturnedProductsInstances.remove(o);
	}
	
	public static boolean deleteReturnedProductsObjects(List<ReturnedProducts> os) {
		return ReturnedProductsInstances.removeAll(os);
	}
	public static Report createReportObject() {
		Report o = new Report();
		return o;
	}
	
	public static boolean addReportObject(Report o) {
		return ReportInstances.add(o);
	}
	
	public static boolean addReportObjects(List<Report> os) {
		return ReportInstances.addAll(os);
	}
	
	public static boolean deleteReportObject(Report o) {
		return ReportInstances.remove(o);
	}
	
	public static boolean deleteReportObjects(List<Report> os) {
		return ReportInstances.removeAll(os);
	}
	public static RestockProducts createRestockProductsObject() {
		RestockProducts o = new RestockProducts();
		return o;
	}
	
	public static boolean addRestockProductsObject(RestockProducts o) {
		return RestockProductsInstances.add(o);
	}
	
	public static boolean addRestockProductsObjects(List<RestockProducts> os) {
		return RestockProductsInstances.addAll(os);
	}
	
	public static boolean deleteRestockProductsObject(RestockProducts o) {
		return RestockProductsInstances.remove(o);
	}
	
	public static boolean deleteRestockProductsObjects(List<RestockProducts> os) {
		return RestockProductsInstances.removeAll(os);
	}
  
}

