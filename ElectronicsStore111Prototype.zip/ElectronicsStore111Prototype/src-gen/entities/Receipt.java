package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Receipt implements Serializable {
	
	/* all primary attributes */
	private String ReceiptID;
	private String PaymentMethod;
	private float TotalPrice;
	private Cart ProductList;
	private LocalDate DateOfPurchase;
	private String TransactionID;
	
	/* all references */
	private Cashier ProvidedBy; 
	private Transaction MustHave; 
	
	/* all get and set functions */
	public String getReceiptID() {
		return ReceiptID;
	}	
	
	public void setReceiptID(String receiptid) {
		this.ReceiptID = receiptid;
	}
	public String getPaymentMethod() {
		return PaymentMethod;
	}	
	
	public void setPaymentMethod(String paymentmethod) {
		this.PaymentMethod = paymentmethod;
	}
	public float getTotalPrice() {
		return TotalPrice;
	}	
	
	public void setTotalPrice(float totalprice) {
		this.TotalPrice = totalprice;
	}
	public Cart getProductList() {
		return ProductList;
	}	
	
	public void setProductList(Cart productlist) {
		this.ProductList = productlist;
	}
	public LocalDate getDateOfPurchase() {
		return DateOfPurchase;
	}	
	
	public void setDateOfPurchase(LocalDate dateofpurchase) {
		this.DateOfPurchase = dateofpurchase;
	}
	
	/* all functions for reference*/
	public Cashier getProvidedBy() {
		return ProvidedBy;
	}	
	
	public void setProvidedBy(Cashier cashier) {
		this.ProvidedBy = cashier;
	}			
	public Transaction getMustHave() {
		return MustHave;
	}	
	
	public void setMustHave(Transaction transaction) {
		this.MustHave = transaction;
	}
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String ID) {
		this.TransactionID = ID;
	}
	


}
