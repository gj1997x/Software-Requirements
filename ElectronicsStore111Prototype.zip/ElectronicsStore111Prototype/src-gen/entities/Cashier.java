package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Cashier implements Serializable {
	
	/* all primary attributes */
	private String CashierID;
	private String FullName;
	private int EmployeeNumber;
	private String Branch;
	
	/* all references */
	private List<Order> CheckedOutBy = new LinkedList<Order>(); 
	private List<Transaction> Process = new LinkedList<Transaction>(); 
	private List<Receipt> Provides = new LinkedList<Receipt>(); 
	private Users RepresentedBy; 
	
	/* all get and set functions */
	public String getCashierID() {
		return CashierID;
	}	
	
	public void setCashierID(String cashierid) {
		this.CashierID = cashierid;
	}
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public int getEmployeeNumber() {
		return EmployeeNumber;
	}	
	
	public void setEmployeeNumber(int employeenumber) {
		this.EmployeeNumber = employeenumber;
	}
	public String getBranch() {
		return Branch;
	}	
	
	public void setBranch(String branch) {
		this.Branch = branch;
	}
	
	/* all functions for reference*/
	public List<Order> getCheckedOutBy() {
		return CheckedOutBy;
	}	
	
	public void addCheckedOutBy(Order order) {
		this.CheckedOutBy.add(order);
	}
	
	public void deleteCheckedOutBy(Order order) {
		this.CheckedOutBy.remove(order);
	}
	public List<Transaction> getProcess() {
		return Process;
	}	
	
	public void addProcess(Transaction transaction) {
		this.Process.add(transaction);
	}
	
	public void deleteProcess(Transaction transaction) {
		this.Process.remove(transaction);
	}
	public List<Receipt> getProvides() {
		return Provides;
	}	
	
	public void addProvides(Receipt receipt) {
		this.Provides.add(receipt);
	}
	
	public void deleteProvides(Receipt receipt) {
		this.Provides.remove(receipt);
	}
	public Users getRepresentedBy() {
		return RepresentedBy;
	}	
	
	public void setRepresentedBy(Users users) {
		this.RepresentedBy = users;
	}			
	


}
