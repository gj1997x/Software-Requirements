package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class RestockProducts implements Serializable {
	
	/* all primary attributes */
	private List<Product> ProductsNeededList;
	private String RestockProductsID;
	
	/* all references */
	private StoreManager AskTo; 
	
	/* all get and set functions */
	public List<Product> getProductsNeededList() {
		return ProductsNeededList;
	}	
	
	public void setProductsNeededList(Product productsneededlist) {
		this.ProductsNeededList.add(productsneededlist);
	}
	public String getRestockProductsID() {
		return RestockProductsID;
	}	
	
	public void setRestockProductsID(String restockproductsid) {
		this.RestockProductsID = restockproductsid;
	}
	
	/* all functions for reference*/
	public StoreManager getAskTo() {
		return AskTo;
	}	
	
	public void setAskTo(StoreManager storemanager) {
		this.AskTo = storemanager;
	}			
	


}
