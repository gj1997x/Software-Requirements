package entities;

import services.impl.StandardOPs;
import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Arrays;
import java.time.LocalDate;
import java.io.Serializable;
import java.lang.reflect.Method;

public class Report implements Serializable {
	
	/* all primary attributes */
	private String ReportID;
	private LocalDate DateGenerated;
	private String ReportResult;
	private String TypeOfReport;
	public ArrayList<String> validReport = new ArrayList<String>();
	
	/* all references */
	private StoreManager Generates; 
	
	/* all get and set functions */
	public String getReportID() {
		return ReportID;
	}	
	
	public void setReportID(String reportid) {
		this.ReportID = reportid;
	}
	public LocalDate getDateGenerated() {
		return DateGenerated;
	}	
	
	public void setDateGenerated(LocalDate dategenerated) {
		this.DateGenerated = dategenerated;
	}
	public String getReportResult() {
		return ReportResult;
	}	
	
	public void setReportResult(String reportresult) {
		this.ReportResult = reportresult;
	}
	public String getTypeOfReport() {
		return TypeOfReport;
	}	
	
	public void setTypeOfReport(String typeofreport) {
		this.TypeOfReport = typeofreport;
	}
	
	/* all functions for reference*/
	public StoreManager getGenerates() {
		return Generates;
	}	
	
	public void setGenerates(StoreManager storemanager) {
		this.Generates = storemanager;
	}			
	


}
