package gui;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TabPane;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Modality;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.Tooltip;

import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;
import java.io.File;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.List;
import java.time.LocalDate;
import java.util.LinkedList;

import java.lang.reflect.Array;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;

import gui.supportclass.*;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.util.Callback;
import services.*;
import services.impl.*;
import java.time.format.DateTimeFormatter;
import java.lang.reflect.Method;

import entities.*;

public class PrototypeController implements Initializable {


	DateTimeFormatter dateformatter;
	 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	
		electronics_service = ServiceManager.createElectronics();
		thirdpartyservices_service = ServiceManager.createThirdPartyServices();
		signupservice_service = ServiceManager.createSignupService();
		systemloginservice_service = ServiceManager.createSystemLoginService();
		credentialscheckservice_service = ServiceManager.createCredentialsCheckService();
		browseproductsservice_service = ServiceManager.createBrowseProductsService();
		checkoutservice_service = ServiceManager.createCheckOutService();
		returnproductservice_service = ServiceManager.createReturnProductService();
		reviewcartservice_service = ServiceManager.createReviewCartService();
		modifycartservice_service = ServiceManager.createModifyCartService();
		givefeedbackservice_service = ServiceManager.createGiveFeedbackService();
		membershipstatusservice_service = ServiceManager.createMembershipStatusService();
		scanproductsservice_service = ServiceManager.createScanProductsService();
		processpaymentservice_service = ServiceManager.createProcessPaymentService();
		processreturnservice_service = ServiceManager.createProcessReturnService();
		printreceiptservice_service = ServiceManager.createPrintReceiptService();
		paymentvalidationservice_service = ServiceManager.createPaymentValidationService();
		instorepaymentvalidationservice_service = ServiceManager.createInStorePaymentValidationService();
		viewreportsservice_service = ServiceManager.createViewReportsService();
		manageinventoryservice_service = ServiceManager.createManageInventoryService();
		accessfeedbackservice_service = ServiceManager.createAccessFeedbackService();
		processordersservice_service = ServiceManager.createProcessOrdersService();
		processcheckoutservice_service = ServiceManager.createProcessCheckoutService();
		viewnewordersservice_service = ServiceManager.createViewNewOrdersService();
		electronicsstore111system_service = ServiceManager.createElectronicsStore111System();
				
		this.dateformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		
	   	 //prepare data for contract
	   	 prepareData();
	   	 
	   	 //generate invariant panel
	   	 genereateInvairantPanel();
	   	 
		 //Actor Threeview Binding
		 actorTreeViewBinding();
		 
		 //Generate
		 generatOperationPane();
		 genereateOpInvariantPanel();
		 
		 //prilimariry data
		 try {
			DataFitService.fit();
		 } catch (PreconditionException e) {
			// TODO Auto-generated catch block
		 	e.printStackTrace();
		 }
		 
		 //generate class statistic
		 classStatisicBingding();
		 
		 //generate object statistic
		 generateObjectTable();
		 
		 //genereate association statistic
		 associationStatisicBingding();

		 //set listener 
		 setListeners();
	}
	
	/**
	 * deepCopyforTreeItem (Actor Generation)
	 */
	TreeItem<String> deepCopyTree(TreeItem<String> item) {
		    TreeItem<String> copy = new TreeItem<String>(item.getValue());
		    for (TreeItem<String> child : item.getChildren()) {
		        copy.getChildren().add(deepCopyTree(child));
		    }
		    return copy;
	}
	
	/**
	 * check all invariant and update invariant panel
	 */
	public void invairantPanelUpdate() {
		
		try {
			
			for (Entry<String, Label> inv : entity_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String entityName = invt[0];
				for (Object o : EntityManager.getAllInstancesOf(entityName)) {				
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}				
			}
			
			for (Entry<String, Label> inv : service_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String serviceName = invt[0];
				for (Object o : ServiceManager.getAllInstancesOf(serviceName)) {				
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	/**
	 * check op invariant and update op invariant panel
	 */		
	public void opInvairantPanelUpdate() {
		
		try {
			
			for (Entry<String, Label> inv : op_entity_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String entityName = invt[0];
				for (Object o : EntityManager.getAllInstancesOf(entityName)) {
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
			for (Entry<String, Label> inv : op_service_invariants_label_map.entrySet()) {
				String invname = inv.getKey();
				String[] invt = invname.split("_");
				String serviceName = invt[0];
				for (Object o : ServiceManager.getAllInstancesOf(serviceName)) {
					 Method m = o.getClass().getMethod(invname);
					 if ((boolean)m.invoke(o) == false) {
						 inv.getValue().setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #af0c27 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
						 break;
					 }
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/* 
	*	generate op invariant panel 
	*/
	public void genereateOpInvariantPanel() {
		
		opInvariantPanel = new HashMap<String, VBox>();
		op_entity_invariants_label_map = new LinkedHashMap<String, Label>();
		op_service_invariants_label_map = new LinkedHashMap<String, Label>();
		
		VBox v;
		List<String> entities;
		v = new VBox();
		
		//entities invariants
		entities = SystemLoginServiceImpl.opINVRelatedEntity.get("usernameInput");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("usernameInput" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SystemLoginService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("usernameInput", v);
		
		v = new VBox();
		
		//entities invariants
		entities = SystemLoginServiceImpl.opINVRelatedEntity.get("passwordInput");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("passwordInput" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SystemLoginService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("passwordInput", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CredentialsCheckServiceImpl.opINVRelatedEntity.get("validationCheck");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("validationCheck" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CredentialsCheckService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("validationCheck", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CredentialsCheckServiceImpl.opINVRelatedEntity.get("validationMessage");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("validationMessage" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CredentialsCheckService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("validationMessage", v);
		
		v = new VBox();
		
		//entities invariants
		entities = SignupServiceImpl.opINVRelatedEntity.get("customerRegUsername");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("customerRegUsername" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SignupService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("customerRegUsername", v);
		
		v = new VBox();
		
		//entities invariants
		entities = SignupServiceImpl.opINVRelatedEntity.get("customerRegPassword");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("customerRegPassword" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SignupService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("customerRegPassword", v);
		
		v = new VBox();
		
		//entities invariants
		entities = SignupServiceImpl.opINVRelatedEntity.get("customerDetails");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("customerDetails" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SignupService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("customerDetails", v);
		
		v = new VBox();
		
		//entities invariants
		entities = SignupServiceImpl.opINVRelatedEntity.get("saveDetails");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("saveDetails" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("SignupService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("saveDetails", v);
		
		v = new VBox();
		
		//entities invariants
		entities = BrowseProductsServiceImpl.opINVRelatedEntity.get("searchProducts");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("searchProducts" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("BrowseProductsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("searchProducts", v);
		
		v = new VBox();
		
		//entities invariants
		entities = BrowseProductsServiceImpl.opINVRelatedEntity.get("viewAllProducts");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("viewAllProducts" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("BrowseProductsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("viewAllProducts", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CheckOutServiceImpl.opINVRelatedEntity.get("cartSummary");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("cartSummary" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CheckOutService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("cartSummary", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CheckOutServiceImpl.opINVRelatedEntity.get("makePayment");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("makePayment" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CheckOutService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("makePayment", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CheckOutServiceImpl.opINVRelatedEntity.get("getGuestUserDetails");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getGuestUserDetails" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CheckOutService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getGuestUserDetails", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ReturnProductServiceImpl.opINVRelatedEntity.get("getTransactionID");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getTransactionID" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ReturnProductService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getTransactionID", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ReturnProductServiceImpl.opINVRelatedEntity.get("productID");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("productID" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ReturnProductService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("productID", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ReturnProductServiceImpl.opINVRelatedEntity.get("getReason");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getReason" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ReturnProductService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getReason", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ReturnProductServiceImpl.opINVRelatedEntity.get("saveReturn");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("saveReturn" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ReturnProductService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("saveReturn", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ReviewCartServiceImpl.opINVRelatedEntity.get("reviewCart");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("reviewCart" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ReviewCartService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("reviewCart", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ModifyCartServiceImpl.opINVRelatedEntity.get("modifyCart");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("modifyCart" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ModifyCartService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("modifyCart", v);
		
		v = new VBox();
		
		//entities invariants
		entities = GiveFeedbackServiceImpl.opINVRelatedEntity.get("giveFeedback");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("giveFeedback" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("GiveFeedbackService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("giveFeedback", v);
		
		v = new VBox();
		
		//entities invariants
		entities = GiveFeedbackServiceImpl.opINVRelatedEntity.get("saveFeedback");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("saveFeedback" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("GiveFeedbackService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("saveFeedback", v);
		
		v = new VBox();
		
		//entities invariants
		entities = MembershipStatusServiceImpl.opINVRelatedEntity.get("getMembershipStatus");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getMembershipStatus" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("MembershipStatusService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getMembershipStatus", v);
		
		v = new VBox();
		
		//entities invariants
		entities = MembershipStatusServiceImpl.opINVRelatedEntity.get("showCurrentStatus");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("showCurrentStatus" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("MembershipStatusService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("showCurrentStatus", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ScanProductsServiceImpl.opINVRelatedEntity.get("scanProducts");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("scanProducts" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ScanProductsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("scanProducts", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ScanProductsServiceImpl.opINVRelatedEntity.get("updateCart");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("updateCart" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ScanProductsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("updateCart", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ProcessPaymentServiceImpl.opINVRelatedEntity.get("paymentProcess");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("paymentProcess" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ProcessPaymentService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("paymentProcess", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ProcessPaymentServiceImpl.opINVRelatedEntity.get("addLoyaltyPoints");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("addLoyaltyPoints" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ProcessPaymentService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("addLoyaltyPoints", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ProcessReturnServiceImpl.opINVRelatedEntity.get("getCustomerID");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getCustomerID" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ProcessReturnService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getCustomerID", v);
		
		v = new VBox();
		
		//entities invariants
		entities = PrintReceiptServiceImpl.opINVRelatedEntity.get("getUserDetails");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getUserDetails" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("PrintReceiptService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getUserDetails", v);
		
		v = new VBox();
		
		//entities invariants
		entities = PrintReceiptServiceImpl.opINVRelatedEntity.get("printReciept");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("printReciept" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("PrintReceiptService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("printReciept", v);
		
		v = new VBox();
		
		//entities invariants
		entities = PaymentValidationServiceImpl.opINVRelatedEntity.get("processingUserPayment");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("processingUserPayment" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("PaymentValidationService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("processingUserPayment", v);
		
		v = new VBox();
		
		//entities invariants
		entities = PaymentValidationServiceImpl.opINVRelatedEntity.get("bankContactandAuthorization");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("bankContactandAuthorization" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("PaymentValidationService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("bankContactandAuthorization", v);
		
		v = new VBox();
		
		//entities invariants
		entities = InStorePaymentValidationServiceImpl.opINVRelatedEntity.get("processingInStoreUserPayment");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("processingInStoreUserPayment" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("InStorePaymentValidationService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("processingInStoreUserPayment", v);
		
		v = new VBox();
		
		//entities invariants
		entities = InStorePaymentValidationServiceImpl.opINVRelatedEntity.get("bankContactandAuthorizationInStore");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("bankContactandAuthorizationInStore" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("InStorePaymentValidationService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("bankContactandAuthorizationInStore", v);
		
		v = new VBox();
		
		//entities invariants
		entities = InStorePaymentValidationServiceImpl.opINVRelatedEntity.get("cashPayment");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("cashPayment" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("InStorePaymentValidationService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("cashPayment", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ViewReportsServiceImpl.opINVRelatedEntity.get("generateReport");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("generateReport" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ViewReportsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("generateReport", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ViewReportsServiceImpl.opINVRelatedEntity.get("getReportType");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("getReportType" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ViewReportsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("getReportType", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ViewReportsServiceImpl.opINVRelatedEntity.get("viewAllReports");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("viewAllReports" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ViewReportsService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("viewAllReports", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ManageInventoryServiceImpl.opINVRelatedEntity.get("sendToSupplier");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("sendToSupplier" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ManageInventoryService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("sendToSupplier", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ManageInventoryServiceImpl.opINVRelatedEntity.get("recordRestock");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("recordRestock" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ManageInventoryService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("recordRestock", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ManageInventoryServiceImpl.opINVRelatedEntity.get("viewInventoryStockLevel");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("viewInventoryStockLevel" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ManageInventoryService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("viewInventoryStockLevel", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ManageInventoryServiceImpl.opINVRelatedEntity.get("orderStockProducts");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("orderStockProducts" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ManageInventoryService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("orderStockProducts", v);
		
		v = new VBox();
		
		//entities invariants
		entities = CheckOutServiceImpl.opINVRelatedEntity.get("newOrder");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("newOrder" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("CheckOutService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("newOrder", v);
		
		v = new VBox();
		
		//entities invariants
		entities = ManageInventoryServiceImpl.opINVRelatedEntity.get("creatingNewSupplier");
		if (entities != null) {
			for (String opRelatedEntities : entities) {
				for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
					
					String invname = inv.getKey();
					String[] invt = invname.split("_");
					String entityName = invt[0];
		
					if (opRelatedEntities.equals(entityName)) {
						Label l = new Label(invname);
						l.setStyle("-fx-max-width: Infinity;" + 
								"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
							    "-fx-padding: 6px;" +
							    "-fx-border-color: black;");
						Tooltip tp = new Tooltip();
						tp.setText(inv.getValue());
						l.setTooltip(tp);
						
						op_entity_invariants_label_map.put(invname, l);
						
						v.getChildren().add(l);
					}
				}
			}
		} else {
			Label l = new Label("creatingNewSupplier" + " is no related invariants");
			l.setPadding(new Insets(8, 8, 8, 8));
			v.getChildren().add(l);
		}
		
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			String invname = inv.getKey();
			String[] invt = invname.split("_");
			String serviceName = invt[0];
			
			if (serviceName.equals("ManageInventoryService")) {
				Label l = new Label(invname);
				l.setStyle("-fx-max-width: Infinity;" + 
						   "-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
						   "-fx-padding: 6px;" +
						   "-fx-border-color: black;");
				Tooltip tp = new Tooltip();
				tp.setText(inv.getValue());
				l.setTooltip(tp);
				
				op_entity_invariants_label_map.put(invname, l);
				
				v.getChildren().add(l);
			}
		}
		opInvariantPanel.put("creatingNewSupplier", v);
		
		
	}
	
	
	/*
	*  generate invariant panel
	*/
	public void genereateInvairantPanel() {
		
		service_invariants_label_map = new LinkedHashMap<String, Label>();
		entity_invariants_label_map = new LinkedHashMap<String, Label>();
		
		//entity_invariants_map
		VBox v = new VBox();
		//service invariants
		for (Entry<String, String> inv : service_invariants_map.entrySet()) {
			
			Label l = new Label(inv.getKey());
			l.setStyle("-fx-max-width: Infinity;" + 
					"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
				    "-fx-padding: 6px;" +
				    "-fx-border-color: black;");
			
			Tooltip tp = new Tooltip();
			tp.setText(inv.getValue());
			l.setTooltip(tp);
			
			service_invariants_label_map.put(inv.getKey(), l);
			v.getChildren().add(l);
			
		}
		//entity invariants
		for (Entry<String, String> inv : entity_invariants_map.entrySet()) {
			
			String INVname = inv.getKey();
			Label l = new Label(INVname);
			if (INVname.contains("AssociationInvariants")) {
				l.setStyle("-fx-max-width: Infinity;" + 
					"-fx-background-color: linear-gradient(to right, #099b17 0%, #F0FFFF 100%);" +
				    "-fx-padding: 6px;" +
				    "-fx-border-color: black;");
			} else {
				l.setStyle("-fx-max-width: Infinity;" + 
									"-fx-background-color: linear-gradient(to right, #7FFF00 0%, #F0FFFF 100%);" +
								    "-fx-padding: 6px;" +
								    "-fx-border-color: black;");
			}	
			Tooltip tp = new Tooltip();
			tp.setText(inv.getValue());
			l.setTooltip(tp);
			
			entity_invariants_label_map.put(inv.getKey(), l);
			v.getChildren().add(l);
			
		}
		ScrollPane scrollPane = new ScrollPane(v);
		scrollPane.setFitToWidth(true);
		all_invariant_pane.setMaxHeight(850);
		
		all_invariant_pane.setContent(scrollPane);
	}	
	
	
	
	/* 
	*	mainPane add listener
	*/
	public void setListeners() {
		 mainPane.getSelectionModel().selectedItemProperty().addListener((ov, oldTab, newTab) -> {
			 
			 	if (newTab.getText().equals("System State")) {
			 		System.out.println("refresh all");
			 		refreshAll();
			 	}
		    
		    });
	}
	
	
	//checking all invariants
	public void checkAllInvariants() {
		
		invairantPanelUpdate();
	
	}	
	
	//refresh all
	public void refreshAll() {
		
		invairantPanelUpdate();
		classStatisticUpdate();
		generateObjectTable();
	}
	
	
	//update association
	public void updateAssociation(String className) {
		
		for (AssociationInfo assoc : allassociationData.get(className)) {
			assoc.computeAssociationNumber();
		}
		
	}
	
	public void updateAssociation(String className, int index) {
		
		for (AssociationInfo assoc : allassociationData.get(className)) {
			assoc.computeAssociationNumber(index);
		}
		
	}	
	
	public void generateObjectTable() {
		
		allObjectTables = new LinkedHashMap<String, TableView>();
		
		TableView<Map<String, String>> tableCustomer = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableCustomer_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
		tableCustomer_CustomerID.setMinWidth("CustomerID".length()*10);
		tableCustomer_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_CustomerID);
		TableColumn<Map<String, String>, String> tableCustomer_FullName = new TableColumn<Map<String, String>, String>("FullName");
		tableCustomer_FullName.setMinWidth("FullName".length()*10);
		tableCustomer_FullName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FullName"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_FullName);
		TableColumn<Map<String, String>, String> tableCustomer_Address = new TableColumn<Map<String, String>, String>("Address");
		tableCustomer_Address.setMinWidth("Address".length()*10);
		tableCustomer_Address.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Address"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Address);
		TableColumn<Map<String, String>, String> tableCustomer_PhoneNumber = new TableColumn<Map<String, String>, String>("PhoneNumber");
		tableCustomer_PhoneNumber.setMinWidth("PhoneNumber".length()*10);
		tableCustomer_PhoneNumber.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("PhoneNumber"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_PhoneNumber);
		TableColumn<Map<String, String>, String> tableCustomer_Email = new TableColumn<Map<String, String>, String>("Email");
		tableCustomer_Email.setMinWidth("Email".length()*10);
		tableCustomer_Email.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Email"));
		    }
		});	
		tableCustomer.getColumns().add(tableCustomer_Email);
		
		//table data
		ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
		List<Customer> rsCustomer = EntityManager.getAllInstancesOf("Customer");
		for (Customer r : rsCustomer) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getCustomerID() != null)
				unit.put("CustomerID", String.valueOf(r.getCustomerID()));
			else
				unit.put("CustomerID", "");
			if (r.getFullName() != null)
				unit.put("FullName", String.valueOf(r.getFullName()));
			else
				unit.put("FullName", "");
			if (r.getAddress() != null)
				unit.put("Address", String.valueOf(r.getAddress()));
			else
				unit.put("Address", "");
			unit.put("PhoneNumber", String.valueOf(r.getPhoneNumber()));
			if (r.getEmail() != null)
				unit.put("Email", String.valueOf(r.getEmail()));
			else
				unit.put("Email", "");

			dataCustomer.add(unit);
		}
		
		tableCustomer.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableCustomer.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Customer", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableCustomer.setItems(dataCustomer);
		allObjectTables.put("Customer", tableCustomer);
		
		TableView<Map<String, String>> tableMember = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableMember_MemberID = new TableColumn<Map<String, String>, String>("MemberID");
		tableMember_MemberID.setMinWidth("MemberID".length()*10);
		tableMember_MemberID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("MemberID"));
		    }
		});	
		tableMember.getColumns().add(tableMember_MemberID);
		TableColumn<Map<String, String>, String> tableMember_FullName = new TableColumn<Map<String, String>, String>("FullName");
		tableMember_FullName.setMinWidth("FullName".length()*10);
		tableMember_FullName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FullName"));
		    }
		});	
		tableMember.getColumns().add(tableMember_FullName);
		TableColumn<Map<String, String>, String> tableMember_Tier = new TableColumn<Map<String, String>, String>("Tier");
		tableMember_Tier.setMinWidth("Tier".length()*10);
		tableMember_Tier.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Tier"));
		    }
		});	
		tableMember.getColumns().add(tableMember_Tier);
		TableColumn<Map<String, String>, String> tableMember_LoyaltyPoints = new TableColumn<Map<String, String>, String>("LoyaltyPoints");
		tableMember_LoyaltyPoints.setMinWidth("LoyaltyPoints".length()*10);
		tableMember_LoyaltyPoints.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("LoyaltyPoints"));
		    }
		});	
		tableMember.getColumns().add(tableMember_LoyaltyPoints);
		
		//table data
		ObservableList<Map<String, String>> dataMember = FXCollections.observableArrayList();
		List<Member> rsMember = EntityManager.getAllInstancesOf("Member");
		for (Member r : rsMember) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getMemberID() != null)
				unit.put("MemberID", String.valueOf(r.getMemberID()));
			else
				unit.put("MemberID", "");
			if (r.getFullName() != null)
				unit.put("FullName", String.valueOf(r.getFullName()));
			else
				unit.put("FullName", "");
			if (r.getTier() != null)
				unit.put("Tier", String.valueOf(r.getTier()));
			else
				unit.put("Tier", "");
			unit.put("LoyaltyPoints", String.valueOf(r.getLoyaltyPoints()));

			dataMember.add(unit);
		}
		
		tableMember.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableMember.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Member", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableMember.setItems(dataMember);
		allObjectTables.put("Member", tableMember);
		
		TableView<Map<String, String>> tableCashier = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableCashier_CashierID = new TableColumn<Map<String, String>, String>("CashierID");
		tableCashier_CashierID.setMinWidth("CashierID".length()*10);
		tableCashier_CashierID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CashierID"));
		    }
		});	
		tableCashier.getColumns().add(tableCashier_CashierID);
		TableColumn<Map<String, String>, String> tableCashier_FullName = new TableColumn<Map<String, String>, String>("FullName");
		tableCashier_FullName.setMinWidth("FullName".length()*10);
		tableCashier_FullName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FullName"));
		    }
		});	
		tableCashier.getColumns().add(tableCashier_FullName);
		TableColumn<Map<String, String>, String> tableCashier_EmployeeNumber = new TableColumn<Map<String, String>, String>("EmployeeNumber");
		tableCashier_EmployeeNumber.setMinWidth("EmployeeNumber".length()*10);
		tableCashier_EmployeeNumber.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("EmployeeNumber"));
		    }
		});	
		tableCashier.getColumns().add(tableCashier_EmployeeNumber);
		TableColumn<Map<String, String>, String> tableCashier_Branch = new TableColumn<Map<String, String>, String>("Branch");
		tableCashier_Branch.setMinWidth("Branch".length()*10);
		tableCashier_Branch.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Branch"));
		    }
		});	
		tableCashier.getColumns().add(tableCashier_Branch);
		
		//table data
		ObservableList<Map<String, String>> dataCashier = FXCollections.observableArrayList();
		List<Cashier> rsCashier = EntityManager.getAllInstancesOf("Cashier");
		for (Cashier r : rsCashier) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getCashierID() != null)
				unit.put("CashierID", String.valueOf(r.getCashierID()));
			else
				unit.put("CashierID", "");
			if (r.getFullName() != null)
				unit.put("FullName", String.valueOf(r.getFullName()));
			else
				unit.put("FullName", "");
			unit.put("EmployeeNumber", String.valueOf(r.getEmployeeNumber()));
			if (r.getBranch() != null)
				unit.put("Branch", String.valueOf(r.getBranch()));
			else
				unit.put("Branch", "");

			dataCashier.add(unit);
		}
		
		tableCashier.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableCashier.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Cashier", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableCashier.setItems(dataCashier);
		allObjectTables.put("Cashier", tableCashier);
		
		TableView<Map<String, String>> tableStoreManager = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableStoreManager_StoreManagerID = new TableColumn<Map<String, String>, String>("StoreManagerID");
		tableStoreManager_StoreManagerID.setMinWidth("StoreManagerID".length()*10);
		tableStoreManager_StoreManagerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("StoreManagerID"));
		    }
		});	
		tableStoreManager.getColumns().add(tableStoreManager_StoreManagerID);
		TableColumn<Map<String, String>, String> tableStoreManager_FullName = new TableColumn<Map<String, String>, String>("FullName");
		tableStoreManager_FullName.setMinWidth("FullName".length()*10);
		tableStoreManager_FullName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FullName"));
		    }
		});	
		tableStoreManager.getColumns().add(tableStoreManager_FullName);
		TableColumn<Map<String, String>, String> tableStoreManager_Branch = new TableColumn<Map<String, String>, String>("Branch");
		tableStoreManager_Branch.setMinWidth("Branch".length()*10);
		tableStoreManager_Branch.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Branch"));
		    }
		});	
		tableStoreManager.getColumns().add(tableStoreManager_Branch);
		
		//table data
		ObservableList<Map<String, String>> dataStoreManager = FXCollections.observableArrayList();
		List<StoreManager> rsStoreManager = EntityManager.getAllInstancesOf("StoreManager");
		for (StoreManager r : rsStoreManager) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getStoreManagerID() != null)
				unit.put("StoreManagerID", String.valueOf(r.getStoreManagerID()));
			else
				unit.put("StoreManagerID", "");
			if (r.getFullName() != null)
				unit.put("FullName", String.valueOf(r.getFullName()));
			else
				unit.put("FullName", "");
			if (r.getBranch() != null)
				unit.put("Branch", String.valueOf(r.getBranch()));
			else
				unit.put("Branch", "");

			dataStoreManager.add(unit);
		}
		
		tableStoreManager.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableStoreManager.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("StoreManager", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableStoreManager.setItems(dataStoreManager);
		allObjectTables.put("StoreManager", tableStoreManager);
		
		TableView<Map<String, String>> tableProduct = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableProduct_ProductID = new TableColumn<Map<String, String>, String>("ProductID");
		tableProduct_ProductID.setMinWidth("ProductID".length()*10);
		tableProduct_ProductID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductID"));
		    }
		});	
		tableProduct.getColumns().add(tableProduct_ProductID);
		TableColumn<Map<String, String>, String> tableProduct_ProductName = new TableColumn<Map<String, String>, String>("ProductName");
		tableProduct_ProductName.setMinWidth("ProductName".length()*10);
		tableProduct_ProductName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductName"));
		    }
		});	
		tableProduct.getColumns().add(tableProduct_ProductName);
		TableColumn<Map<String, String>, String> tableProduct_Price = new TableColumn<Map<String, String>, String>("Price");
		tableProduct_Price.setMinWidth("Price".length()*10);
		tableProduct_Price.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Price"));
		    }
		});	
		tableProduct.getColumns().add(tableProduct_Price);
		TableColumn<Map<String, String>, String> tableProduct_StockLevel = new TableColumn<Map<String, String>, String>("StockLevel");
		tableProduct_StockLevel.setMinWidth("StockLevel".length()*10);
		tableProduct_StockLevel.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("StockLevel"));
		    }
		});	
		tableProduct.getColumns().add(tableProduct_StockLevel);
		
		//table data
		ObservableList<Map<String, String>> dataProduct = FXCollections.observableArrayList();
		List<Product> rsProduct = EntityManager.getAllInstancesOf("Product");
		for (Product r : rsProduct) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getProductID() != null)
				unit.put("ProductID", String.valueOf(r.getProductID()));
			else
				unit.put("ProductID", "");
			if (r.getProductName() != null)
				unit.put("ProductName", String.valueOf(r.getProductName()));
			else
				unit.put("ProductName", "");
			unit.put("Price", String.valueOf(r.getPrice()));
			unit.put("StockLevel", String.valueOf(r.getStockLevel()));

			dataProduct.add(unit);
		}
		
		tableProduct.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableProduct.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Product", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableProduct.setItems(dataProduct);
		allObjectTables.put("Product", tableProduct);
		
		TableView<Map<String, String>> tableSupplier = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableSupplier_SupplierID = new TableColumn<Map<String, String>, String>("SupplierID");
		tableSupplier_SupplierID.setMinWidth("SupplierID".length()*10);
		tableSupplier_SupplierID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("SupplierID"));
		    }
		});	
		tableSupplier.getColumns().add(tableSupplier_SupplierID);
		TableColumn<Map<String, String>, String> tableSupplier_CompanyName = new TableColumn<Map<String, String>, String>("CompanyName");
		tableSupplier_CompanyName.setMinWidth("CompanyName".length()*10);
		tableSupplier_CompanyName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CompanyName"));
		    }
		});	
		tableSupplier.getColumns().add(tableSupplier_CompanyName);
		TableColumn<Map<String, String>, String> tableSupplier_ContactDetails = new TableColumn<Map<String, String>, String>("ContactDetails");
		tableSupplier_ContactDetails.setMinWidth("ContactDetails".length()*10);
		tableSupplier_ContactDetails.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ContactDetails"));
		    }
		});	
		tableSupplier.getColumns().add(tableSupplier_ContactDetails);
		
		//table data
		ObservableList<Map<String, String>> dataSupplier = FXCollections.observableArrayList();
		List<Supplier> rsSupplier = EntityManager.getAllInstancesOf("Supplier");
		for (Supplier r : rsSupplier) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getSupplierID() != null)
				unit.put("SupplierID", String.valueOf(r.getSupplierID()));
			else
				unit.put("SupplierID", "");
			if (r.getCompanyName() != null)
				unit.put("CompanyName", String.valueOf(r.getCompanyName()));
			else
				unit.put("CompanyName", "");
			if (r.getContactDetails() != null)
				unit.put("ContactDetails", String.valueOf(r.getContactDetails()));
			else
				unit.put("ContactDetails", "");

			dataSupplier.add(unit);
		}
		
		tableSupplier.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableSupplier.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Supplier", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableSupplier.setItems(dataSupplier);
		allObjectTables.put("Supplier", tableSupplier);
		
		TableView<Map<String, String>> tableInventory = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableInventory_InventoryID = new TableColumn<Map<String, String>, String>("InventoryID");
		tableInventory_InventoryID.setMinWidth("InventoryID".length()*10);
		tableInventory_InventoryID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("InventoryID"));
		    }
		});	
		tableInventory.getColumns().add(tableInventory_InventoryID);
		TableColumn<Map<String, String>, String> tableInventory_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
		tableInventory_ProductList.setMinWidth("ProductList".length()*10);
		tableInventory_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
		    }
		});	
		tableInventory.getColumns().add(tableInventory_ProductList);
		
		//table data
		ObservableList<Map<String, String>> dataInventory = FXCollections.observableArrayList();
		List<Inventory> rsInventory = EntityManager.getAllInstancesOf("Inventory");
		for (Inventory r : rsInventory) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getInventoryID() != null)
				unit.put("InventoryID", String.valueOf(r.getInventoryID()));
			else
				unit.put("InventoryID", "");
			unit.put("ProductList", String.valueOf(r.getProductList()));

			dataInventory.add(unit);
		}
		
		tableInventory.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableInventory.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Inventory", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableInventory.setItems(dataInventory);
		allObjectTables.put("Inventory", tableInventory);
		
		TableView<Map<String, String>> tableOrder = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableOrder_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
		tableOrder_OrderID.setMinWidth("OrderID".length()*10);
		tableOrder_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
		    }
		});	
		tableOrder.getColumns().add(tableOrder_OrderID);
		TableColumn<Map<String, String>, String> tableOrder_DateOfPurchase = new TableColumn<Map<String, String>, String>("DateOfPurchase");
		tableOrder_DateOfPurchase.setMinWidth("DateOfPurchase".length()*10);
		tableOrder_DateOfPurchase.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("DateOfPurchase"));
		    }
		});	
		tableOrder.getColumns().add(tableOrder_DateOfPurchase);
		TableColumn<Map<String, String>, String> tableOrder_TotalPrice = new TableColumn<Map<String, String>, String>("TotalPrice");
		tableOrder_TotalPrice.setMinWidth("TotalPrice".length()*10);
		tableOrder_TotalPrice.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TotalPrice"));
		    }
		});	
		tableOrder.getColumns().add(tableOrder_TotalPrice);
		TableColumn<Map<String, String>, String> tableOrder_ProductsList = new TableColumn<Map<String, String>, String>("ProductsList");
		tableOrder_ProductsList.setMinWidth("ProductsList".length()*10);
		tableOrder_ProductsList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductsList"));
		    }
		});	
		tableOrder.getColumns().add(tableOrder_ProductsList);
		
		//table data
		ObservableList<Map<String, String>> dataOrder = FXCollections.observableArrayList();
		List<Order> rsOrder = EntityManager.getAllInstancesOf("Order");
		for (Order r : rsOrder) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getOrderID() != null)
				unit.put("OrderID", String.valueOf(r.getOrderID()));
			else
				unit.put("OrderID", "");
			if (r.getDateOfPurchase() != null)
				unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
			else
				unit.put("DateOfPurchase", "");
			unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
			unit.put("ProductsList", String.valueOf(r.getProductsList()));

			dataOrder.add(unit);
		}
		
		tableOrder.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableOrder.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Order", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableOrder.setItems(dataOrder);
		allObjectTables.put("Order", tableOrder);
		
		TableView<Map<String, String>> tableTransaction = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableTransaction_TransactionID = new TableColumn<Map<String, String>, String>("TransactionID");
		tableTransaction_TransactionID.setMinWidth("TransactionID".length()*10);
		tableTransaction_TransactionID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TransactionID"));
		    }
		});	
		tableTransaction.getColumns().add(tableTransaction_TransactionID);
		TableColumn<Map<String, String>, String> tableTransaction_Amount = new TableColumn<Map<String, String>, String>("Amount");
		tableTransaction_Amount.setMinWidth("Amount".length()*10);
		tableTransaction_Amount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Amount"));
		    }
		});	
		tableTransaction.getColumns().add(tableTransaction_Amount);
		TableColumn<Map<String, String>, String> tableTransaction_PaymentMethod = new TableColumn<Map<String, String>, String>("PaymentMethod");
		tableTransaction_PaymentMethod.setMinWidth("PaymentMethod".length()*10);
		tableTransaction_PaymentMethod.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("PaymentMethod"));
		    }
		});	
		tableTransaction.getColumns().add(tableTransaction_PaymentMethod);
		TableColumn<Map<String, String>, String> tableTransaction_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
		tableTransaction_OrderID.setMinWidth("OrderID".length()*10);
		tableTransaction_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
		    }
		});	
		tableTransaction.getColumns().add(tableTransaction_OrderID);
		
		//table data
		ObservableList<Map<String, String>> dataTransaction = FXCollections.observableArrayList();
		List<Transaction> rsTransaction = EntityManager.getAllInstancesOf("Transaction");
		for (Transaction r : rsTransaction) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getTransactionID() != null)
				unit.put("TransactionID", String.valueOf(r.getTransactionID()));
			else
				unit.put("TransactionID", "");
			unit.put("Amount", String.valueOf(r.getAmount()));
			if (r.getPaymentMethod() != null)
				unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
			else
				unit.put("PaymentMethod", "");
			if (r.getOrderID() != null)
				unit.put("OrderID", String.valueOf(r.getOrderID()));
			else
				unit.put("OrderID", "");

			dataTransaction.add(unit);
		}
		
		tableTransaction.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableTransaction.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Transaction", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableTransaction.setItems(dataTransaction);
		allObjectTables.put("Transaction", tableTransaction);
		
		TableView<Map<String, String>> tableFeedback = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableFeedback_FeedbackID = new TableColumn<Map<String, String>, String>("FeedbackID");
		tableFeedback_FeedbackID.setMinWidth("FeedbackID".length()*10);
		tableFeedback_FeedbackID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FeedbackID"));
		    }
		});	
		tableFeedback.getColumns().add(tableFeedback_FeedbackID);
		TableColumn<Map<String, String>, String> tableFeedback_FeedbackContent = new TableColumn<Map<String, String>, String>("FeedbackContent");
		tableFeedback_FeedbackContent.setMinWidth("FeedbackContent".length()*10);
		tableFeedback_FeedbackContent.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("FeedbackContent"));
		    }
		});	
		tableFeedback.getColumns().add(tableFeedback_FeedbackContent);
		TableColumn<Map<String, String>, String> tableFeedback_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
		tableFeedback_CustomerID.setMinWidth("CustomerID".length()*10);
		tableFeedback_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
		    }
		});	
		tableFeedback.getColumns().add(tableFeedback_CustomerID);
		
		//table data
		ObservableList<Map<String, String>> dataFeedback = FXCollections.observableArrayList();
		List<Feedback> rsFeedback = EntityManager.getAllInstancesOf("Feedback");
		for (Feedback r : rsFeedback) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getFeedbackID() != null)
				unit.put("FeedbackID", String.valueOf(r.getFeedbackID()));
			else
				unit.put("FeedbackID", "");
			if (r.getFeedbackContent() != null)
				unit.put("FeedbackContent", String.valueOf(r.getFeedbackContent()));
			else
				unit.put("FeedbackContent", "");
			if (r.getCustomerID() != null)
				unit.put("CustomerID", String.valueOf(r.getCustomerID()));
			else
				unit.put("CustomerID", "");

			dataFeedback.add(unit);
		}
		
		tableFeedback.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableFeedback.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Feedback", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableFeedback.setItems(dataFeedback);
		allObjectTables.put("Feedback", tableFeedback);
		
		TableView<Map<String, String>> tableReceipt = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableReceipt_ReceiptID = new TableColumn<Map<String, String>, String>("ReceiptID");
		tableReceipt_ReceiptID.setMinWidth("ReceiptID".length()*10);
		tableReceipt_ReceiptID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ReceiptID"));
		    }
		});	
		tableReceipt.getColumns().add(tableReceipt_ReceiptID);
		TableColumn<Map<String, String>, String> tableReceipt_PaymentMethod = new TableColumn<Map<String, String>, String>("PaymentMethod");
		tableReceipt_PaymentMethod.setMinWidth("PaymentMethod".length()*10);
		tableReceipt_PaymentMethod.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("PaymentMethod"));
		    }
		});	
		tableReceipt.getColumns().add(tableReceipt_PaymentMethod);
		TableColumn<Map<String, String>, String> tableReceipt_TotalPrice = new TableColumn<Map<String, String>, String>("TotalPrice");
		tableReceipt_TotalPrice.setMinWidth("TotalPrice".length()*10);
		tableReceipt_TotalPrice.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TotalPrice"));
		    }
		});	
		tableReceipt.getColumns().add(tableReceipt_TotalPrice);
		TableColumn<Map<String, String>, String> tableReceipt_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
		tableReceipt_ProductList.setMinWidth("ProductList".length()*10);
		tableReceipt_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
		    }
		});	
		tableReceipt.getColumns().add(tableReceipt_ProductList);
		TableColumn<Map<String, String>, String> tableReceipt_DateOfPurchase = new TableColumn<Map<String, String>, String>("DateOfPurchase");
		tableReceipt_DateOfPurchase.setMinWidth("DateOfPurchase".length()*10);
		tableReceipt_DateOfPurchase.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("DateOfPurchase"));
		    }
		});	
		tableReceipt.getColumns().add(tableReceipt_DateOfPurchase);
		
		//table data
		ObservableList<Map<String, String>> dataReceipt = FXCollections.observableArrayList();
		List<Receipt> rsReceipt = EntityManager.getAllInstancesOf("Receipt");
		for (Receipt r : rsReceipt) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getReceiptID() != null)
				unit.put("ReceiptID", String.valueOf(r.getReceiptID()));
			else
				unit.put("ReceiptID", "");
			if (r.getPaymentMethod() != null)
				unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
			else
				unit.put("PaymentMethod", "");
			unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
			unit.put("ProductList", String.valueOf(r.getProductList()));
			if (r.getDateOfPurchase() != null)
				unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
			else
				unit.put("DateOfPurchase", "");

			dataReceipt.add(unit);
		}
		
		tableReceipt.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableReceipt.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Receipt", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableReceipt.setItems(dataReceipt);
		allObjectTables.put("Receipt", tableReceipt);
		
		TableView<Map<String, String>> tableSupplierOrder = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableSupplierOrder_SupplierOrderID = new TableColumn<Map<String, String>, String>("SupplierOrderID");
		tableSupplierOrder_SupplierOrderID.setMinWidth("SupplierOrderID".length()*10);
		tableSupplierOrder_SupplierOrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("SupplierOrderID"));
		    }
		});	
		tableSupplierOrder.getColumns().add(tableSupplierOrder_SupplierOrderID);
		TableColumn<Map<String, String>, String> tableSupplierOrder_SupplierID = new TableColumn<Map<String, String>, String>("SupplierID");
		tableSupplierOrder_SupplierID.setMinWidth("SupplierID".length()*10);
		tableSupplierOrder_SupplierID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("SupplierID"));
		    }
		});	
		tableSupplierOrder.getColumns().add(tableSupplierOrder_SupplierID);
		TableColumn<Map<String, String>, String> tableSupplierOrder_ProductsList = new TableColumn<Map<String, String>, String>("ProductsList");
		tableSupplierOrder_ProductsList.setMinWidth("ProductsList".length()*10);
		tableSupplierOrder_ProductsList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductsList"));
		    }
		});	
		tableSupplierOrder.getColumns().add(tableSupplierOrder_ProductsList);
		TableColumn<Map<String, String>, String> tableSupplierOrder_Status = new TableColumn<Map<String, String>, String>("Status");
		tableSupplierOrder_Status.setMinWidth("Status".length()*10);
		tableSupplierOrder_Status.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Status"));
		    }
		});	
		tableSupplierOrder.getColumns().add(tableSupplierOrder_Status);
		
		//table data
		ObservableList<Map<String, String>> dataSupplierOrder = FXCollections.observableArrayList();
		List<SupplierOrder> rsSupplierOrder = EntityManager.getAllInstancesOf("SupplierOrder");
		for (SupplierOrder r : rsSupplierOrder) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getSupplierOrderID() != null)
				unit.put("SupplierOrderID", String.valueOf(r.getSupplierOrderID()));
			else
				unit.put("SupplierOrderID", "");
			if (r.getSupplierID() != null)
				unit.put("SupplierID", String.valueOf(r.getSupplierID()));
			else
				unit.put("SupplierID", "");
			unit.put("ProductsList", String.valueOf(r.getProductsList()));
			if (r.getStatus() != null)
				unit.put("Status", String.valueOf(r.getStatus()));
			else
				unit.put("Status", "");

			dataSupplierOrder.add(unit);
		}
		
		tableSupplierOrder.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableSupplierOrder.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("SupplierOrder", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableSupplierOrder.setItems(dataSupplierOrder);
		allObjectTables.put("SupplierOrder", tableSupplierOrder);
		
		TableView<Map<String, String>> tableUsers = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableUsers_UserID = new TableColumn<Map<String, String>, String>("UserID");
		tableUsers_UserID.setMinWidth("UserID".length()*10);
		tableUsers_UserID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("UserID"));
		    }
		});	
		tableUsers.getColumns().add(tableUsers_UserID);
		TableColumn<Map<String, String>, String> tableUsers_UserName = new TableColumn<Map<String, String>, String>("UserName");
		tableUsers_UserName.setMinWidth("UserName".length()*10);
		tableUsers_UserName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("UserName"));
		    }
		});	
		tableUsers.getColumns().add(tableUsers_UserName);
		TableColumn<Map<String, String>, String> tableUsers_Password = new TableColumn<Map<String, String>, String>("Password");
		tableUsers_Password.setMinWidth("Password".length()*10);
		tableUsers_Password.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("Password"));
		    }
		});	
		tableUsers.getColumns().add(tableUsers_Password);
		
		//table data
		ObservableList<Map<String, String>> dataUsers = FXCollections.observableArrayList();
		List<Users> rsUsers = EntityManager.getAllInstancesOf("Users");
		for (Users r : rsUsers) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getUserID() != null)
				unit.put("UserID", String.valueOf(r.getUserID()));
			else
				unit.put("UserID", "");
			if (r.getUserName() != null)
				unit.put("UserName", String.valueOf(r.getUserName()));
			else
				unit.put("UserName", "");
			if (r.getPassword() != null)
				unit.put("Password", String.valueOf(r.getPassword()));
			else
				unit.put("Password", "");

			dataUsers.add(unit);
		}
		
		tableUsers.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableUsers.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Users", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableUsers.setItems(dataUsers);
		allObjectTables.put("Users", tableUsers);
		
		TableView<Map<String, String>> tableCart = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableCart_CartID = new TableColumn<Map<String, String>, String>("CartID");
		tableCart_CartID.setMinWidth("CartID".length()*10);
		tableCart_CartID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CartID"));
		    }
		});	
		tableCart.getColumns().add(tableCart_CartID);
		TableColumn<Map<String, String>, String> tableCart_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
		tableCart_ProductList.setMinWidth("ProductList".length()*10);
		tableCart_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
		    }
		});	
		tableCart.getColumns().add(tableCart_ProductList);
		TableColumn<Map<String, String>, String> tableCart_TotalAmount = new TableColumn<Map<String, String>, String>("TotalAmount");
		tableCart_TotalAmount.setMinWidth("TotalAmount".length()*10);
		tableCart_TotalAmount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TotalAmount"));
		    }
		});	
		tableCart.getColumns().add(tableCart_TotalAmount);
		TableColumn<Map<String, String>, String> tableCart_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
		tableCart_CustomerID.setMinWidth("CustomerID".length()*10);
		tableCart_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
		    }
		});	
		tableCart.getColumns().add(tableCart_CustomerID);
		TableColumn<Map<String, String>, String> tableCart_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
		tableCart_OrderID.setMinWidth("OrderID".length()*10);
		tableCart_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
		    }
		});	
		tableCart.getColumns().add(tableCart_OrderID);
		
		//table data
		ObservableList<Map<String, String>> dataCart = FXCollections.observableArrayList();
		List<Cart> rsCart = EntityManager.getAllInstancesOf("Cart");
		for (Cart r : rsCart) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getCartID() != null)
				unit.put("CartID", String.valueOf(r.getCartID()));
			else
				unit.put("CartID", "");
			unit.put("ProductList", String.valueOf(r.getProductList()));
			unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
			if (r.getCustomerID() != null)
				unit.put("CustomerID", String.valueOf(r.getCustomerID()));
			else
				unit.put("CustomerID", "");
			if (r.getOrderID() != null)
				unit.put("OrderID", String.valueOf(r.getOrderID()));
			else
				unit.put("OrderID", "");

			dataCart.add(unit);
		}
		
		tableCart.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableCart.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Cart", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableCart.setItems(dataCart);
		allObjectTables.put("Cart", tableCart);
		
		TableView<Map<String, String>> tableReturnedProducts = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableReturnedProducts_ReturnID = new TableColumn<Map<String, String>, String>("ReturnID");
		tableReturnedProducts_ReturnID.setMinWidth("ReturnID".length()*10);
		tableReturnedProducts_ReturnID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ReturnID"));
		    }
		});	
		tableReturnedProducts.getColumns().add(tableReturnedProducts_ReturnID);
		TableColumn<Map<String, String>, String> tableReturnedProducts_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
		tableReturnedProducts_CustomerID.setMinWidth("CustomerID".length()*10);
		tableReturnedProducts_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
		    }
		});	
		tableReturnedProducts.getColumns().add(tableReturnedProducts_CustomerID);
		TableColumn<Map<String, String>, String> tableReturnedProducts_ReasonOfReturn = new TableColumn<Map<String, String>, String>("ReasonOfReturn");
		tableReturnedProducts_ReasonOfReturn.setMinWidth("ReasonOfReturn".length()*10);
		tableReturnedProducts_ReasonOfReturn.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ReasonOfReturn"));
		    }
		});	
		tableReturnedProducts.getColumns().add(tableReturnedProducts_ReasonOfReturn);
		TableColumn<Map<String, String>, String> tableReturnedProducts_TransactionID = new TableColumn<Map<String, String>, String>("TransactionID");
		tableReturnedProducts_TransactionID.setMinWidth("TransactionID".length()*10);
		tableReturnedProducts_TransactionID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TransactionID"));
		    }
		});	
		tableReturnedProducts.getColumns().add(tableReturnedProducts_TransactionID);
		
		//table data
		ObservableList<Map<String, String>> dataReturnedProducts = FXCollections.observableArrayList();
		List<ReturnedProducts> rsReturnedProducts = EntityManager.getAllInstancesOf("ReturnedProducts");
		for (ReturnedProducts r : rsReturnedProducts) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getReturnID() != null)
				unit.put("ReturnID", String.valueOf(r.getReturnID()));
			else
				unit.put("ReturnID", "");
			if (r.getCustomerID() != null)
				unit.put("CustomerID", String.valueOf(r.getCustomerID()));
			else
				unit.put("CustomerID", "");
			if (r.getReasonOfReturn() != null)
				unit.put("ReasonOfReturn", String.valueOf(r.getReasonOfReturn()));
			else
				unit.put("ReasonOfReturn", "");
			if (r.getTransactionID() != null)
				unit.put("TransactionID", String.valueOf(r.getTransactionID()));
			else
				unit.put("TransactionID", "");

			dataReturnedProducts.add(unit);
		}
		
		tableReturnedProducts.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableReturnedProducts.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("ReturnedProducts", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableReturnedProducts.setItems(dataReturnedProducts);
		allObjectTables.put("ReturnedProducts", tableReturnedProducts);
		
		TableView<Map<String, String>> tableReport = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableReport_ReportID = new TableColumn<Map<String, String>, String>("ReportID");
		tableReport_ReportID.setMinWidth("ReportID".length()*10);
		tableReport_ReportID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ReportID"));
		    }
		});	
		tableReport.getColumns().add(tableReport_ReportID);
		TableColumn<Map<String, String>, String> tableReport_DateGenerated = new TableColumn<Map<String, String>, String>("DateGenerated");
		tableReport_DateGenerated.setMinWidth("DateGenerated".length()*10);
		tableReport_DateGenerated.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("DateGenerated"));
		    }
		});	
		tableReport.getColumns().add(tableReport_DateGenerated);
		TableColumn<Map<String, String>, String> tableReport_ReportResult = new TableColumn<Map<String, String>, String>("ReportResult");
		tableReport_ReportResult.setMinWidth("ReportResult".length()*10);
		tableReport_ReportResult.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ReportResult"));
		    }
		});	
		tableReport.getColumns().add(tableReport_ReportResult);
		TableColumn<Map<String, String>, String> tableReport_TypeOfReport = new TableColumn<Map<String, String>, String>("TypeOfReport");
		tableReport_TypeOfReport.setMinWidth("TypeOfReport".length()*10);
		tableReport_TypeOfReport.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("TypeOfReport"));
		    }
		});	
		tableReport.getColumns().add(tableReport_TypeOfReport);
		
		//table data
		ObservableList<Map<String, String>> dataReport = FXCollections.observableArrayList();
		List<Report> rsReport = EntityManager.getAllInstancesOf("Report");
		for (Report r : rsReport) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			if (r.getReportID() != null)
				unit.put("ReportID", String.valueOf(r.getReportID()));
			else
				unit.put("ReportID", "");
			if (r.getDateGenerated() != null)
				unit.put("DateGenerated", r.getDateGenerated().format(dateformatter));
			else
				unit.put("DateGenerated", "");
			if (r.getReportResult() != null)
				unit.put("ReportResult", String.valueOf(r.getReportResult()));
			else
				unit.put("ReportResult", "");
			if (r.getTypeOfReport() != null)
				unit.put("TypeOfReport", String.valueOf(r.getTypeOfReport()));
			else
				unit.put("TypeOfReport", "");

			dataReport.add(unit);
		}
		
		tableReport.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableReport.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("Report", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableReport.setItems(dataReport);
		allObjectTables.put("Report", tableReport);
		
		TableView<Map<String, String>> tableRestockProducts = new TableView<Map<String, String>>();

		//super entity attribute column
						
		//attributes table column
		TableColumn<Map<String, String>, String> tableRestockProducts_ProductsNeededList = new TableColumn<Map<String, String>, String>("ProductsNeededList");
		tableRestockProducts_ProductsNeededList.setMinWidth("ProductsNeededList".length()*10);
		tableRestockProducts_ProductsNeededList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("ProductsNeededList"));
		    }
		});	
		tableRestockProducts.getColumns().add(tableRestockProducts_ProductsNeededList);
		TableColumn<Map<String, String>, String> tableRestockProducts_RestockProductsID = new TableColumn<Map<String, String>, String>("RestockProductsID");
		tableRestockProducts_RestockProductsID.setMinWidth("RestockProductsID".length()*10);
		tableRestockProducts_RestockProductsID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
			@Override
		    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
		        return new ReadOnlyStringWrapper(data.getValue().get("RestockProductsID"));
		    }
		});	
		tableRestockProducts.getColumns().add(tableRestockProducts_RestockProductsID);
		
		//table data
		ObservableList<Map<String, String>> dataRestockProducts = FXCollections.observableArrayList();
		List<RestockProducts> rsRestockProducts = EntityManager.getAllInstancesOf("RestockProducts");
		for (RestockProducts r : rsRestockProducts) {
			//table entry
			Map<String, String> unit = new HashMap<String, String>();
			
			unit.put("ProductsNeededList", String.valueOf(r.getProductsNeededList()));
			if (r.getRestockProductsID() != null)
				unit.put("RestockProductsID", String.valueOf(r.getRestockProductsID()));
			else
				unit.put("RestockProductsID", "");

			dataRestockProducts.add(unit);
		}
		
		tableRestockProducts.getSelectionModel().selectedIndexProperty().addListener(
							 (observable, oldValue, newValue) ->  { 
							 										 //get selected index
							 										 objectindex = tableRestockProducts.getSelectionModel().getSelectedIndex();
							 			 				 			 System.out.println("select: " + objectindex);

							 			 				 			 //update association object information
							 			 				 			 if (objectindex != -1)
										 			 					 updateAssociation("RestockProducts", objectindex);
							 			 				 			 
							 			 				 		  });
		
		tableRestockProducts.setItems(dataRestockProducts);
		allObjectTables.put("RestockProducts", tableRestockProducts);
		

		
	}
	
	/* 
	* update all object tables with sub dataset
	*/ 
	public void updateCustomerTable(List<Customer> rsCustomer) {
			ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
			for (Customer r : rsCustomer) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getAddress() != null)
					unit.put("Address", String.valueOf(r.getAddress()));
				else
					unit.put("Address", "");
				unit.put("PhoneNumber", String.valueOf(r.getPhoneNumber()));
				if (r.getEmail() != null)
					unit.put("Email", String.valueOf(r.getEmail()));
				else
					unit.put("Email", "");
				dataCustomer.add(unit);
			}
			
			allObjectTables.get("Customer").setItems(dataCustomer);
	}
	public void updateMemberTable(List<Member> rsMember) {
			ObservableList<Map<String, String>> dataMember = FXCollections.observableArrayList();
			for (Member r : rsMember) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getMemberID() != null)
					unit.put("MemberID", String.valueOf(r.getMemberID()));
				else
					unit.put("MemberID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getTier() != null)
					unit.put("Tier", String.valueOf(r.getTier()));
				else
					unit.put("Tier", "");
				unit.put("LoyaltyPoints", String.valueOf(r.getLoyaltyPoints()));
				dataMember.add(unit);
			}
			
			allObjectTables.get("Member").setItems(dataMember);
	}
	public void updateCashierTable(List<Cashier> rsCashier) {
			ObservableList<Map<String, String>> dataCashier = FXCollections.observableArrayList();
			for (Cashier r : rsCashier) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getCashierID() != null)
					unit.put("CashierID", String.valueOf(r.getCashierID()));
				else
					unit.put("CashierID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				unit.put("EmployeeNumber", String.valueOf(r.getEmployeeNumber()));
				if (r.getBranch() != null)
					unit.put("Branch", String.valueOf(r.getBranch()));
				else
					unit.put("Branch", "");
				dataCashier.add(unit);
			}
			
			allObjectTables.get("Cashier").setItems(dataCashier);
	}
	public void updateStoreManagerTable(List<StoreManager> rsStoreManager) {
			ObservableList<Map<String, String>> dataStoreManager = FXCollections.observableArrayList();
			for (StoreManager r : rsStoreManager) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getStoreManagerID() != null)
					unit.put("StoreManagerID", String.valueOf(r.getStoreManagerID()));
				else
					unit.put("StoreManagerID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getBranch() != null)
					unit.put("Branch", String.valueOf(r.getBranch()));
				else
					unit.put("Branch", "");
				dataStoreManager.add(unit);
			}
			
			allObjectTables.get("StoreManager").setItems(dataStoreManager);
	}
	public void updateProductTable(List<Product> rsProduct) {
			ObservableList<Map<String, String>> dataProduct = FXCollections.observableArrayList();
			for (Product r : rsProduct) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getProductID() != null)
					unit.put("ProductID", String.valueOf(r.getProductID()));
				else
					unit.put("ProductID", "");
				if (r.getProductName() != null)
					unit.put("ProductName", String.valueOf(r.getProductName()));
				else
					unit.put("ProductName", "");
				unit.put("Price", String.valueOf(r.getPrice()));
				unit.put("StockLevel", String.valueOf(r.getStockLevel()));
				dataProduct.add(unit);
			}
			
			allObjectTables.get("Product").setItems(dataProduct);
	}
	public void updateSupplierTable(List<Supplier> rsSupplier) {
			ObservableList<Map<String, String>> dataSupplier = FXCollections.observableArrayList();
			for (Supplier r : rsSupplier) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getSupplierID() != null)
					unit.put("SupplierID", String.valueOf(r.getSupplierID()));
				else
					unit.put("SupplierID", "");
				if (r.getCompanyName() != null)
					unit.put("CompanyName", String.valueOf(r.getCompanyName()));
				else
					unit.put("CompanyName", "");
				if (r.getContactDetails() != null)
					unit.put("ContactDetails", String.valueOf(r.getContactDetails()));
				else
					unit.put("ContactDetails", "");
				dataSupplier.add(unit);
			}
			
			allObjectTables.get("Supplier").setItems(dataSupplier);
	}
	public void updateInventoryTable(List<Inventory> rsInventory) {
			ObservableList<Map<String, String>> dataInventory = FXCollections.observableArrayList();
			for (Inventory r : rsInventory) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getInventoryID() != null)
					unit.put("InventoryID", String.valueOf(r.getInventoryID()));
				else
					unit.put("InventoryID", "");
				unit.put("ProductList", String.valueOf(r.getProductList()));
				dataInventory.add(unit);
			}
			
			allObjectTables.get("Inventory").setItems(dataInventory);
	}
	public void updateOrderTable(List<Order> rsOrder) {
			ObservableList<Map<String, String>> dataOrder = FXCollections.observableArrayList();
			for (Order r : rsOrder) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				if (r.getDateOfPurchase() != null)
					unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
				else
					unit.put("DateOfPurchase", "");
				unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
				unit.put("ProductsList", String.valueOf(r.getProductsList()));
				dataOrder.add(unit);
			}
			
			allObjectTables.get("Order").setItems(dataOrder);
	}
	public void updateTransactionTable(List<Transaction> rsTransaction) {
			ObservableList<Map<String, String>> dataTransaction = FXCollections.observableArrayList();
			for (Transaction r : rsTransaction) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getTransactionID() != null)
					unit.put("TransactionID", String.valueOf(r.getTransactionID()));
				else
					unit.put("TransactionID", "");
				unit.put("Amount", String.valueOf(r.getAmount()));
				if (r.getPaymentMethod() != null)
					unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
				else
					unit.put("PaymentMethod", "");
				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				dataTransaction.add(unit);
			}
			
			allObjectTables.get("Transaction").setItems(dataTransaction);
	}
	public void updateFeedbackTable(List<Feedback> rsFeedback) {
			ObservableList<Map<String, String>> dataFeedback = FXCollections.observableArrayList();
			for (Feedback r : rsFeedback) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getFeedbackID() != null)
					unit.put("FeedbackID", String.valueOf(r.getFeedbackID()));
				else
					unit.put("FeedbackID", "");
				if (r.getFeedbackContent() != null)
					unit.put("FeedbackContent", String.valueOf(r.getFeedbackContent()));
				else
					unit.put("FeedbackContent", "");
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				dataFeedback.add(unit);
			}
			
			allObjectTables.get("Feedback").setItems(dataFeedback);
	}
	public void updateReceiptTable(List<Receipt> rsReceipt) {
			ObservableList<Map<String, String>> dataReceipt = FXCollections.observableArrayList();
			for (Receipt r : rsReceipt) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getReceiptID() != null)
					unit.put("ReceiptID", String.valueOf(r.getReceiptID()));
				else
					unit.put("ReceiptID", "");
				if (r.getPaymentMethod() != null)
					unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
				else
					unit.put("PaymentMethod", "");
				unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
				unit.put("ProductList", String.valueOf(r.getProductList()));
				if (r.getDateOfPurchase() != null)
					unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
				else
					unit.put("DateOfPurchase", "");
				dataReceipt.add(unit);
			}
			
			allObjectTables.get("Receipt").setItems(dataReceipt);
	}
	public void updateSupplierOrderTable(List<SupplierOrder> rsSupplierOrder) {
			ObservableList<Map<String, String>> dataSupplierOrder = FXCollections.observableArrayList();
			for (SupplierOrder r : rsSupplierOrder) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getSupplierOrderID() != null)
					unit.put("SupplierOrderID", String.valueOf(r.getSupplierOrderID()));
				else
					unit.put("SupplierOrderID", "");
				if (r.getSupplierID() != null)
					unit.put("SupplierID", String.valueOf(r.getSupplierID()));
				else
					unit.put("SupplierID", "");
				unit.put("ProductsList", String.valueOf(r.getProductsList()));
				if (r.getStatus() != null)
					unit.put("Status", String.valueOf(r.getStatus()));
				else
					unit.put("Status", "");
				dataSupplierOrder.add(unit);
			}
			
			allObjectTables.get("SupplierOrder").setItems(dataSupplierOrder);
	}
	public void updateUsersTable(List<Users> rsUsers) {
			ObservableList<Map<String, String>> dataUsers = FXCollections.observableArrayList();
			for (Users r : rsUsers) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getUserID() != null)
					unit.put("UserID", String.valueOf(r.getUserID()));
				else
					unit.put("UserID", "");
				if (r.getUserName() != null)
					unit.put("UserName", String.valueOf(r.getUserName()));
				else
					unit.put("UserName", "");
				if (r.getPassword() != null)
					unit.put("Password", String.valueOf(r.getPassword()));
				else
					unit.put("Password", "");
				dataUsers.add(unit);
			}
			
			allObjectTables.get("Users").setItems(dataUsers);
	}
	public void updateCartTable(List<Cart> rsCart) {
			ObservableList<Map<String, String>> dataCart = FXCollections.observableArrayList();
			for (Cart r : rsCart) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getCartID() != null)
					unit.put("CartID", String.valueOf(r.getCartID()));
				else
					unit.put("CartID", "");
				unit.put("ProductList", String.valueOf(r.getProductList()));
				unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				dataCart.add(unit);
			}
			
			allObjectTables.get("Cart").setItems(dataCart);
	}
	public void updateReturnedProductsTable(List<ReturnedProducts> rsReturnedProducts) {
			ObservableList<Map<String, String>> dataReturnedProducts = FXCollections.observableArrayList();
			for (ReturnedProducts r : rsReturnedProducts) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getReturnID() != null)
					unit.put("ReturnID", String.valueOf(r.getReturnID()));
				else
					unit.put("ReturnID", "");
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getReasonOfReturn() != null)
					unit.put("ReasonOfReturn", String.valueOf(r.getReasonOfReturn()));
				else
					unit.put("ReasonOfReturn", "");
				if (r.getTransactionID() != null)
					unit.put("TransactionID", String.valueOf(r.getTransactionID()));
				else
					unit.put("TransactionID", "");
				dataReturnedProducts.add(unit);
			}
			
			allObjectTables.get("ReturnedProducts").setItems(dataReturnedProducts);
	}
	public void updateReportTable(List<Report> rsReport) {
			ObservableList<Map<String, String>> dataReport = FXCollections.observableArrayList();
			for (Report r : rsReport) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				if (r.getReportID() != null)
					unit.put("ReportID", String.valueOf(r.getReportID()));
				else
					unit.put("ReportID", "");
				if (r.getDateGenerated() != null)
					unit.put("DateGenerated", r.getDateGenerated().format(dateformatter));
				else
					unit.put("DateGenerated", "");
				if (r.getReportResult() != null)
					unit.put("ReportResult", String.valueOf(r.getReportResult()));
				else
					unit.put("ReportResult", "");
				if (r.getTypeOfReport() != null)
					unit.put("TypeOfReport", String.valueOf(r.getTypeOfReport()));
				else
					unit.put("TypeOfReport", "");
				dataReport.add(unit);
			}
			
			allObjectTables.get("Report").setItems(dataReport);
	}
	public void updateRestockProductsTable(List<RestockProducts> rsRestockProducts) {
			ObservableList<Map<String, String>> dataRestockProducts = FXCollections.observableArrayList();
			for (RestockProducts r : rsRestockProducts) {
				Map<String, String> unit = new HashMap<String, String>();
				
				
				unit.put("ProductsNeededList", String.valueOf(r.getProductsNeededList()));
				if (r.getRestockProductsID() != null)
					unit.put("RestockProductsID", String.valueOf(r.getRestockProductsID()));
				else
					unit.put("RestockProductsID", "");
				dataRestockProducts.add(unit);
			}
			
			allObjectTables.get("RestockProducts").setItems(dataRestockProducts);
	}
	
	/* 
	* update all object tables
	*/ 
	public void updateCustomerTable() {
			ObservableList<Map<String, String>> dataCustomer = FXCollections.observableArrayList();
			List<Customer> rsCustomer = EntityManager.getAllInstancesOf("Customer");
			for (Customer r : rsCustomer) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getAddress() != null)
					unit.put("Address", String.valueOf(r.getAddress()));
				else
					unit.put("Address", "");
				unit.put("PhoneNumber", String.valueOf(r.getPhoneNumber()));
				if (r.getEmail() != null)
					unit.put("Email", String.valueOf(r.getEmail()));
				else
					unit.put("Email", "");
				dataCustomer.add(unit);
			}
			
			allObjectTables.get("Customer").setItems(dataCustomer);
	}
	public void updateMemberTable() {
			ObservableList<Map<String, String>> dataMember = FXCollections.observableArrayList();
			List<Member> rsMember = EntityManager.getAllInstancesOf("Member");
			for (Member r : rsMember) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getMemberID() != null)
					unit.put("MemberID", String.valueOf(r.getMemberID()));
				else
					unit.put("MemberID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getTier() != null)
					unit.put("Tier", String.valueOf(r.getTier()));
				else
					unit.put("Tier", "");
				unit.put("LoyaltyPoints", String.valueOf(r.getLoyaltyPoints()));
				dataMember.add(unit);
			}
			
			allObjectTables.get("Member").setItems(dataMember);
	}
	public void updateCashierTable() {
			ObservableList<Map<String, String>> dataCashier = FXCollections.observableArrayList();
			List<Cashier> rsCashier = EntityManager.getAllInstancesOf("Cashier");
			for (Cashier r : rsCashier) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getCashierID() != null)
					unit.put("CashierID", String.valueOf(r.getCashierID()));
				else
					unit.put("CashierID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				unit.put("EmployeeNumber", String.valueOf(r.getEmployeeNumber()));
				if (r.getBranch() != null)
					unit.put("Branch", String.valueOf(r.getBranch()));
				else
					unit.put("Branch", "");
				dataCashier.add(unit);
			}
			
			allObjectTables.get("Cashier").setItems(dataCashier);
	}
	public void updateStoreManagerTable() {
			ObservableList<Map<String, String>> dataStoreManager = FXCollections.observableArrayList();
			List<StoreManager> rsStoreManager = EntityManager.getAllInstancesOf("StoreManager");
			for (StoreManager r : rsStoreManager) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getStoreManagerID() != null)
					unit.put("StoreManagerID", String.valueOf(r.getStoreManagerID()));
				else
					unit.put("StoreManagerID", "");
				if (r.getFullName() != null)
					unit.put("FullName", String.valueOf(r.getFullName()));
				else
					unit.put("FullName", "");
				if (r.getBranch() != null)
					unit.put("Branch", String.valueOf(r.getBranch()));
				else
					unit.put("Branch", "");
				dataStoreManager.add(unit);
			}
			
			allObjectTables.get("StoreManager").setItems(dataStoreManager);
	}
	public void updateProductTable() {
			ObservableList<Map<String, String>> dataProduct = FXCollections.observableArrayList();
			List<Product> rsProduct = EntityManager.getAllInstancesOf("Product");
			for (Product r : rsProduct) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getProductID() != null)
					unit.put("ProductID", String.valueOf(r.getProductID()));
				else
					unit.put("ProductID", "");
				if (r.getProductName() != null)
					unit.put("ProductName", String.valueOf(r.getProductName()));
				else
					unit.put("ProductName", "");
				unit.put("Price", String.valueOf(r.getPrice()));
				unit.put("StockLevel", String.valueOf(r.getStockLevel()));
				dataProduct.add(unit);
			}
			
			allObjectTables.get("Product").setItems(dataProduct);
	}
	public void updateSupplierTable() {
			ObservableList<Map<String, String>> dataSupplier = FXCollections.observableArrayList();
			List<Supplier> rsSupplier = EntityManager.getAllInstancesOf("Supplier");
			for (Supplier r : rsSupplier) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getSupplierID() != null)
					unit.put("SupplierID", String.valueOf(r.getSupplierID()));
				else
					unit.put("SupplierID", "");
				if (r.getCompanyName() != null)
					unit.put("CompanyName", String.valueOf(r.getCompanyName()));
				else
					unit.put("CompanyName", "");
				if (r.getContactDetails() != null)
					unit.put("ContactDetails", String.valueOf(r.getContactDetails()));
				else
					unit.put("ContactDetails", "");
				dataSupplier.add(unit);
			}
			
			allObjectTables.get("Supplier").setItems(dataSupplier);
	}
	public void updateInventoryTable() {
			ObservableList<Map<String, String>> dataInventory = FXCollections.observableArrayList();
			List<Inventory> rsInventory = EntityManager.getAllInstancesOf("Inventory");
			for (Inventory r : rsInventory) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getInventoryID() != null)
					unit.put("InventoryID", String.valueOf(r.getInventoryID()));
				else
					unit.put("InventoryID", "");
				unit.put("ProductList", String.valueOf(r.getProductList()));
				dataInventory.add(unit);
			}
			
			allObjectTables.get("Inventory").setItems(dataInventory);
	}
	public void updateOrderTable() {
			ObservableList<Map<String, String>> dataOrder = FXCollections.observableArrayList();
			List<Order> rsOrder = EntityManager.getAllInstancesOf("Order");
			for (Order r : rsOrder) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				if (r.getDateOfPurchase() != null)
					unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
				else
					unit.put("DateOfPurchase", "");
				unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
				unit.put("ProductsList", String.valueOf(r.getProductsList()));
				dataOrder.add(unit);
			}
			
			allObjectTables.get("Order").setItems(dataOrder);
	}
	public void updateTransactionTable() {
			ObservableList<Map<String, String>> dataTransaction = FXCollections.observableArrayList();
			List<Transaction> rsTransaction = EntityManager.getAllInstancesOf("Transaction");
			for (Transaction r : rsTransaction) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getTransactionID() != null)
					unit.put("TransactionID", String.valueOf(r.getTransactionID()));
				else
					unit.put("TransactionID", "");
				unit.put("Amount", String.valueOf(r.getAmount()));
				if (r.getPaymentMethod() != null)
					unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
				else
					unit.put("PaymentMethod", "");
				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				dataTransaction.add(unit);
			}
			
			allObjectTables.get("Transaction").setItems(dataTransaction);
	}
	public void updateFeedbackTable() {
			ObservableList<Map<String, String>> dataFeedback = FXCollections.observableArrayList();
			List<Feedback> rsFeedback = EntityManager.getAllInstancesOf("Feedback");
			for (Feedback r : rsFeedback) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getFeedbackID() != null)
					unit.put("FeedbackID", String.valueOf(r.getFeedbackID()));
				else
					unit.put("FeedbackID", "");
				if (r.getFeedbackContent() != null)
					unit.put("FeedbackContent", String.valueOf(r.getFeedbackContent()));
				else
					unit.put("FeedbackContent", "");
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				dataFeedback.add(unit);
			}
			
			allObjectTables.get("Feedback").setItems(dataFeedback);
	}
	public void updateReceiptTable() {
			ObservableList<Map<String, String>> dataReceipt = FXCollections.observableArrayList();
			List<Receipt> rsReceipt = EntityManager.getAllInstancesOf("Receipt");
			for (Receipt r : rsReceipt) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getReceiptID() != null)
					unit.put("ReceiptID", String.valueOf(r.getReceiptID()));
				else
					unit.put("ReceiptID", "");
				if (r.getPaymentMethod() != null)
					unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
				else
					unit.put("PaymentMethod", "");
				unit.put("TotalPrice", String.valueOf(r.getTotalPrice()));
				unit.put("ProductList", String.valueOf(r.getProductList()));
				if (r.getDateOfPurchase() != null)
					unit.put("DateOfPurchase", r.getDateOfPurchase().format(dateformatter));
				else
					unit.put("DateOfPurchase", "");
				dataReceipt.add(unit);
			}
			
			allObjectTables.get("Receipt").setItems(dataReceipt);
	}
	public void updateSupplierOrderTable() {
			ObservableList<Map<String, String>> dataSupplierOrder = FXCollections.observableArrayList();
			List<SupplierOrder> rsSupplierOrder = EntityManager.getAllInstancesOf("SupplierOrder");
			for (SupplierOrder r : rsSupplierOrder) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getSupplierOrderID() != null)
					unit.put("SupplierOrderID", String.valueOf(r.getSupplierOrderID()));
				else
					unit.put("SupplierOrderID", "");
				if (r.getSupplierID() != null)
					unit.put("SupplierID", String.valueOf(r.getSupplierID()));
				else
					unit.put("SupplierID", "");
				unit.put("ProductsList", String.valueOf(r.getProductsList()));
				if (r.getStatus() != null)
					unit.put("Status", String.valueOf(r.getStatus()));
				else
					unit.put("Status", "");
				dataSupplierOrder.add(unit);
			}
			
			allObjectTables.get("SupplierOrder").setItems(dataSupplierOrder);
	}
	public void updateUsersTable() {
			ObservableList<Map<String, String>> dataUsers = FXCollections.observableArrayList();
			List<Users> rsUsers = EntityManager.getAllInstancesOf("Users");
			for (Users r : rsUsers) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getUserID() != null)
					unit.put("UserID", String.valueOf(r.getUserID()));
				else
					unit.put("UserID", "");
				if (r.getUserName() != null)
					unit.put("UserName", String.valueOf(r.getUserName()));
				else
					unit.put("UserName", "");
				if (r.getPassword() != null)
					unit.put("Password", String.valueOf(r.getPassword()));
				else
					unit.put("Password", "");
				dataUsers.add(unit);
			}
			
			allObjectTables.get("Users").setItems(dataUsers);
	}
	public void updateCartTable() {
			ObservableList<Map<String, String>> dataCart = FXCollections.observableArrayList();
			List<Cart> rsCart = EntityManager.getAllInstancesOf("Cart");
			for (Cart r : rsCart) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getCartID() != null)
					unit.put("CartID", String.valueOf(r.getCartID()));
				else
					unit.put("CartID", "");
				unit.put("ProductList", String.valueOf(r.getProductList()));
				unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getOrderID() != null)
					unit.put("OrderID", String.valueOf(r.getOrderID()));
				else
					unit.put("OrderID", "");
				dataCart.add(unit);
			}
			
			allObjectTables.get("Cart").setItems(dataCart);
	}
	public void updateReturnedProductsTable() {
			ObservableList<Map<String, String>> dataReturnedProducts = FXCollections.observableArrayList();
			List<ReturnedProducts> rsReturnedProducts = EntityManager.getAllInstancesOf("ReturnedProducts");
			for (ReturnedProducts r : rsReturnedProducts) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getReturnID() != null)
					unit.put("ReturnID", String.valueOf(r.getReturnID()));
				else
					unit.put("ReturnID", "");
				if (r.getCustomerID() != null)
					unit.put("CustomerID", String.valueOf(r.getCustomerID()));
				else
					unit.put("CustomerID", "");
				if (r.getReasonOfReturn() != null)
					unit.put("ReasonOfReturn", String.valueOf(r.getReasonOfReturn()));
				else
					unit.put("ReasonOfReturn", "");
				if (r.getTransactionID() != null)
					unit.put("TransactionID", String.valueOf(r.getTransactionID()));
				else
					unit.put("TransactionID", "");
				dataReturnedProducts.add(unit);
			}
			
			allObjectTables.get("ReturnedProducts").setItems(dataReturnedProducts);
	}
	public void updateReportTable() {
			ObservableList<Map<String, String>> dataReport = FXCollections.observableArrayList();
			List<Report> rsReport = EntityManager.getAllInstancesOf("Report");
			for (Report r : rsReport) {
				Map<String, String> unit = new HashMap<String, String>();


				if (r.getReportID() != null)
					unit.put("ReportID", String.valueOf(r.getReportID()));
				else
					unit.put("ReportID", "");
				if (r.getDateGenerated() != null)
					unit.put("DateGenerated", r.getDateGenerated().format(dateformatter));
				else
					unit.put("DateGenerated", "");
				if (r.getReportResult() != null)
					unit.put("ReportResult", String.valueOf(r.getReportResult()));
				else
					unit.put("ReportResult", "");
				if (r.getTypeOfReport() != null)
					unit.put("TypeOfReport", String.valueOf(r.getTypeOfReport()));
				else
					unit.put("TypeOfReport", "");
				dataReport.add(unit);
			}
			
			allObjectTables.get("Report").setItems(dataReport);
	}
	public void updateRestockProductsTable() {
			ObservableList<Map<String, String>> dataRestockProducts = FXCollections.observableArrayList();
			List<RestockProducts> rsRestockProducts = EntityManager.getAllInstancesOf("RestockProducts");
			for (RestockProducts r : rsRestockProducts) {
				Map<String, String> unit = new HashMap<String, String>();


				unit.put("ProductsNeededList", String.valueOf(r.getProductsNeededList()));
				if (r.getRestockProductsID() != null)
					unit.put("RestockProductsID", String.valueOf(r.getRestockProductsID()));
				else
					unit.put("RestockProductsID", "");
				dataRestockProducts.add(unit);
			}
			
			allObjectTables.get("RestockProducts").setItems(dataRestockProducts);
	}
	
	public void classStatisicBingding() {
	
		 classInfodata = FXCollections.observableArrayList();
	 	 customer = new ClassInfo("Customer", EntityManager.getAllInstancesOf("Customer").size());
	 	 classInfodata.add(customer);
	 	 member = new ClassInfo("Member", EntityManager.getAllInstancesOf("Member").size());
	 	 classInfodata.add(member);
	 	 cashier = new ClassInfo("Cashier", EntityManager.getAllInstancesOf("Cashier").size());
	 	 classInfodata.add(cashier);
	 	 storemanager = new ClassInfo("StoreManager", EntityManager.getAllInstancesOf("StoreManager").size());
	 	 classInfodata.add(storemanager);
	 	 product = new ClassInfo("Product", EntityManager.getAllInstancesOf("Product").size());
	 	 classInfodata.add(product);
	 	 supplier = new ClassInfo("Supplier", EntityManager.getAllInstancesOf("Supplier").size());
	 	 classInfodata.add(supplier);
	 	 inventory = new ClassInfo("Inventory", EntityManager.getAllInstancesOf("Inventory").size());
	 	 classInfodata.add(inventory);
	 	 order = new ClassInfo("Order", EntityManager.getAllInstancesOf("Order").size());
	 	 classInfodata.add(order);
	 	 transaction = new ClassInfo("Transaction", EntityManager.getAllInstancesOf("Transaction").size());
	 	 classInfodata.add(transaction);
	 	 feedback = new ClassInfo("Feedback", EntityManager.getAllInstancesOf("Feedback").size());
	 	 classInfodata.add(feedback);
	 	 receipt = new ClassInfo("Receipt", EntityManager.getAllInstancesOf("Receipt").size());
	 	 classInfodata.add(receipt);
	 	 supplierorder = new ClassInfo("SupplierOrder", EntityManager.getAllInstancesOf("SupplierOrder").size());
	 	 classInfodata.add(supplierorder);
	 	 users = new ClassInfo("Users", EntityManager.getAllInstancesOf("Users").size());
	 	 classInfodata.add(users);
	 	 cart = new ClassInfo("Cart", EntityManager.getAllInstancesOf("Cart").size());
	 	 classInfodata.add(cart);
	 	 returnedproducts = new ClassInfo("ReturnedProducts", EntityManager.getAllInstancesOf("ReturnedProducts").size());
	 	 classInfodata.add(returnedproducts);
	 	 report = new ClassInfo("Report", EntityManager.getAllInstancesOf("Report").size());
	 	 classInfodata.add(report);
	 	 restockproducts = new ClassInfo("RestockProducts", EntityManager.getAllInstancesOf("RestockProducts").size());
	 	 classInfodata.add(restockproducts);
	 	 
		 class_statisic.setItems(classInfodata);
		 
		 //Class Statisic Binding
		 class_statisic.getSelectionModel().selectedItemProperty().addListener(
				 (observable, oldValue, newValue) ->  { 
				 										 //no selected object in table
				 										 objectindex = -1;
				 										 
				 										 //get lastest data, reflect updateTableData method
				 										 try {
												 			 Method updateob = this.getClass().getMethod("update" + newValue.getName() + "Table", null);
												 			 updateob.invoke(this);			 
												 		 } catch (Exception e) {
												 		 	 e.printStackTrace();
												 		 }		 										 
				 	
				 										 //show object table
				 			 				 			 TableView obs = allObjectTables.get(newValue.getName());
				 			 				 			 if (obs != null) {
				 			 				 				object_statics.setContent(obs);
				 			 				 				object_statics.setText("All Objects " + newValue.getName() + ":");
				 			 				 			 }
				 			 				 			 
				 			 				 			 //update association information
							 			 				 updateAssociation(newValue.getName());
				 			 				 			 
				 			 				 			 //show association information
				 			 				 			 ObservableList<AssociationInfo> asso = allassociationData.get(newValue.getName());
				 			 				 			 if (asso != null) {
				 			 				 			 	association_statisic.setItems(asso);
				 			 				 			 }
				 			 				 		  });
	}
	
	public void classStatisticUpdate() {
	 	 customer.setNumber(EntityManager.getAllInstancesOf("Customer").size());
	 	 member.setNumber(EntityManager.getAllInstancesOf("Member").size());
	 	 cashier.setNumber(EntityManager.getAllInstancesOf("Cashier").size());
	 	 storemanager.setNumber(EntityManager.getAllInstancesOf("StoreManager").size());
	 	 product.setNumber(EntityManager.getAllInstancesOf("Product").size());
	 	 supplier.setNumber(EntityManager.getAllInstancesOf("Supplier").size());
	 	 inventory.setNumber(EntityManager.getAllInstancesOf("Inventory").size());
	 	 order.setNumber(EntityManager.getAllInstancesOf("Order").size());
	 	 transaction.setNumber(EntityManager.getAllInstancesOf("Transaction").size());
	 	 feedback.setNumber(EntityManager.getAllInstancesOf("Feedback").size());
	 	 receipt.setNumber(EntityManager.getAllInstancesOf("Receipt").size());
	 	 supplierorder.setNumber(EntityManager.getAllInstancesOf("SupplierOrder").size());
	 	 users.setNumber(EntityManager.getAllInstancesOf("Users").size());
	 	 cart.setNumber(EntityManager.getAllInstancesOf("Cart").size());
	 	 returnedproducts.setNumber(EntityManager.getAllInstancesOf("ReturnedProducts").size());
	 	 report.setNumber(EntityManager.getAllInstancesOf("Report").size());
	 	 restockproducts.setNumber(EntityManager.getAllInstancesOf("RestockProducts").size());
		
	}
	
	/**
	 * association binding
	 */
	public void associationStatisicBingding() {
		
		allassociationData = new HashMap<String, ObservableList<AssociationInfo>>();
		
		ObservableList<AssociationInfo> Customer_association_data = FXCollections.observableArrayList();
		AssociationInfo Customer_associatition_Becomes = new AssociationInfo("Customer", "Member", "Becomes", false);
		Customer_association_data.add(Customer_associatition_Becomes);
		AssociationInfo Customer_associatition_Make = new AssociationInfo("Customer", "Order", "Make", false);
		Customer_association_data.add(Customer_associatition_Make);
		AssociationInfo Customer_associatition_Are = new AssociationInfo("Customer", "Users", "Are", false);
		Customer_association_data.add(Customer_associatition_Are);
		AssociationInfo Customer_associatition_Suggest = new AssociationInfo("Customer", "Feedback", "Suggest", false);
		Customer_association_data.add(Customer_associatition_Suggest);
		AssociationInfo Customer_associatition_ReturnedBy = new AssociationInfo("Customer", "ReturnedProducts", "ReturnedBy", false);
		Customer_association_data.add(Customer_associatition_ReturnedBy);
		AssociationInfo Customer_associatition_CanBeProcessedBy = new AssociationInfo("Customer", "Transaction", "CanBeProcessedBy", false);
		Customer_association_data.add(Customer_associatition_CanBeProcessedBy);
		
		allassociationData.put("Customer", Customer_association_data);
		
		ObservableList<AssociationInfo> Member_association_data = FXCollections.observableArrayList();
		AssociationInfo Member_associatition_Is = new AssociationInfo("Member", "Customer", "Is", false);
		Member_association_data.add(Member_associatition_Is);
		AssociationInfo Member_associatition_BelongTo = new AssociationInfo("Member", "Users", "BelongTo", false);
		Member_association_data.add(Member_associatition_BelongTo);
		
		allassociationData.put("Member", Member_association_data);
		
		ObservableList<AssociationInfo> Cashier_association_data = FXCollections.observableArrayList();
		AssociationInfo Cashier_associatition_CheckedOutBy = new AssociationInfo("Cashier", "Order", "CheckedOutBy", true);
		Cashier_association_data.add(Cashier_associatition_CheckedOutBy);
		AssociationInfo Cashier_associatition_Process = new AssociationInfo("Cashier", "Transaction", "Process", true);
		Cashier_association_data.add(Cashier_associatition_Process);
		AssociationInfo Cashier_associatition_Provides = new AssociationInfo("Cashier", "Receipt", "Provides", true);
		Cashier_association_data.add(Cashier_associatition_Provides);
		AssociationInfo Cashier_associatition_RepresentedBy = new AssociationInfo("Cashier", "Users", "RepresentedBy", false);
		Cashier_association_data.add(Cashier_associatition_RepresentedBy);
		
		allassociationData.put("Cashier", Cashier_association_data);
		
		ObservableList<AssociationInfo> StoreManager_association_data = FXCollections.observableArrayList();
		AssociationInfo StoreManager_associatition_Manages = new AssociationInfo("StoreManager", "Inventory", "Manages", false);
		StoreManager_association_data.add(StoreManager_associatition_Manages);
		AssociationInfo StoreManager_associatition_Accessed = new AssociationInfo("StoreManager", "Feedback", "Accessed", true);
		StoreManager_association_data.add(StoreManager_associatition_Accessed);
		AssociationInfo StoreManager_associatition_Is = new AssociationInfo("StoreManager", "Users", "Is", false);
		StoreManager_association_data.add(StoreManager_associatition_Is);
		AssociationInfo StoreManager_associatition_GeneratedBy = new AssociationInfo("StoreManager", "Report", "GeneratedBy", true);
		StoreManager_association_data.add(StoreManager_associatition_GeneratedBy);
		AssociationInfo StoreManager_associatition_DoneBy = new AssociationInfo("StoreManager", "RestockProducts", "DoneBy", false);
		StoreManager_association_data.add(StoreManager_associatition_DoneBy);
		
		allassociationData.put("StoreManager", StoreManager_association_data);
		
		ObservableList<AssociationInfo> Product_association_data = FXCollections.observableArrayList();
		AssociationInfo Product_associatition_In = new AssociationInfo("Product", "Order", "In", false);
		Product_association_data.add(Product_associatition_In);
		AssociationInfo Product_associatition_StoredIn = new AssociationInfo("Product", "Inventory", "StoredIn", false);
		Product_association_data.add(Product_associatition_StoredIn);
		
		allassociationData.put("Product", Product_association_data);
		
		ObservableList<AssociationInfo> Supplier_association_data = FXCollections.observableArrayList();
		AssociationInfo Supplier_associatition_FulfilledBy = new AssociationInfo("Supplier", "SupplierOrder", "FulfilledBy", true);
		Supplier_association_data.add(Supplier_associatition_FulfilledBy);
		AssociationInfo Supplier_associatition_MayBe = new AssociationInfo("Supplier", "Users", "MayBe", false);
		Supplier_association_data.add(Supplier_associatition_MayBe);
		
		allassociationData.put("Supplier", Supplier_association_data);
		
		ObservableList<AssociationInfo> Inventory_association_data = FXCollections.observableArrayList();
		AssociationInfo Inventory_associatition_Contains = new AssociationInfo("Inventory", "Product", "Contains", true);
		Inventory_association_data.add(Inventory_associatition_Contains);
		AssociationInfo Inventory_associatition_ManangedBy = new AssociationInfo("Inventory", "StoreManager", "ManangedBy", false);
		Inventory_association_data.add(Inventory_associatition_ManangedBy);
		AssociationInfo Inventory_associatition_SuppliedBy = new AssociationInfo("Inventory", "SupplierOrder", "SuppliedBy", true);
		Inventory_association_data.add(Inventory_associatition_SuppliedBy);
		
		allassociationData.put("Inventory", Inventory_association_data);
		
		ObservableList<AssociationInfo> Order_association_data = FXCollections.observableArrayList();
		AssociationInfo Order_associatition_MadeBY = new AssociationInfo("Order", "Customer", "MadeBY", false);
		Order_association_data.add(Order_associatition_MadeBY);
		AssociationInfo Order_associatition_Accomedate = new AssociationInfo("Order", "Product", "Accomedate", true);
		Order_association_data.add(Order_associatition_Accomedate);
		AssociationInfo Order_associatition_CheckOut = new AssociationInfo("Order", "Cashier", "CheckOut", false);
		Order_association_data.add(Order_associatition_CheckOut);
		AssociationInfo Order_associatition_HasIn = new AssociationInfo("Order", "Cart", "HasIn", false);
		Order_association_data.add(Order_associatition_HasIn);
		
		allassociationData.put("Order", Order_association_data);
		
		ObservableList<AssociationInfo> Transaction_association_data = FXCollections.observableArrayList();
		AssociationInfo Transaction_associatition_ProcessedBy = new AssociationInfo("Transaction", "Cashier", "ProcessedBy", false);
		Transaction_association_data.add(Transaction_associatition_ProcessedBy);
		AssociationInfo Transaction_associatition_CanProcess = new AssociationInfo("Transaction", "Customer", "CanProcess", false);
		Transaction_association_data.add(Transaction_associatition_CanProcess);
		AssociationInfo Transaction_associatition_ProvidedWithin = new AssociationInfo("Transaction", "Receipt", "ProvidedWithin", false);
		Transaction_association_data.add(Transaction_associatition_ProvidedWithin);
		
		allassociationData.put("Transaction", Transaction_association_data);
		
		ObservableList<AssociationInfo> Feedback_association_data = FXCollections.observableArrayList();
		AssociationInfo Feedback_associatition_Accesses = new AssociationInfo("Feedback", "StoreManager", "Accesses", false);
		Feedback_association_data.add(Feedback_associatition_Accesses);
		AssociationInfo Feedback_associatition_Provide = new AssociationInfo("Feedback", "Customer", "Provide", true);
		Feedback_association_data.add(Feedback_associatition_Provide);
		
		allassociationData.put("Feedback", Feedback_association_data);
		
		ObservableList<AssociationInfo> Receipt_association_data = FXCollections.observableArrayList();
		AssociationInfo Receipt_associatition_ProvidedBy = new AssociationInfo("Receipt", "Cashier", "ProvidedBy", false);
		Receipt_association_data.add(Receipt_associatition_ProvidedBy);
		AssociationInfo Receipt_associatition_MustHave = new AssociationInfo("Receipt", "Transaction", "MustHave", false);
		Receipt_association_data.add(Receipt_associatition_MustHave);
		
		allassociationData.put("Receipt", Receipt_association_data);
		
		ObservableList<AssociationInfo> SupplierOrder_association_data = FXCollections.observableArrayList();
		AssociationInfo SupplierOrder_associatition_Fulfill = new AssociationInfo("SupplierOrder", "Supplier", "Fulfill", false);
		SupplierOrder_association_data.add(SupplierOrder_associatition_Fulfill);
		AssociationInfo SupplierOrder_associatition_Supplies = new AssociationInfo("SupplierOrder", "Inventory", "Supplies", false);
		SupplierOrder_association_data.add(SupplierOrder_associatition_Supplies);
		
		allassociationData.put("SupplierOrder", SupplierOrder_association_data);
		
		ObservableList<AssociationInfo> Users_association_data = FXCollections.observableArrayList();
		AssociationInfo Users_associatition_CanBe = new AssociationInfo("Users", "StoreManager", "CanBe", false);
		Users_association_data.add(Users_associatition_CanBe);
		AssociationInfo Users_associatition_IsA = new AssociationInfo("Users", "Supplier", "IsA", false);
		Users_association_data.add(Users_associatition_IsA);
		AssociationInfo Users_associatition_Represents = new AssociationInfo("Users", "Cashier", "Represents", false);
		Users_association_data.add(Users_associatition_Represents);
		AssociationInfo Users_associatition_RelatedTo = new AssociationInfo("Users", "Customer", "RelatedTo", false);
		Users_association_data.add(Users_associatition_RelatedTo);
		AssociationInfo Users_associatition_MustBeAlso = new AssociationInfo("Users", "Member", "MustBeAlso", false);
		Users_association_data.add(Users_associatition_MustBeAlso);
		
		allassociationData.put("Users", Users_association_data);
		
		ObservableList<AssociationInfo> Cart_association_data = FXCollections.observableArrayList();
		AssociationInfo Cart_associatition_IsIn = new AssociationInfo("Cart", "Order", "IsIn", false);
		Cart_association_data.add(Cart_associatition_IsIn);
		
		allassociationData.put("Cart", Cart_association_data);
		
		ObservableList<AssociationInfo> ReturnedProducts_association_data = FXCollections.observableArrayList();
		AssociationInfo ReturnedProducts_associatition_CanReturn = new AssociationInfo("ReturnedProducts", "Customer", "CanReturn", true);
		ReturnedProducts_association_data.add(ReturnedProducts_associatition_CanReturn);
		
		allassociationData.put("ReturnedProducts", ReturnedProducts_association_data);
		
		ObservableList<AssociationInfo> Report_association_data = FXCollections.observableArrayList();
		AssociationInfo Report_associatition_Generates = new AssociationInfo("Report", "StoreManager", "Generates", false);
		Report_association_data.add(Report_associatition_Generates);
		
		allassociationData.put("Report", Report_association_data);
		
		ObservableList<AssociationInfo> RestockProducts_association_data = FXCollections.observableArrayList();
		AssociationInfo RestockProducts_associatition_AskTo = new AssociationInfo("RestockProducts", "StoreManager", "AskTo", false);
		RestockProducts_association_data.add(RestockProducts_associatition_AskTo);
		
		allassociationData.put("RestockProducts", RestockProducts_association_data);
		
		
		association_statisic.getSelectionModel().selectedItemProperty().addListener(
			    (observable, oldValue, newValue) ->  { 
	
							 		if (newValue != null) {
							 			 try {
							 			 	 if (newValue.getNumber() != 0) {
								 				 //choose object or not
								 				 if (objectindex != -1) {
									 				 Class[] cArg = new Class[1];
									 				 cArg[0] = List.class;
									 				 //reflect updateTableData method
										 			 Method updateob = this.getClass().getMethod("update" + newValue.getTargetClass() + "Table", cArg);
										 			 //find choosen object
										 			 Object selectedob = EntityManager.getAllInstancesOf(newValue.getSourceClass()).get(objectindex);
										 			 //reflect find association method
										 			 Method getAssociatedObject = selectedob.getClass().getMethod("get" + newValue.getAssociationName());
										 			 List r = new LinkedList();
										 			 //one or mulity?
										 			 if (newValue.getIsMultiple() == true) {
											 			 
											 			r = (List) getAssociatedObject.invoke(selectedob);
										 			 }
										 			 else {
										 				r.add(getAssociatedObject.invoke(selectedob));
										 			 }
										 			 //invoke update method
										 			 updateob.invoke(this, r);
										 			  
										 			 
								 				 }
												 //bind updated data to GUI
					 				 			 TableView obs = allObjectTables.get(newValue.getTargetClass());
					 				 			 if (obs != null) {
					 				 				object_statics.setContent(obs);
					 				 				object_statics.setText("Targets Objects " + newValue.getTargetClass() + ":");
					 				 			 }
					 				 		 }
							 			 }
							 			 catch (Exception e) {
							 				 e.printStackTrace();
							 			 }
							 		}
					 		  });
		
	}	
	
	

    //prepare data for contract
	public void prepareData() {
		
		//definition map
		definitions_map = new HashMap<String, String>();
		definitions_map.put("usernameInput", "u:Users = Users.allInstance()->any(user:Users | user.Username = username)\r\r\n");
		definitions_map.put("passwordInput", "u:Users = Users.allInstance()->any(user:Users | user.Password = password)\r\r\n");
		definitions_map.put("validationCheck", "u:Users = Users.allInstance()->any(user:Users | user.UserName = username and user.Password = password)\r\r\n");
		definitions_map.put("validationMessage", "messages:Set(String) = Set { \"success\" .. \"failure\" }\r\r\n");
		definitions_map.put("saveDetails", "newMember:Member = Member.allInstance()\n // ->select(c:Member | c.MemberID = MemberID)\rc:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\n\ru:Users = Users.allInstance()->any(u:Users | u.UserName = usename)\r\r\n");
		definitions_map.put("cartSummary", "c:Cart = Cart.allInstance()->any(c:Cart | c.OrderID = orderID)\r\r\n");
		definitions_map.put("makePayment", "c:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\r\r\n");
		definitions_map.put("getGuestUserDetails", "u:Users = Users.allInstance()\r\r\n");
		definitions_map.put("getTransactionID", "t:Transaction = Transaction.allInstance()->any(t:Transaction | t.transactionID = transactionID)\r\r\n");
		definitions_map.put("productID", "p:Product = Product.allInstance()->any(p:Product | p.ProductID = productID)\r\r\n");
		definitions_map.put("saveReturn", "r:ReturnedProducts = ReturnedProducts.allInstance()->any(r:ReturnedProducts | r.ProductID = self.ProductID)\n\rc:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\r\r\n");
		definitions_map.put("reviewCart", "ca:Cart = Cart.allInstance()->any(cart:Cart | cart.CartID = sessionID)\r\r\n");
		definitions_map.put("modifyCart", "ca:Cart = Cart.allInstance()->any(cart:Cart | cart.CartID = sessionID and cart.ProductID = productID)\r\r\n");
		definitions_map.put("saveFeedback", " // // A provide a feed back the association provided on the diagramc:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = self.customerID)\n\rf:Feedback = Feedback.allInstance()->any(f:Feedback | f.FeedbackID =self.FeedbackID)\r\r\n");
		definitions_map.put("showCurrentStatus", "m:Member = Member.allInstance()->any(m:Member | m.MemberID =self.CustomerID)\r\r\n");
		definitions_map.put("scanProducts", " // / The barcode will represent the Product ID of a specific productp:Product = Product.allInstance()->any(p:Product | p.ProductID = barcode)\r\r\n");
		definitions_map.put("updateCart", "selectedProduct:Product = Product.allInstance()->any(p:Product | p.ProductID = productID and p.ProductName = productName)\r\r\n");
		definitions_map.put("paymentProcess", "c:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\r\r\n");
		definitions_map.put("addLoyaltyPoints", "m:Member = Member.allInstance()->any(m:Member | m.MemberID = memberID)\r\r\n");
		definitions_map.put("getCustomerID", "c:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\r\r\n");
		definitions_map.put("getUserDetails", "c:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\n\rt:Transaction = Transaction.allInstance()->any(t:Transaction | t.TransactionID = transactionID)\n\ro:Order = Order.allInstance()->any(o:Order | o.OrderID = orderID)\r\r\n");
		definitions_map.put("printReciept", "c:Customer = Customer.allInstance()->any(c:Customer | c.CustomerID = customerID)\n\rt:Transaction = Transaction.allInstance()->any(t:Transaction | t.TransactionID = transactionID)\n\ro:Order = Order.allInstance()->any(o:Order | o.OrderID = orderID)\n\rca:Cart = Cart.allInstance()->any(ca:Cart | ca.Cart = cartID)\r\r\n");
		definitions_map.put("cashPayment", "ca:Cart = Cart.allInstance()->any(ca:Cart | ca.Cart = cartID)\r\r\n");
		definitions_map.put("getReportType", "r:Report = Report.allInstance()->any(rep:Report | rep.reportID = reportID)\r\r\n");
		definitions_map.put("viewAllReports", "allReports:Set(Report) = Report.allInstance()\r\r\n");
		definitions_map.put("sendToSupplier", "s:Supplier = Supplier.allInstance()->any(s | s.SupplierID = supplierID)\n\rp:Product = Product.allInstance()->any(p | p.ProductID = productID)\r\r\n");
		definitions_map.put("recordRestock", "p:Product = Product.allInstance()->any(p | p.ProductID = productID and p.ProductName = productName)\r\r\n");
		definitions_map.put("viewInventoryStockLevel", "i:Inventory = Inventory.allInstance()\r\r\n");
		definitions_map.put("orderStockProducts", "p:Product = Product.allInstance()->any(p | p.ProductID = productID)\r\r\n");
		definitions_map.put("creatingNewSupplier", "s = Supplier.allInstance()->any(s | s.SupplierID = supplierID)\r\r\n");
		
		//precondition map
		preconditions_map = new HashMap<String, String>();
		preconditions_map.put("usernameInput", "username <> ''");
		preconditions_map.put("passwordInput", "password <> ''");
		preconditions_map.put("validationCheck", "username <> '' and\npassword <> ''\n");
		preconditions_map.put("validationMessage", "validationState <> ''");
		preconditions_map.put("customerRegUsername", "username <> ''");
		preconditions_map.put("customerRegPassword", "password <> ''");
		preconditions_map.put("customerDetails", "email <> '' and\nphonenumber <> '' and\naddress <> '' and\nfullName <> '' and\nuserID <> ''\n");
		preconditions_map.put("saveDetails", "usename = true and\npassword = true and\nemail = true and\nphonenumber = true and\naddress = true and\nfullName = true and\ncustomerID <> ''\n");
		preconditions_map.put("searchProducts", "productName <> '' and\nproductName.oclIsTypeOf(String)\n");
		preconditions_map.put("viewAllProducts", "true");
		preconditions_map.put("cartSummary", "c.oclIsUndefined() = false");
		preconditions_map.put("makePayment", "paymentMethod <> '' and\norderID <> '' and\ntransactionID <> '' and\nAmount <> ''\n");
		preconditions_map.put("getGuestUserDetails", "fullName <> '' and\naddress <> '' and\nphoneNumber <> '' and\nemail <> '' and\nuserID <> ''\n");
		preconditions_map.put("getTransactionID", "transactionID <> ''");
		preconditions_map.put("productID", "productID <> ''");
		preconditions_map.put("getReason", "reasonOfReturn <> ''");
		preconditions_map.put("saveReturn", "customerID <> '' and\ntransactionID <> '' and\nreasonOfReturn <> '' and\nreturnID <> ''\n");
		preconditions_map.put("reviewCart", "sessionID <> ''");
		preconditions_map.put("modifyCart", "sessionID <> '' and\nproductID <> '' and\nquantity <> ''\n");
		preconditions_map.put("giveFeedback", "textFeedback <> '' and\ncustomerID <> '' and\nfeedbackID <> ''\n");
		preconditions_map.put("saveFeedback", "textFeedback <> '' and\ncustomerID <> ''\n");
		preconditions_map.put("getMembershipStatus", "customerID <> '' and\nemail <> ''\n");
		preconditions_map.put("showCurrentStatus", "m.oclIsUndefined() = false");
		preconditions_map.put("scanProducts", "p.oclIsUndefined() = false and\nquantity > 0\n");
		preconditions_map.put("updateCart", "selectedProduct.oclIsUndefined() = false and\nquantity > 0\n");
		preconditions_map.put("paymentProcess", "paymentMethod <> '' and\ntotalAmount <> '' and\nloyaltyCustomerID <> '' and\nAmount <> ''\n");
		preconditions_map.put("addLoyaltyPoints", "m.oclIsUndefined() = false");
		preconditions_map.put("getCustomerID", "true");
		preconditions_map.put("getUserDetails", "c.oclIsUndefined() = false and\nt.oclIsUndefined() = false and\no.oclIsUndefined() = false\n");
		preconditions_map.put("printReciept", "c.oclIsUndefined() = false and\nt.oclIsUndefined() = false and\no.oclIsUndefined() = false and\nca.oclIsUndefined() = false\n");
		preconditions_map.put("processingUserPayment", "self.CvvCodeSize = cvvCode.size() and\nself.CreditCardsize = creditcardNumber.size() and\nself.CvvCodeSize.isEqual(3) and\nself.CreditCardsize.isEqual(16)\n");
		preconditions_map.put("bankContactandAuthorization", "true");
		preconditions_map.put("processingInStoreUserPayment", "self.CvvCodeSize = cvvCode.size() and\nself.CreditCardsize = creditcardNumber.size() and\nself.CvvCodeSize.isEqual(3) and\nself.CreditCardsize.isEqual(16)\n");
		preconditions_map.put("bankContactandAuthorizationInStore", "true");
		preconditions_map.put("cashPayment", "amount <> '' and\ncartID <> '' and\ncashByUser <> ''\n");
		preconditions_map.put("generateReport", "amount <> '' and\ncartID <> '' and\ncashByUser <> '' and\nvalidReportTypes = Set { 'sales' .. 'inventory' }\n");
		preconditions_map.put("getReportType", "reportID <> ''");
		preconditions_map.put("viewAllReports", "true");
		preconditions_map.put("sendToSupplier", " // /// they exists.oclIsUndefined() = false and\np.oclIsUndefined() = false\n");
		preconditions_map.put("recordRestock", "p.oclIsUndefined() = false");
		preconditions_map.put("viewInventoryStockLevel", "true");
		preconditions_map.put("orderStockProducts", "p.oclIsUndefined() = false and\nquantity > 0\n");
		preconditions_map.put("newOrder", "true");
		preconditions_map.put("creatingNewSupplier", "s.oclIsUndefined() = true");
		
		//postcondition map
		postconditions_map = new HashMap<String, String>();
		postconditions_map.put("usernameInput", "if(u.oclIsUndefined() = false)\nthen\nself.username = username and\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("passwordInput", "if(u.oclIsUndefined() = false)\nthen\nself.Password = password and\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("validationCheck", "if(u.oclIsUndefined() = false)\nthen\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("validationMessage", "if(messages->includes(validationState))\nthen\nresult = validationState\nelse\nresult = 'Invalid message'\nendif");
		postconditions_map.put("customerRegUsername", "self.UserName = username and\nresult = true\n");
		postconditions_map.put("customerRegPassword", "self.Password = password and\nresult = true\n");
		postconditions_map.put("customerDetails", "let u:Users inu.oclIsNew() and\nu.UserID = userID and\nu.UserName = self.UserName and\nu.Password = self.Password and\nself.Email = email and\nself.PhoneNumber = phonenumber and\nself.Address = address and\nself.FullName = fullName and\nc.RelatedTo->includes(u) and\nresult = true\n");
		postconditions_map.put("saveDetails", "let m:Member inm.oclIsNew() and\nm.Username = usename and\nm.Password = password and\nm.Email = email and\nm.PhoneNumber = phonenumber and\nm.Address = address and\nm.CustomerID = customerID and\nm.FullName = fullName and\nc.Is->includes(m) and\nu.BelongTo->includes(m) and\nresult = true\n");
		postconditions_map.put("searchProducts", "result = Product.allInstance()->select(product:Product | product.ProductName = productName)");
		postconditions_map.put("viewAllProducts", "result = Product.allInstance()");
		postconditions_map.put("cartSummary", "self.DateOfPurchase.isEqual(Today) and\nnewOrder(orderID , self.DateOfPurchase , c.TotalAmount , c.ProductList) and\nresult = c\n");
		postconditions_map.put("makePayment", "let t:Transaction int.oclIsNew() and\nt.TrancationID = transactionID and\nt.PaymentMethod = paymentMethod and\nt.OrderID = orderID and\nt.Amount = totalAmount and\nc.CanBeProcessedBy->includes(t) and\nresult = true\n");
		postconditions_map.put("getGuestUserDetails", "let c:Customer inc.oclIsNew() and\nc.FullName = fullName and\nc.Address = address and\nc.PhoneNumber = phoneNumber and\nc.Email = email and\nc.CustomerID = customerID and\nCustomer.allInstance()->includes(c) and\nu.Are->includes(c) and\nresult = true\n");
		postconditions_map.put("getTransactionID", "self.TransactionID = transactionID and\nresult = t\n");
		postconditions_map.put("productID", "let r:ReturnedProducts inr.oclIsNew() and\nself.ProductID = productID and\nr.ProductID = productID and\nReturnedProducts.allInstance()->includes(r) and\nresult = true\n");
		postconditions_map.put("getReason", "self.Reason = reasonOfReturn");
		postconditions_map.put("saveReturn", "self.CustomerID = customerID and\nself.TransactionID = transactionID and\nself.Reason = reasonOfReturn and\nr.ReturnID = returnID and\nr.CustomerID = self.CustomerID and\nr.transactionID = self.TransactionID and\nr.reasonOfReturn = self.Reason and\nc.CanReturn->includes(r) and\nresult = true\n");
		postconditions_map.put("reviewCart", "if(ca.oclIsUndefined() = false)\nthen\nresult = ca // The cart is available and not expired\nelse\nresult = null\nendif");
		postconditions_map.put("modifyCart", "ca.Quantity = quantity and\nresult = true\n");
		postconditions_map.put("giveFeedback", "self.Feedback = textFeedback and\nself.CustomerID = customerID and\nself.FeedbackID = feedbackID and\nresult = true\n");
		postconditions_map.put("saveFeedback", "let f:Feedback inf.oclIsNew() and\nf.FeedbackID = self.FeedbackID and\nf.FeedbackContent = self.Feedback and\nf.CustomerID = self.CustomerID and\nc.Provide->includes(f) and\nresult = true\n");
		postconditions_map.put("getMembershipStatus", "self.CustomerID = memberID and\nself.Email = email and\nresult = true\n");
		postconditions_map.put("showCurrentStatus", "result = m");
		postconditions_map.put("scanProducts", "if(p.StockLevel >= quantity)\nthen\nupdateCart(p.ProductID , p.ProductName , quantity , p.Price) and\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("updateCart", "if(selectedProduct.StockLevel >= quantity)\nthen\nCart.ProductList->includes(selectedProduct) // Adding Product in the Cart\nand\nselectedProduct.StockLevel = selectedProduct.StockLevel@pre - quantity // Updating the quantity\nand\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("paymentProcess", "let t:Transaction int.oclIsNew() and\nt.TrancationID = transactionID and\nt.PaymentMethod = paymentMethod and\nt.OrderID = orderID and\nt.Amount = totalAmount and\nc.CanBeProcessedBy->includes(t) and\nresult = true\n");
		postconditions_map.put("addLoyaltyPoints", "m.LoyaltyPoints = m.LoyaltyPoints + points and\nresult = true\n");
		postconditions_map.put("getCustomerID", "let r:ReturnedProducts inr.oclIsNew() and\nr.CustomerID = customerID and\nr.ProductID = productID and\nr.TransactionID = transactionID and\nr.ReasonOfReturn = reasonOfReturn and\nReturnedProducts.allInstance()->includes(r) and\nc.ReturnedBy->includes(t) and\nresult = true\n");
		postconditions_map.put("getUserDetails", "// self.CustomerID = customerID and\n// self.TransactionID = transactionID and\n// self.OrderID = orderID and\nresult = true");
		postconditions_map.put("printReciept", "let re:Receipt inre.oclIsNew() and\nre.ReceiptID = receiptID and\nre.PaymentMethod = t.PaymentMethod and\nre.TransactionID = t.TransactionID and\nre.TotalAmount = ca.TotalAmount and\nre.DateOfPurchase.isEqual(Today) and\nReceipt.allInstance()->includes(re) and\nresult = true\n");
		postconditions_map.put("processingUserPayment", "result = true");
		postconditions_map.put("bankContactandAuthorization", "true");
		postconditions_map.put("processingInStoreUserPayment", "result = true");
		postconditions_map.put("bankContactandAuthorizationInStore", "true");
		postconditions_map.put("cashPayment", "ifcashByUser >= ca.TotalAmount\nthen\nresult = true\nelse\nresult = false\nendif");
		postconditions_map.put("generateReport", "let report:Report inreport.oclIsNew() and\nreport.ReportID = reportID and\nreport.TypeOfReport = type and\nreport.DateGenerated.isEqual(Today) and\nreport.ReportResult = \"We will be integrating a third party tool that helps in creating and providing visual charts\" and\nreport.DateOfPurchase.isEqual(Today) and\nReport.allInstance()->includes(report) and\nresult = true\n");
		postconditions_map.put("getReportType", "result = r");
		postconditions_map.put("viewAllReports", "result = allReports");
		postconditions_map.put("sendToSupplier", "let so:Supplier inso.oclIsNew() and\nso.SupplierID = supplierID and\nso.SupplierOrderID = supplierOrderID and\nso.ProductsList->includes(p) and\nso.Status = 'New Order' and\nso.allInstance()->includes(so) and\ns.Fulfill->includes(so) and\nresult = true\n");
		postconditions_map.put("recordRestock", "p.StockLevel = p.StockLevel@pre + quantity and\nresult = true\n");
		postconditions_map.put("viewInventoryStockLevel", " // returning the inventoryresult = i");
		postconditions_map.put("orderStockProducts", "let rp:RestockProducts inrp.oclIsNew() and\nrp.ProductsNeededList = p and\nrp.RestockProductsID = restockProductsID and\nrp.allInstance()->includes(rp) and\nresult = true\n");
		postconditions_map.put("newOrder", "let o:Order ino.oclIsNew() and\no.OrderID = orderID and\no.DateOfPurchase = dateOfPurchase and\no.TotalPrice = totalPrice and\no.ProductList->includes(produceList) and\no.allInstance()->includes(o) and\nresult = true\n");
		postconditions_map.put("creatingNewSupplier", "let s:Supplier ins.oclIsNew() and\ns.SupplierID = supplierID and\ns.CompanyName = companyName and\ns.ContactDetails = contactDetails and\ns.allInstance()->includes(s) and\nresult = true\n");
		
		//service invariants map
		service_invariants_map = new LinkedHashMap<String, String>();
		
		//entity invariants map
		entity_invariants_map = new LinkedHashMap<String, String>();
		
	}
	
	public void generatOperationPane() {
		
		 operationPanels = new LinkedHashMap<String, GridPane>();
		
		 // ==================== GridPane_usernameInput ====================
		 GridPane usernameInput = new GridPane();
		 usernameInput.setHgap(4);
		 usernameInput.setVgap(6);
		 usernameInput.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> usernameInput_content = usernameInput.getChildren();
		 Label usernameInput_username_label = new Label("username:");
		 usernameInput_username_label.setMinWidth(Region.USE_PREF_SIZE);
		 usernameInput_content.add(usernameInput_username_label);
		 GridPane.setConstraints(usernameInput_username_label, 0, 0);
		 
		 usernameInput_username_t = new TextField();
		 usernameInput_content.add(usernameInput_username_t);
		 usernameInput_username_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(usernameInput_username_t, 1, 0);
		 operationPanels.put("usernameInput", usernameInput);
		 
		 // ==================== GridPane_passwordInput ====================
		 GridPane passwordInput = new GridPane();
		 passwordInput.setHgap(4);
		 passwordInput.setVgap(6);
		 passwordInput.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> passwordInput_content = passwordInput.getChildren();
		 Label passwordInput_password_label = new Label("password:");
		 passwordInput_password_label.setMinWidth(Region.USE_PREF_SIZE);
		 passwordInput_content.add(passwordInput_password_label);
		 GridPane.setConstraints(passwordInput_password_label, 0, 0);
		 
		 passwordInput_password_t = new TextField();
		 passwordInput_content.add(passwordInput_password_t);
		 passwordInput_password_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(passwordInput_password_t, 1, 0);
		 operationPanels.put("passwordInput", passwordInput);
		 
		 // ==================== GridPane_validationCheck ====================
		 GridPane validationCheck = new GridPane();
		 validationCheck.setHgap(4);
		 validationCheck.setVgap(6);
		 validationCheck.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> validationCheck_content = validationCheck.getChildren();
		 Label validationCheck_username_label = new Label("username:");
		 validationCheck_username_label.setMinWidth(Region.USE_PREF_SIZE);
		 validationCheck_content.add(validationCheck_username_label);
		 GridPane.setConstraints(validationCheck_username_label, 0, 0);
		 
		 validationCheck_username_t = new TextField();
		 validationCheck_content.add(validationCheck_username_t);
		 validationCheck_username_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(validationCheck_username_t, 1, 0);
		 Label validationCheck_password_label = new Label("password:");
		 validationCheck_password_label.setMinWidth(Region.USE_PREF_SIZE);
		 validationCheck_content.add(validationCheck_password_label);
		 GridPane.setConstraints(validationCheck_password_label, 0, 1);
		 
		 validationCheck_password_t = new TextField();
		 validationCheck_content.add(validationCheck_password_t);
		 validationCheck_password_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(validationCheck_password_t, 1, 1);
		 operationPanels.put("validationCheck", validationCheck);
		 
		 // ==================== GridPane_validationMessage ====================
		 GridPane validationMessage = new GridPane();
		 validationMessage.setHgap(4);
		 validationMessage.setVgap(6);
		 validationMessage.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> validationMessage_content = validationMessage.getChildren();
		 Label validationMessage_validationState_label = new Label("validationState:");
		 validationMessage_validationState_label.setMinWidth(Region.USE_PREF_SIZE);
		 validationMessage_content.add(validationMessage_validationState_label);
		 GridPane.setConstraints(validationMessage_validationState_label, 0, 0);
		 
		 validationMessage_validationState_t = new TextField();
		 validationMessage_content.add(validationMessage_validationState_t);
		 validationMessage_validationState_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(validationMessage_validationState_t, 1, 0);
		 operationPanels.put("validationMessage", validationMessage);
		 
		 // ==================== GridPane_customerRegUsername ====================
		 GridPane customerRegUsername = new GridPane();
		 customerRegUsername.setHgap(4);
		 customerRegUsername.setVgap(6);
		 customerRegUsername.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> customerRegUsername_content = customerRegUsername.getChildren();
		 Label customerRegUsername_username_label = new Label("username:");
		 customerRegUsername_username_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerRegUsername_content.add(customerRegUsername_username_label);
		 GridPane.setConstraints(customerRegUsername_username_label, 0, 0);
		 
		 customerRegUsername_username_t = new TextField();
		 customerRegUsername_content.add(customerRegUsername_username_t);
		 customerRegUsername_username_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerRegUsername_username_t, 1, 0);
		 operationPanels.put("customerRegUsername", customerRegUsername);
		 
		 // ==================== GridPane_customerRegPassword ====================
		 GridPane customerRegPassword = new GridPane();
		 customerRegPassword.setHgap(4);
		 customerRegPassword.setVgap(6);
		 customerRegPassword.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> customerRegPassword_content = customerRegPassword.getChildren();
		 Label customerRegPassword_password_label = new Label("password:");
		 customerRegPassword_password_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerRegPassword_content.add(customerRegPassword_password_label);
		 GridPane.setConstraints(customerRegPassword_password_label, 0, 0);
		 
		 customerRegPassword_password_t = new TextField();
		 customerRegPassword_content.add(customerRegPassword_password_t);
		 customerRegPassword_password_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerRegPassword_password_t, 1, 0);
		 operationPanels.put("customerRegPassword", customerRegPassword);
		 
		 // ==================== GridPane_customerDetails ====================
		 GridPane customerDetails = new GridPane();
		 customerDetails.setHgap(4);
		 customerDetails.setVgap(6);
		 customerDetails.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> customerDetails_content = customerDetails.getChildren();
		 Label customerDetails_email_label = new Label("email:");
		 customerDetails_email_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerDetails_content.add(customerDetails_email_label);
		 GridPane.setConstraints(customerDetails_email_label, 0, 0);
		 
		 customerDetails_email_t = new TextField();
		 customerDetails_content.add(customerDetails_email_t);
		 customerDetails_email_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerDetails_email_t, 1, 0);
		 Label customerDetails_phonenumber_label = new Label("phonenumber:");
		 customerDetails_phonenumber_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerDetails_content.add(customerDetails_phonenumber_label);
		 GridPane.setConstraints(customerDetails_phonenumber_label, 0, 1);
		 
		 customerDetails_phonenumber_t = new TextField();
		 customerDetails_content.add(customerDetails_phonenumber_t);
		 customerDetails_phonenumber_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerDetails_phonenumber_t, 1, 1);
		 Label customerDetails_address_label = new Label("address:");
		 customerDetails_address_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerDetails_content.add(customerDetails_address_label);
		 GridPane.setConstraints(customerDetails_address_label, 0, 2);
		 
		 customerDetails_address_t = new TextField();
		 customerDetails_content.add(customerDetails_address_t);
		 customerDetails_address_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerDetails_address_t, 1, 2);
		 Label customerDetails_fullName_label = new Label("fullName:");
		 customerDetails_fullName_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerDetails_content.add(customerDetails_fullName_label);
		 GridPane.setConstraints(customerDetails_fullName_label, 0, 3);
		 
		 customerDetails_fullName_t = new TextField();
		 customerDetails_content.add(customerDetails_fullName_t);
		 customerDetails_fullName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerDetails_fullName_t, 1, 3);
		 Label customerDetails_userID_label = new Label("userID:");
		 customerDetails_userID_label.setMinWidth(Region.USE_PREF_SIZE);
		 customerDetails_content.add(customerDetails_userID_label);
		 GridPane.setConstraints(customerDetails_userID_label, 0, 4);
		 
		 customerDetails_userID_t = new TextField();
		 customerDetails_content.add(customerDetails_userID_t);
		 customerDetails_userID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(customerDetails_userID_t, 1, 4);
		 operationPanels.put("customerDetails", customerDetails);
		 
		 // ==================== GridPane_saveDetails ====================
		 GridPane saveDetails = new GridPane();
		 saveDetails.setHgap(4);
		 saveDetails.setVgap(6);
		 saveDetails.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> saveDetails_content = saveDetails.getChildren();
		 Label saveDetails_usename_label = new Label("usename:");
		 saveDetails_usename_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_usename_label);
		 GridPane.setConstraints(saveDetails_usename_label, 0, 0);
		 
		 saveDetails_usename_t = new TextField();
		 saveDetails_content.add(saveDetails_usename_t);
		 saveDetails_usename_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_usename_t, 1, 0);
		 Label saveDetails_password_label = new Label("password:");
		 saveDetails_password_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_password_label);
		 GridPane.setConstraints(saveDetails_password_label, 0, 1);
		 
		 saveDetails_password_t = new TextField();
		 saveDetails_content.add(saveDetails_password_t);
		 saveDetails_password_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_password_t, 1, 1);
		 Label saveDetails_email_label = new Label("email:");
		 saveDetails_email_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_email_label);
		 GridPane.setConstraints(saveDetails_email_label, 0, 2);
		 
		 saveDetails_email_t = new TextField();
		 saveDetails_content.add(saveDetails_email_t);
		 saveDetails_email_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_email_t, 1, 2);
		 Label saveDetails_phonenumber_label = new Label("phonenumber:");
		 saveDetails_phonenumber_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_phonenumber_label);
		 GridPane.setConstraints(saveDetails_phonenumber_label, 0, 3);
		 
		 saveDetails_phonenumber_t = new TextField();
		 saveDetails_content.add(saveDetails_phonenumber_t);
		 saveDetails_phonenumber_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_phonenumber_t, 1, 3);
		 Label saveDetails_address_label = new Label("address:");
		 saveDetails_address_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_address_label);
		 GridPane.setConstraints(saveDetails_address_label, 0, 4);
		 
		 saveDetails_address_t = new TextField();
		 saveDetails_content.add(saveDetails_address_t);
		 saveDetails_address_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_address_t, 1, 4);
		 Label saveDetails_customerID_label = new Label("customerID:");
		 saveDetails_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_customerID_label);
		 GridPane.setConstraints(saveDetails_customerID_label, 0, 5);
		 
		 saveDetails_customerID_t = new TextField();
		 saveDetails_content.add(saveDetails_customerID_t);
		 saveDetails_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_customerID_t, 1, 5);
		 Label saveDetails_fullName_label = new Label("fullName:");
		 saveDetails_fullName_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveDetails_content.add(saveDetails_fullName_label);
		 GridPane.setConstraints(saveDetails_fullName_label, 0, 6);
		 
		 saveDetails_fullName_t = new TextField();
		 saveDetails_content.add(saveDetails_fullName_t);
		 saveDetails_fullName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveDetails_fullName_t, 1, 6);
		 operationPanels.put("saveDetails", saveDetails);
		 
		 // ==================== GridPane_searchProducts ====================
		 GridPane searchProducts = new GridPane();
		 searchProducts.setHgap(4);
		 searchProducts.setVgap(6);
		 searchProducts.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> searchProducts_content = searchProducts.getChildren();
		 Label searchProducts_productName_label = new Label("productName:");
		 searchProducts_productName_label.setMinWidth(Region.USE_PREF_SIZE);
		 searchProducts_content.add(searchProducts_productName_label);
		 GridPane.setConstraints(searchProducts_productName_label, 0, 0);
		 
		 searchProducts_productName_t = new TextField();
		 searchProducts_content.add(searchProducts_productName_t);
		 searchProducts_productName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(searchProducts_productName_t, 1, 0);
		 operationPanels.put("searchProducts", searchProducts);
		 
		 // ==================== GridPane_viewAllProducts ====================
		 GridPane viewAllProducts = new GridPane();
		 viewAllProducts.setHgap(4);
		 viewAllProducts.setVgap(6);
		 viewAllProducts.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> viewAllProducts_content = viewAllProducts.getChildren();
		 Label viewAllProducts_label = new Label("This operation is no intput parameters..");
		 viewAllProducts_label.setMinWidth(Region.USE_PREF_SIZE);
		 viewAllProducts_content.add(viewAllProducts_label);
		 GridPane.setConstraints(viewAllProducts_label, 0, 0);
		 operationPanels.put("viewAllProducts", viewAllProducts);
		 
		 // ==================== GridPane_cartSummary ====================
		 GridPane cartSummary = new GridPane();
		 cartSummary.setHgap(4);
		 cartSummary.setVgap(6);
		 cartSummary.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> cartSummary_content = cartSummary.getChildren();
		 Label cartSummary_listOfProductID_label = new Label("listOfProductID:");
		 cartSummary_listOfProductID_label.setMinWidth(Region.USE_PREF_SIZE);
		 cartSummary_content.add(cartSummary_listOfProductID_label);
		 GridPane.setConstraints(cartSummary_listOfProductID_label, 0, 0);
		 
		 cartSummary_listOfProductID_t = new TextField();
		 cartSummary_content.add(cartSummary_listOfProductID_t);
		 cartSummary_listOfProductID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cartSummary_listOfProductID_t, 1, 0);
		 Label cartSummary_quantity_label = new Label("quantity:");
		 cartSummary_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 cartSummary_content.add(cartSummary_quantity_label);
		 GridPane.setConstraints(cartSummary_quantity_label, 0, 1);
		 
		 cartSummary_quantity_t = new TextField();
		 cartSummary_content.add(cartSummary_quantity_t);
		 cartSummary_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cartSummary_quantity_t, 1, 1);
		 Label cartSummary_orderID_label = new Label("orderID:");
		 cartSummary_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 cartSummary_content.add(cartSummary_orderID_label);
		 GridPane.setConstraints(cartSummary_orderID_label, 0, 2);
		 
		 cartSummary_orderID_t = new TextField();
		 cartSummary_content.add(cartSummary_orderID_t);
		 cartSummary_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cartSummary_orderID_t, 1, 2);
		 operationPanels.put("cartSummary", cartSummary);
		 
		 // ==================== GridPane_makePayment ====================
		 GridPane makePayment = new GridPane();
		 makePayment.setHgap(4);
		 makePayment.setVgap(6);
		 makePayment.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> makePayment_content = makePayment.getChildren();
		 Label makePayment_paymentMethod_label = new Label("paymentMethod:");
		 makePayment_paymentMethod_label.setMinWidth(Region.USE_PREF_SIZE);
		 makePayment_content.add(makePayment_paymentMethod_label);
		 GridPane.setConstraints(makePayment_paymentMethod_label, 0, 0);
		 
		 makePayment_paymentMethod_t = new TextField();
		 makePayment_content.add(makePayment_paymentMethod_t);
		 makePayment_paymentMethod_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(makePayment_paymentMethod_t, 1, 0);
		 Label makePayment_orderID_label = new Label("orderID:");
		 makePayment_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 makePayment_content.add(makePayment_orderID_label);
		 GridPane.setConstraints(makePayment_orderID_label, 0, 1);
		 
		 makePayment_orderID_t = new TextField();
		 makePayment_content.add(makePayment_orderID_t);
		 makePayment_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(makePayment_orderID_t, 1, 1);
		 Label makePayment_transactionID_label = new Label("transactionID:");
		 makePayment_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 makePayment_content.add(makePayment_transactionID_label);
		 GridPane.setConstraints(makePayment_transactionID_label, 0, 2);
		 
		 makePayment_transactionID_t = new TextField();
		 makePayment_content.add(makePayment_transactionID_t);
		 makePayment_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(makePayment_transactionID_t, 1, 2);
		 Label makePayment_totalAmount_label = new Label("totalAmount:");
		 makePayment_totalAmount_label.setMinWidth(Region.USE_PREF_SIZE);
		 makePayment_content.add(makePayment_totalAmount_label);
		 GridPane.setConstraints(makePayment_totalAmount_label, 0, 3);
		 
		 makePayment_totalAmount_t = new TextField();
		 makePayment_content.add(makePayment_totalAmount_t);
		 makePayment_totalAmount_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(makePayment_totalAmount_t, 1, 3);
		 Label makePayment_customerID_label = new Label("customerID:");
		 makePayment_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 makePayment_content.add(makePayment_customerID_label);
		 GridPane.setConstraints(makePayment_customerID_label, 0, 4);
		 
		 makePayment_customerID_t = new TextField();
		 makePayment_content.add(makePayment_customerID_t);
		 makePayment_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(makePayment_customerID_t, 1, 4);
		 operationPanels.put("makePayment", makePayment);
		 
		 // ==================== GridPane_getGuestUserDetails ====================
		 GridPane getGuestUserDetails = new GridPane();
		 getGuestUserDetails.setHgap(4);
		 getGuestUserDetails.setVgap(6);
		 getGuestUserDetails.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getGuestUserDetails_content = getGuestUserDetails.getChildren();
		 Label getGuestUserDetails_fullName_label = new Label("fullName:");
		 getGuestUserDetails_fullName_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_fullName_label);
		 GridPane.setConstraints(getGuestUserDetails_fullName_label, 0, 0);
		 
		 getGuestUserDetails_fullName_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_fullName_t);
		 getGuestUserDetails_fullName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_fullName_t, 1, 0);
		 Label getGuestUserDetails_address_label = new Label("address:");
		 getGuestUserDetails_address_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_address_label);
		 GridPane.setConstraints(getGuestUserDetails_address_label, 0, 1);
		 
		 getGuestUserDetails_address_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_address_t);
		 getGuestUserDetails_address_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_address_t, 1, 1);
		 Label getGuestUserDetails_phoneNumber_label = new Label("phoneNumber:");
		 getGuestUserDetails_phoneNumber_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_phoneNumber_label);
		 GridPane.setConstraints(getGuestUserDetails_phoneNumber_label, 0, 2);
		 
		 getGuestUserDetails_phoneNumber_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_phoneNumber_t);
		 getGuestUserDetails_phoneNumber_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_phoneNumber_t, 1, 2);
		 Label getGuestUserDetails_email_label = new Label("email:");
		 getGuestUserDetails_email_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_email_label);
		 GridPane.setConstraints(getGuestUserDetails_email_label, 0, 3);
		 
		 getGuestUserDetails_email_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_email_t);
		 getGuestUserDetails_email_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_email_t, 1, 3);
		 Label getGuestUserDetails_customerID_label = new Label("customerID:");
		 getGuestUserDetails_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_customerID_label);
		 GridPane.setConstraints(getGuestUserDetails_customerID_label, 0, 4);
		 
		 getGuestUserDetails_customerID_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_customerID_t);
		 getGuestUserDetails_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_customerID_t, 1, 4);
		 Label getGuestUserDetails_orderID_label = new Label("orderID:");
		 getGuestUserDetails_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getGuestUserDetails_content.add(getGuestUserDetails_orderID_label);
		 GridPane.setConstraints(getGuestUserDetails_orderID_label, 0, 5);
		 
		 getGuestUserDetails_orderID_t = new TextField();
		 getGuestUserDetails_content.add(getGuestUserDetails_orderID_t);
		 getGuestUserDetails_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getGuestUserDetails_orderID_t, 1, 5);
		 operationPanels.put("getGuestUserDetails", getGuestUserDetails);
		 
		 // ==================== GridPane_getTransactionID ====================
		 GridPane getTransactionID = new GridPane();
		 getTransactionID.setHgap(4);
		 getTransactionID.setVgap(6);
		 getTransactionID.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getTransactionID_content = getTransactionID.getChildren();
		 Label getTransactionID_transactionID_label = new Label("transactionID:");
		 getTransactionID_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getTransactionID_content.add(getTransactionID_transactionID_label);
		 GridPane.setConstraints(getTransactionID_transactionID_label, 0, 0);
		 
		 getTransactionID_transactionID_t = new TextField();
		 getTransactionID_content.add(getTransactionID_transactionID_t);
		 getTransactionID_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getTransactionID_transactionID_t, 1, 0);
		 operationPanels.put("getTransactionID", getTransactionID);
		 
		 // ==================== GridPane_productID ====================
		 GridPane productID = new GridPane();
		 productID.setHgap(4);
		 productID.setVgap(6);
		 productID.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> productID_content = productID.getChildren();
		 Label productID_productID_label = new Label("productID:");
		 productID_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 productID_content.add(productID_productID_label);
		 GridPane.setConstraints(productID_productID_label, 0, 0);
		 
		 productID_productID_t = new TextField();
		 productID_content.add(productID_productID_t);
		 productID_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(productID_productID_t, 1, 0);
		 operationPanels.put("productID", productID);
		 
		 // ==================== GridPane_getReason ====================
		 GridPane getReason = new GridPane();
		 getReason.setHgap(4);
		 getReason.setVgap(6);
		 getReason.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getReason_content = getReason.getChildren();
		 Label getReason_reasonOfReturn_label = new Label("reasonOfReturn:");
		 getReason_reasonOfReturn_label.setMinWidth(Region.USE_PREF_SIZE);
		 getReason_content.add(getReason_reasonOfReturn_label);
		 GridPane.setConstraints(getReason_reasonOfReturn_label, 0, 0);
		 
		 getReason_reasonOfReturn_t = new TextField();
		 getReason_content.add(getReason_reasonOfReturn_t);
		 getReason_reasonOfReturn_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getReason_reasonOfReturn_t, 1, 0);
		 operationPanels.put("getReason", getReason);
		 
		 // ==================== GridPane_saveReturn ====================
		 GridPane saveReturn = new GridPane();
		 saveReturn.setHgap(4);
		 saveReturn.setVgap(6);
		 saveReturn.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> saveReturn_content = saveReturn.getChildren();
		 Label saveReturn_customerID_label = new Label("customerID:");
		 saveReturn_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveReturn_content.add(saveReturn_customerID_label);
		 GridPane.setConstraints(saveReturn_customerID_label, 0, 0);
		 
		 saveReturn_customerID_t = new TextField();
		 saveReturn_content.add(saveReturn_customerID_t);
		 saveReturn_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveReturn_customerID_t, 1, 0);
		 Label saveReturn_transactionID_label = new Label("transactionID:");
		 saveReturn_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveReturn_content.add(saveReturn_transactionID_label);
		 GridPane.setConstraints(saveReturn_transactionID_label, 0, 1);
		 
		 saveReturn_transactionID_t = new TextField();
		 saveReturn_content.add(saveReturn_transactionID_t);
		 saveReturn_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveReturn_transactionID_t, 1, 1);
		 Label saveReturn_reasonOfReturn_label = new Label("reasonOfReturn:");
		 saveReturn_reasonOfReturn_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveReturn_content.add(saveReturn_reasonOfReturn_label);
		 GridPane.setConstraints(saveReturn_reasonOfReturn_label, 0, 2);
		 
		 saveReturn_reasonOfReturn_t = new TextField();
		 saveReturn_content.add(saveReturn_reasonOfReturn_t);
		 saveReturn_reasonOfReturn_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveReturn_reasonOfReturn_t, 1, 2);
		 Label saveReturn_returnID_label = new Label("returnID:");
		 saveReturn_returnID_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveReturn_content.add(saveReturn_returnID_label);
		 GridPane.setConstraints(saveReturn_returnID_label, 0, 3);
		 
		 saveReturn_returnID_t = new TextField();
		 saveReturn_content.add(saveReturn_returnID_t);
		 saveReturn_returnID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveReturn_returnID_t, 1, 3);
		 operationPanels.put("saveReturn", saveReturn);
		 
		 // ==================== GridPane_reviewCart ====================
		 GridPane reviewCart = new GridPane();
		 reviewCart.setHgap(4);
		 reviewCart.setVgap(6);
		 reviewCart.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> reviewCart_content = reviewCart.getChildren();
		 Label reviewCart_sessionID_label = new Label("sessionID:");
		 reviewCart_sessionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 reviewCart_content.add(reviewCart_sessionID_label);
		 GridPane.setConstraints(reviewCart_sessionID_label, 0, 0);
		 
		 reviewCart_sessionID_t = new TextField();
		 reviewCart_content.add(reviewCart_sessionID_t);
		 reviewCart_sessionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(reviewCart_sessionID_t, 1, 0);
		 operationPanels.put("reviewCart", reviewCart);
		 
		 // ==================== GridPane_modifyCart ====================
		 GridPane modifyCart = new GridPane();
		 modifyCart.setHgap(4);
		 modifyCart.setVgap(6);
		 modifyCart.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> modifyCart_content = modifyCart.getChildren();
		 Label modifyCart_sessionID_label = new Label("sessionID:");
		 modifyCart_sessionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 modifyCart_content.add(modifyCart_sessionID_label);
		 GridPane.setConstraints(modifyCart_sessionID_label, 0, 0);
		 
		 modifyCart_sessionID_t = new TextField();
		 modifyCart_content.add(modifyCart_sessionID_t);
		 modifyCart_sessionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(modifyCart_sessionID_t, 1, 0);
		 Label modifyCart_productID_label = new Label("productID:");
		 modifyCart_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 modifyCart_content.add(modifyCart_productID_label);
		 GridPane.setConstraints(modifyCart_productID_label, 0, 1);
		 
		 modifyCart_productID_t = new TextField();
		 modifyCart_content.add(modifyCart_productID_t);
		 modifyCart_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(modifyCart_productID_t, 1, 1);
		 Label modifyCart_quantity_label = new Label("quantity:");
		 modifyCart_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 modifyCart_content.add(modifyCart_quantity_label);
		 GridPane.setConstraints(modifyCart_quantity_label, 0, 2);
		 
		 modifyCart_quantity_t = new TextField();
		 modifyCart_content.add(modifyCart_quantity_t);
		 modifyCart_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(modifyCart_quantity_t, 1, 2);
		 operationPanels.put("modifyCart", modifyCart);
		 
		 // ==================== GridPane_giveFeedback ====================
		 GridPane giveFeedback = new GridPane();
		 giveFeedback.setHgap(4);
		 giveFeedback.setVgap(6);
		 giveFeedback.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> giveFeedback_content = giveFeedback.getChildren();
		 Label giveFeedback_textFeedback_label = new Label("textFeedback:");
		 giveFeedback_textFeedback_label.setMinWidth(Region.USE_PREF_SIZE);
		 giveFeedback_content.add(giveFeedback_textFeedback_label);
		 GridPane.setConstraints(giveFeedback_textFeedback_label, 0, 0);
		 
		 giveFeedback_textFeedback_t = new TextField();
		 giveFeedback_content.add(giveFeedback_textFeedback_t);
		 giveFeedback_textFeedback_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(giveFeedback_textFeedback_t, 1, 0);
		 Label giveFeedback_customerID_label = new Label("customerID:");
		 giveFeedback_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 giveFeedback_content.add(giveFeedback_customerID_label);
		 GridPane.setConstraints(giveFeedback_customerID_label, 0, 1);
		 
		 giveFeedback_customerID_t = new TextField();
		 giveFeedback_content.add(giveFeedback_customerID_t);
		 giveFeedback_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(giveFeedback_customerID_t, 1, 1);
		 Label giveFeedback_feedbackID_label = new Label("feedbackID:");
		 giveFeedback_feedbackID_label.setMinWidth(Region.USE_PREF_SIZE);
		 giveFeedback_content.add(giveFeedback_feedbackID_label);
		 GridPane.setConstraints(giveFeedback_feedbackID_label, 0, 2);
		 
		 giveFeedback_feedbackID_t = new TextField();
		 giveFeedback_content.add(giveFeedback_feedbackID_t);
		 giveFeedback_feedbackID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(giveFeedback_feedbackID_t, 1, 2);
		 operationPanels.put("giveFeedback", giveFeedback);
		 
		 // ==================== GridPane_saveFeedback ====================
		 GridPane saveFeedback = new GridPane();
		 saveFeedback.setHgap(4);
		 saveFeedback.setVgap(6);
		 saveFeedback.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> saveFeedback_content = saveFeedback.getChildren();
		 Label saveFeedback_customerID_label = new Label("customerID:");
		 saveFeedback_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveFeedback_content.add(saveFeedback_customerID_label);
		 GridPane.setConstraints(saveFeedback_customerID_label, 0, 0);
		 
		 saveFeedback_customerID_t = new TextField();
		 saveFeedback_content.add(saveFeedback_customerID_t);
		 saveFeedback_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveFeedback_customerID_t, 1, 0);
		 Label saveFeedback_textFeedback_label = new Label("textFeedback:");
		 saveFeedback_textFeedback_label.setMinWidth(Region.USE_PREF_SIZE);
		 saveFeedback_content.add(saveFeedback_textFeedback_label);
		 GridPane.setConstraints(saveFeedback_textFeedback_label, 0, 1);
		 
		 saveFeedback_textFeedback_t = new TextField();
		 saveFeedback_content.add(saveFeedback_textFeedback_t);
		 saveFeedback_textFeedback_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(saveFeedback_textFeedback_t, 1, 1);
		 operationPanels.put("saveFeedback", saveFeedback);
		 
		 // ==================== GridPane_getMembershipStatus ====================
		 GridPane getMembershipStatus = new GridPane();
		 getMembershipStatus.setHgap(4);
		 getMembershipStatus.setVgap(6);
		 getMembershipStatus.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getMembershipStatus_content = getMembershipStatus.getChildren();
		 Label getMembershipStatus_memberID_label = new Label("memberID:");
		 getMembershipStatus_memberID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getMembershipStatus_content.add(getMembershipStatus_memberID_label);
		 GridPane.setConstraints(getMembershipStatus_memberID_label, 0, 0);
		 
		 getMembershipStatus_memberID_t = new TextField();
		 getMembershipStatus_content.add(getMembershipStatus_memberID_t);
		 getMembershipStatus_memberID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getMembershipStatus_memberID_t, 1, 0);
		 Label getMembershipStatus_email_label = new Label("email:");
		 getMembershipStatus_email_label.setMinWidth(Region.USE_PREF_SIZE);
		 getMembershipStatus_content.add(getMembershipStatus_email_label);
		 GridPane.setConstraints(getMembershipStatus_email_label, 0, 1);
		 
		 getMembershipStatus_email_t = new TextField();
		 getMembershipStatus_content.add(getMembershipStatus_email_t);
		 getMembershipStatus_email_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getMembershipStatus_email_t, 1, 1);
		 operationPanels.put("getMembershipStatus", getMembershipStatus);
		 
		 // ==================== GridPane_showCurrentStatus ====================
		 GridPane showCurrentStatus = new GridPane();
		 showCurrentStatus.setHgap(4);
		 showCurrentStatus.setVgap(6);
		 showCurrentStatus.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> showCurrentStatus_content = showCurrentStatus.getChildren();
		 Label showCurrentStatus_label = new Label("This operation is no intput parameters..");
		 showCurrentStatus_label.setMinWidth(Region.USE_PREF_SIZE);
		 showCurrentStatus_content.add(showCurrentStatus_label);
		 GridPane.setConstraints(showCurrentStatus_label, 0, 0);
		 operationPanels.put("showCurrentStatus", showCurrentStatus);
		 
		 // ==================== GridPane_scanProducts ====================
		 GridPane scanProducts = new GridPane();
		 scanProducts.setHgap(4);
		 scanProducts.setVgap(6);
		 scanProducts.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> scanProducts_content = scanProducts.getChildren();
		 Label scanProducts_barcode_label = new Label("barcode:");
		 scanProducts_barcode_label.setMinWidth(Region.USE_PREF_SIZE);
		 scanProducts_content.add(scanProducts_barcode_label);
		 GridPane.setConstraints(scanProducts_barcode_label, 0, 0);
		 
		 scanProducts_barcode_t = new TextField();
		 scanProducts_content.add(scanProducts_barcode_t);
		 scanProducts_barcode_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(scanProducts_barcode_t, 1, 0);
		 Label scanProducts_quantity_label = new Label("quantity:");
		 scanProducts_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 scanProducts_content.add(scanProducts_quantity_label);
		 GridPane.setConstraints(scanProducts_quantity_label, 0, 1);
		 
		 scanProducts_quantity_t = new TextField();
		 scanProducts_content.add(scanProducts_quantity_t);
		 scanProducts_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(scanProducts_quantity_t, 1, 1);
		 operationPanels.put("scanProducts", scanProducts);
		 Label scanProducts_CartID_label = new Label("cartID:");
		 scanProducts_CartID_label.setMinWidth(Region.USE_PREF_SIZE);
		 scanProducts_content.add(scanProducts_CartID_label);
		 GridPane.setConstraints(scanProducts_CartID_label, 0, 2);
		 
		 updateCart_quantity_t = new TextField();
		 scanProducts_content.add(updateCart_quantity_t);
		 updateCart_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(updateCart_quantity_t, 1, 2);
		 
		 // ==================== GridPane_updateCart ====================
		 GridPane updateCart = new GridPane();
		 updateCart.setHgap(4);
		 updateCart.setVgap(6);
		 updateCart.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> updateCart_content = updateCart.getChildren();
		 Label updateCart_productID_label = new Label("productID:");
		 updateCart_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 updateCart_content.add(updateCart_productID_label);
		 GridPane.setConstraints(updateCart_productID_label, 0, 0);
		 
		 updateCart_productID_t = new TextField();
		 updateCart_content.add(updateCart_productID_t);
		 updateCart_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(updateCart_productID_t, 1, 0);
		 Label updateCart_productName_label = new Label("productName:");
		 updateCart_productName_label.setMinWidth(Region.USE_PREF_SIZE);
		 updateCart_content.add(updateCart_productName_label);
		 GridPane.setConstraints(updateCart_productName_label, 0, 1);
		 
		 updateCart_productName_t = new TextField();
		 updateCart_content.add(updateCart_productName_t);
		 updateCart_productName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(updateCart_productName_t, 1, 1);
		 Label updateCart_quantity_label = new Label("quantity:");
		 updateCart_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 updateCart_content.add(updateCart_quantity_label);
		 GridPane.setConstraints(updateCart_quantity_label, 0, 2);
		 
		 updateCart_quantity_t = new TextField();
		 updateCart_content.add(updateCart_quantity_t);
		 updateCart_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(updateCart_quantity_t, 1, 2);
		 Label updateCart_price_label = new Label("price:");
		 updateCart_price_label.setMinWidth(Region.USE_PREF_SIZE);
		 updateCart_content.add(updateCart_price_label);
		 GridPane.setConstraints(updateCart_price_label, 0, 3);
		 
		 updateCart_price_t = new TextField();
		 updateCart_content.add(updateCart_price_t);
		 updateCart_price_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(updateCart_price_t, 1, 3);
		 operationPanels.put("updateCart", updateCart);
		 
		 // ==================== GridPane_paymentProcess ====================
		 GridPane paymentProcess = new GridPane();
		 paymentProcess.setHgap(4);
		 paymentProcess.setVgap(6);
		 paymentProcess.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> paymentProcess_content = paymentProcess.getChildren();
		 Label paymentProcess_paymentMethod_label = new Label("paymentMethod:");
		 paymentProcess_paymentMethod_label.setMinWidth(Region.USE_PREF_SIZE);
		 paymentProcess_content.add(paymentProcess_paymentMethod_label);
		 GridPane.setConstraints(paymentProcess_paymentMethod_label, 0, 0);
		 
		 paymentProcess_paymentMethod_t = new TextField();
		 paymentProcess_content.add(paymentProcess_paymentMethod_t);
		 paymentProcess_paymentMethod_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(paymentProcess_paymentMethod_t, 1, 0);
		 Label paymentProcess_totalAmount_label = new Label("totalAmount:");
		 paymentProcess_totalAmount_label.setMinWidth(Region.USE_PREF_SIZE);
		 paymentProcess_content.add(paymentProcess_totalAmount_label);
		 GridPane.setConstraints(paymentProcess_totalAmount_label, 0, 1);
		 
		 paymentProcess_totalAmount_t = new TextField();
		 paymentProcess_content.add(paymentProcess_totalAmount_t);
		 paymentProcess_totalAmount_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(paymentProcess_totalAmount_t, 1, 1);
		 Label paymentProcess_customerID_label = new Label("customerID:");
		 paymentProcess_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 paymentProcess_content.add(paymentProcess_customerID_label);
		 GridPane.setConstraints(paymentProcess_customerID_label, 0, 2);
		 
		 paymentProcess_customerID_t = new TextField();
		 paymentProcess_content.add(paymentProcess_customerID_t);
		 paymentProcess_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(paymentProcess_customerID_t, 1, 2);
		 Label paymentProcess_orderID_label = new Label("orderID:");
		 paymentProcess_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 paymentProcess_content.add(paymentProcess_orderID_label);
		 GridPane.setConstraints(paymentProcess_orderID_label, 0, 3);
		 
		 paymentProcess_orderID_t = new TextField();
		 paymentProcess_content.add(paymentProcess_orderID_t);
		 paymentProcess_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(paymentProcess_orderID_t, 1, 3);
		 Label paymentProcess_transactionID_label = new Label("transactionID:");
		 paymentProcess_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 paymentProcess_content.add(paymentProcess_transactionID_label);
		 GridPane.setConstraints(paymentProcess_transactionID_label, 0, 4);
		 
		 paymentProcess_transactionID_t = new TextField();
		 paymentProcess_content.add(paymentProcess_transactionID_t);
		 paymentProcess_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(paymentProcess_transactionID_t, 1, 4);
		 operationPanels.put("paymentProcess", paymentProcess);
		 
		 // ==================== GridPane_addLoyaltyPoints ====================
		 GridPane addLoyaltyPoints = new GridPane();
		 addLoyaltyPoints.setHgap(4);
		 addLoyaltyPoints.setVgap(6);
		 addLoyaltyPoints.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> addLoyaltyPoints_content = addLoyaltyPoints.getChildren();
		 Label addLoyaltyPoints_points_label = new Label("points:");
		 addLoyaltyPoints_points_label.setMinWidth(Region.USE_PREF_SIZE);
		 addLoyaltyPoints_content.add(addLoyaltyPoints_points_label);
		 GridPane.setConstraints(addLoyaltyPoints_points_label, 0, 0);
		 
		 addLoyaltyPoints_points_t = new TextField();
		 addLoyaltyPoints_content.add(addLoyaltyPoints_points_t);
		 addLoyaltyPoints_points_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(addLoyaltyPoints_points_t, 1, 0);
		 Label addLoyaltyPoints_memberID_label = new Label("memberID:");
		 addLoyaltyPoints_memberID_label.setMinWidth(Region.USE_PREF_SIZE);
		 addLoyaltyPoints_content.add(addLoyaltyPoints_memberID_label);
		 GridPane.setConstraints(addLoyaltyPoints_memberID_label, 0, 1);
		 
		 addLoyaltyPoints_memberID_t = new TextField();
		 addLoyaltyPoints_content.add(addLoyaltyPoints_memberID_t);
		 addLoyaltyPoints_memberID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(addLoyaltyPoints_memberID_t, 1, 1);
		 operationPanels.put("addLoyaltyPoints", addLoyaltyPoints);
		 
		 // ==================== GridPane_getCustomerID ====================
		 GridPane getCustomerID = new GridPane();
		 getCustomerID.setHgap(4);
		 getCustomerID.setVgap(6);
		 getCustomerID.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getCustomerID_content = getCustomerID.getChildren();
		 Label getCustomerID_customerID_label = new Label("customerID:");
		 getCustomerID_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getCustomerID_content.add(getCustomerID_customerID_label);
		 GridPane.setConstraints(getCustomerID_customerID_label, 0, 0);
		 
		 getCustomerID_customerID_t = new TextField();
		 getCustomerID_content.add(getCustomerID_customerID_t);
		 getCustomerID_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getCustomerID_customerID_t, 1, 0);
		 Label getCustomerID_transactionID_label = new Label("transactionID:");
		 getCustomerID_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getCustomerID_content.add(getCustomerID_transactionID_label);
		 GridPane.setConstraints(getCustomerID_transactionID_label, 0, 1);
		 
		 getCustomerID_transactionID_t = new TextField();
		 getCustomerID_content.add(getCustomerID_transactionID_t);
		 getCustomerID_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getCustomerID_transactionID_t, 1, 1);
		 Label getCustomerID_reasonOfReturn_label = new Label("reasonOfReturn:");
		 getCustomerID_reasonOfReturn_label.setMinWidth(Region.USE_PREF_SIZE);
		 getCustomerID_content.add(getCustomerID_reasonOfReturn_label);
		 GridPane.setConstraints(getCustomerID_reasonOfReturn_label, 0, 2);
		 
		 getCustomerID_reasonOfReturn_t = new TextField();
		 getCustomerID_content.add(getCustomerID_reasonOfReturn_t);
		 getCustomerID_reasonOfReturn_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getCustomerID_reasonOfReturn_t, 1, 2);
		 Label getCustomerID_productID_label = new Label("productID:");
		 getCustomerID_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getCustomerID_content.add(getCustomerID_productID_label);
		 GridPane.setConstraints(getCustomerID_productID_label, 0, 3);
		 
		 getCustomerID_productID_t = new TextField();
		 getCustomerID_content.add(getCustomerID_productID_t);
		 getCustomerID_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getCustomerID_productID_t, 1, 3);
		 operationPanels.put("getCustomerID", getCustomerID);
		 
		 // ==================== GridPane_getUserDetails ====================
		 GridPane getUserDetails = new GridPane();
		 getUserDetails.setHgap(4);
		 getUserDetails.setVgap(6);
		 getUserDetails.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getUserDetails_content = getUserDetails.getChildren();
		 Label getUserDetails_customerID_label = new Label("customerID:");
		 getUserDetails_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getUserDetails_content.add(getUserDetails_customerID_label);
		 GridPane.setConstraints(getUserDetails_customerID_label, 0, 0);
		 
		 getUserDetails_customerID_t = new TextField();
		 getUserDetails_content.add(getUserDetails_customerID_t);
		 getUserDetails_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getUserDetails_customerID_t, 1, 0);
		 Label getUserDetails_transactionID_label = new Label("transactionID:");
		 getUserDetails_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getUserDetails_content.add(getUserDetails_transactionID_label);
		 GridPane.setConstraints(getUserDetails_transactionID_label, 0, 1);
		 
		 getUserDetails_transactionID_t = new TextField();
		 getUserDetails_content.add(getUserDetails_transactionID_t);
		 getUserDetails_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getUserDetails_transactionID_t, 1, 1);
		 Label getUserDetails_orderID_label = new Label("orderID:");
		 getUserDetails_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getUserDetails_content.add(getUserDetails_orderID_label);
		 GridPane.setConstraints(getUserDetails_orderID_label, 0, 2);
		 
		 getUserDetails_orderID_t = new TextField();
		 getUserDetails_content.add(getUserDetails_orderID_t);
		 getUserDetails_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getUserDetails_orderID_t, 1, 2);
		 operationPanels.put("getUserDetails", getUserDetails);
		 
		 // ==================== GridPane_printReciept ====================
		 GridPane printReciept = new GridPane();
		 printReciept.setHgap(4);
		 printReciept.setVgap(6);
		 printReciept.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> printReciept_content = printReciept.getChildren();
		 Label printReciept_transactionID_label = new Label("transactionID:");
		 printReciept_transactionID_label.setMinWidth(Region.USE_PREF_SIZE);
		 printReciept_content.add(printReciept_transactionID_label);
		 GridPane.setConstraints(printReciept_transactionID_label, 0, 0);
		 
		 printReciept_transactionID_t = new TextField();
		 printReciept_content.add(printReciept_transactionID_t);
		 printReciept_transactionID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(printReciept_transactionID_t, 1, 0);
		 Label printReciept_customerID_label = new Label("customerID:");
		 printReciept_customerID_label.setMinWidth(Region.USE_PREF_SIZE);
		 printReciept_content.add(printReciept_customerID_label);
		 GridPane.setConstraints(printReciept_customerID_label, 0, 1);
		 
		 printReciept_customerID_t = new TextField();
		 printReciept_content.add(printReciept_customerID_t);
		 printReciept_customerID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(printReciept_customerID_t, 1, 1);
		 Label printReciept_orderID_label = new Label("orderID:");
		 printReciept_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 printReciept_content.add(printReciept_orderID_label);
		 GridPane.setConstraints(printReciept_orderID_label, 0, 2);
		 
		 printReciept_orderID_t = new TextField();
		 printReciept_content.add(printReciept_orderID_t);
		 printReciept_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(printReciept_orderID_t, 1, 2);
		 Label printReciept_cartID_label = new Label("cartID:");
		 printReciept_cartID_label.setMinWidth(Region.USE_PREF_SIZE);
		 printReciept_content.add(printReciept_cartID_label);
		 GridPane.setConstraints(printReciept_cartID_label, 0, 3);
		 
		 printReciept_cartID_t = new TextField();
		 printReciept_content.add(printReciept_cartID_t);
		 printReciept_cartID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(printReciept_cartID_t, 1, 3);
		 Label printReciept_receiptID_label = new Label("receiptID:");
		 printReciept_receiptID_label.setMinWidth(Region.USE_PREF_SIZE);
		 printReciept_content.add(printReciept_receiptID_label);
		 GridPane.setConstraints(printReciept_receiptID_label, 0, 4);
		 
		 printReciept_receiptID_t = new TextField();
		 printReciept_content.add(printReciept_receiptID_t);
		 printReciept_receiptID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(printReciept_receiptID_t, 1, 4);
		 operationPanels.put("printReciept", printReciept);
		 
		 // ==================== GridPane_processingUserPayment ====================
		 GridPane processingUserPayment = new GridPane();
		 processingUserPayment.setHgap(4);
		 processingUserPayment.setVgap(6);
		 processingUserPayment.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> processingUserPayment_content = processingUserPayment.getChildren();
		 Label processingUserPayment_creditcardNumber_label = new Label("creditcardNumber:");
		 processingUserPayment_creditcardNumber_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingUserPayment_content.add(processingUserPayment_creditcardNumber_label);
		 GridPane.setConstraints(processingUserPayment_creditcardNumber_label, 0, 0);
		 
		 processingUserPayment_creditcardNumber_t = new TextField();
		 processingUserPayment_content.add(processingUserPayment_creditcardNumber_t);
		 processingUserPayment_creditcardNumber_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingUserPayment_creditcardNumber_t, 1, 0);
		 Label processingUserPayment_expiryDate_label = new Label("expiryDate (yyyy-MM-dd):");
		 processingUserPayment_expiryDate_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingUserPayment_content.add(processingUserPayment_expiryDate_label);
		 GridPane.setConstraints(processingUserPayment_expiryDate_label, 0, 1);
		 
		 processingUserPayment_expiryDate_t = new TextField();
		 processingUserPayment_content.add(processingUserPayment_expiryDate_t);
		 processingUserPayment_expiryDate_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingUserPayment_expiryDate_t, 1, 1);
		 Label processingUserPayment_cvvCode_label = new Label("cvvCode:");
		 processingUserPayment_cvvCode_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingUserPayment_content.add(processingUserPayment_cvvCode_label);
		 GridPane.setConstraints(processingUserPayment_cvvCode_label, 0, 2);
		 
		 processingUserPayment_cvvCode_t = new TextField();
		 processingUserPayment_content.add(processingUserPayment_cvvCode_t);
		 processingUserPayment_cvvCode_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingUserPayment_cvvCode_t, 1, 2);
		 operationPanels.put("processingUserPayment", processingUserPayment);
		 
		 // ==================== GridPane_bankContactandAuthorization ====================
		 GridPane bankContactandAuthorization = new GridPane();
		 bankContactandAuthorization.setHgap(4);
		 bankContactandAuthorization.setVgap(6);
		 bankContactandAuthorization.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> bankContactandAuthorization_content = bankContactandAuthorization.getChildren();
		 Label bankContactandAuthorization_label = new Label("This operation is no intput parameters..");
		 bankContactandAuthorization_label.setMinWidth(Region.USE_PREF_SIZE);
		 bankContactandAuthorization_content.add(bankContactandAuthorization_label);
		 GridPane.setConstraints(bankContactandAuthorization_label, 0, 0);
		 operationPanels.put("bankContactandAuthorization", bankContactandAuthorization);
		 
		 // ==================== GridPane_processingInStoreUserPayment ====================
		 GridPane processingInStoreUserPayment = new GridPane();
		 processingInStoreUserPayment.setHgap(4);
		 processingInStoreUserPayment.setVgap(6);
		 processingInStoreUserPayment.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> processingInStoreUserPayment_content = processingInStoreUserPayment.getChildren();
		 Label processingInStoreUserPayment_cerditCardNumber_label = new Label("cerditCardNumber:");
		 processingInStoreUserPayment_cerditCardNumber_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_cerditCardNumber_label);
		 GridPane.setConstraints(processingInStoreUserPayment_cerditCardNumber_label, 0, 0);
		 
		 processingInStoreUserPayment_cerditCardNumber_t = new TextField();
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_cerditCardNumber_t);
		 processingInStoreUserPayment_cerditCardNumber_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingInStoreUserPayment_cerditCardNumber_t, 1, 0);
		 Label processingInStoreUserPayment_expiryDate_label = new Label("expiryDate (yyyy-MM-dd):");
		 processingInStoreUserPayment_expiryDate_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_expiryDate_label);
		 GridPane.setConstraints(processingInStoreUserPayment_expiryDate_label, 0, 1);
		 
		 processingInStoreUserPayment_expiryDate_t = new TextField();
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_expiryDate_t);
		 processingInStoreUserPayment_expiryDate_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingInStoreUserPayment_expiryDate_t, 1, 1);
		 Label processingInStoreUserPayment_cvvCode_label = new Label("cvvCode:");
		 processingInStoreUserPayment_cvvCode_label.setMinWidth(Region.USE_PREF_SIZE);
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_cvvCode_label);
		 GridPane.setConstraints(processingInStoreUserPayment_cvvCode_label, 0, 2);
		 
		 processingInStoreUserPayment_cvvCode_t = new TextField();
		 processingInStoreUserPayment_content.add(processingInStoreUserPayment_cvvCode_t);
		 processingInStoreUserPayment_cvvCode_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(processingInStoreUserPayment_cvvCode_t, 1, 2);
		 operationPanels.put("processingInStoreUserPayment", processingInStoreUserPayment);
		 
		 // ==================== GridPane_bankContactandAuthorizationInStore ====================
		 GridPane bankContactandAuthorizationInStore = new GridPane();
		 bankContactandAuthorizationInStore.setHgap(4);
		 bankContactandAuthorizationInStore.setVgap(6);
		 bankContactandAuthorizationInStore.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> bankContactandAuthorizationInStore_content = bankContactandAuthorizationInStore.getChildren();
		 Label bankContactandAuthorizationInStore_label = new Label("This operation is no intput parameters..");
		 bankContactandAuthorizationInStore_label.setMinWidth(Region.USE_PREF_SIZE);
		 bankContactandAuthorizationInStore_content.add(bankContactandAuthorizationInStore_label);
		 GridPane.setConstraints(bankContactandAuthorizationInStore_label, 0, 0);
		 operationPanels.put("bankContactandAuthorizationInStore", bankContactandAuthorizationInStore);
		 
		 // ==================== GridPane_cashPayment ====================
		 GridPane cashPayment = new GridPane();
		 cashPayment.setHgap(4);
		 cashPayment.setVgap(6);
		 cashPayment.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> cashPayment_content = cashPayment.getChildren();
		 Label cashPayment_amount_label = new Label("amount:");
		 cashPayment_amount_label.setMinWidth(Region.USE_PREF_SIZE);
		 cashPayment_content.add(cashPayment_amount_label);
		 GridPane.setConstraints(cashPayment_amount_label, 0, 0);
		 
		 cashPayment_amount_t = new TextField();
		 cashPayment_content.add(cashPayment_amount_t);
		 cashPayment_amount_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cashPayment_amount_t, 1, 0);
		 Label cashPayment_cartID_label = new Label("cartID:");
		 cashPayment_cartID_label.setMinWidth(Region.USE_PREF_SIZE);
		 cashPayment_content.add(cashPayment_cartID_label);
		 GridPane.setConstraints(cashPayment_cartID_label, 0, 1);
		 
		 cashPayment_cartID_t = new TextField();
		 cashPayment_content.add(cashPayment_cartID_t);
		 cashPayment_cartID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cashPayment_cartID_t, 1, 1);
		 Label cashPayment_cashByUser_label = new Label("cashByUser:");
		 cashPayment_cashByUser_label.setMinWidth(Region.USE_PREF_SIZE);
		 cashPayment_content.add(cashPayment_cashByUser_label);
		 GridPane.setConstraints(cashPayment_cashByUser_label, 0, 2);
		 
		 cashPayment_cashByUser_t = new TextField();
		 cashPayment_content.add(cashPayment_cashByUser_t);
		 cashPayment_cashByUser_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(cashPayment_cashByUser_t, 1, 2);
		 operationPanels.put("cashPayment", cashPayment);
		 
		 // ==================== GridPane_generateReport ====================
		 GridPane generateReport = new GridPane();
		 generateReport.setHgap(4);
		 generateReport.setVgap(6);
		 generateReport.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> generateReport_content = generateReport.getChildren();
		 Label generateReport_type_label = new Label("type:");
		 generateReport_type_label.setMinWidth(Region.USE_PREF_SIZE);
		 generateReport_content.add(generateReport_type_label);
		 GridPane.setConstraints(generateReport_type_label, 0, 0);
		 
		 generateReport_type_t = new TextField();
		 generateReport_content.add(generateReport_type_t);
		 generateReport_type_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(generateReport_type_t, 1, 0);
		 Label generateReport_startDate_label = new Label("startDate (yyyy-MM-dd):");
		 generateReport_startDate_label.setMinWidth(Region.USE_PREF_SIZE);
		 generateReport_content.add(generateReport_startDate_label);
		 GridPane.setConstraints(generateReport_startDate_label, 0, 1);
		 
		 generateReport_startDate_t = new TextField();
		 generateReport_content.add(generateReport_startDate_t);
		 generateReport_startDate_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(generateReport_startDate_t, 1, 1);
		 Label generateReport_endDate_label = new Label("endDate (yyyy-MM-dd):");
		 generateReport_endDate_label.setMinWidth(Region.USE_PREF_SIZE);
		 generateReport_content.add(generateReport_endDate_label);
		 GridPane.setConstraints(generateReport_endDate_label, 0, 2);
		 
		 generateReport_endDate_t = new TextField();
		 generateReport_content.add(generateReport_endDate_t);
		 generateReport_endDate_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(generateReport_endDate_t, 1, 2);
		 Label generateReport_reportID_label = new Label("reportID:");
		 generateReport_reportID_label.setMinWidth(Region.USE_PREF_SIZE);
		 generateReport_content.add(generateReport_reportID_label);
		 GridPane.setConstraints(generateReport_reportID_label, 0, 3);
		 
		 generateReport_reportID_t = new TextField();
		 generateReport_content.add(generateReport_reportID_t);
		 generateReport_reportID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(generateReport_reportID_t, 1, 3);
		 operationPanels.put("generateReport", generateReport);
		 
		 // ==================== GridPane_getReportType ====================
		 GridPane getReportType = new GridPane();
		 getReportType.setHgap(4);
		 getReportType.setVgap(6);
		 getReportType.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> getReportType_content = getReportType.getChildren();
		 Label getReportType_reportID_label = new Label("reportID:");
		 getReportType_reportID_label.setMinWidth(Region.USE_PREF_SIZE);
		 getReportType_content.add(getReportType_reportID_label);
		 GridPane.setConstraints(getReportType_reportID_label, 0, 0);
		 
		 getReportType_reportID_t = new TextField();
		 getReportType_content.add(getReportType_reportID_t);
		 getReportType_reportID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(getReportType_reportID_t, 1, 0);
		 operationPanels.put("getReportType", getReportType);
		 
		 // ==================== GridPane_viewAllReports ====================
		 GridPane viewAllReports = new GridPane();
		 viewAllReports.setHgap(4);
		 viewAllReports.setVgap(6);
		 viewAllReports.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> viewAllReports_content = viewAllReports.getChildren();
		 Label viewAllReports_label = new Label("This operation is no intput parameters..");
		 viewAllReports_label.setMinWidth(Region.USE_PREF_SIZE);
		 viewAllReports_content.add(viewAllReports_label);
		 GridPane.setConstraints(viewAllReports_label, 0, 0);
		 operationPanels.put("viewAllReports", viewAllReports);
		 
		 // ==================== GridPane_sendToSupplier ====================
		 GridPane sendToSupplier = new GridPane();
		 sendToSupplier.setHgap(4);
		 sendToSupplier.setVgap(6);
		 sendToSupplier.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> sendToSupplier_content = sendToSupplier.getChildren();
		 Label sendToSupplier_supplierID_label = new Label("supplierID:");
		 sendToSupplier_supplierID_label.setMinWidth(Region.USE_PREF_SIZE);
		 sendToSupplier_content.add(sendToSupplier_supplierID_label);
		 GridPane.setConstraints(sendToSupplier_supplierID_label, 0, 0);
		 
		 sendToSupplier_supplierID_t = new TextField();
		 sendToSupplier_content.add(sendToSupplier_supplierID_t);
		 sendToSupplier_supplierID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(sendToSupplier_supplierID_t, 1, 0);
		 Label sendToSupplier_productID_label = new Label("productID:");
		 sendToSupplier_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 sendToSupplier_content.add(sendToSupplier_productID_label);
		 GridPane.setConstraints(sendToSupplier_productID_label, 0, 1);
		 
		 sendToSupplier_productID_t = new TextField();
		 sendToSupplier_content.add(sendToSupplier_productID_t);
		 sendToSupplier_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(sendToSupplier_productID_t, 1, 1);
		 Label sendToSupplier_supplierOrderID_label = new Label("supplierOrderID:");
		 sendToSupplier_supplierOrderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 sendToSupplier_content.add(sendToSupplier_supplierOrderID_label);
		 GridPane.setConstraints(sendToSupplier_supplierOrderID_label, 0, 2);
		 
		 sendToSupplier_supplierOrderID_t = new TextField();
		 sendToSupplier_content.add(sendToSupplier_supplierOrderID_t);
		 sendToSupplier_supplierOrderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(sendToSupplier_supplierOrderID_t, 1, 2);
		 operationPanels.put("sendToSupplier", sendToSupplier);
		 
		 // ==================== GridPane_recordRestock ====================
		 GridPane recordRestock = new GridPane();
		 recordRestock.setHgap(4);
		 recordRestock.setVgap(6);
		 recordRestock.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> recordRestock_content = recordRestock.getChildren();
		 Label recordRestock_productName_label = new Label("productName:");
		 recordRestock_productName_label.setMinWidth(Region.USE_PREF_SIZE);
		 recordRestock_content.add(recordRestock_productName_label);
		 GridPane.setConstraints(recordRestock_productName_label, 0, 0);
		 
		 recordRestock_productName_t = new TextField();
		 recordRestock_content.add(recordRestock_productName_t);
		 recordRestock_productName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(recordRestock_productName_t, 1, 0);
		 Label recordRestock_productID_label = new Label("productID:");
		 recordRestock_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 recordRestock_content.add(recordRestock_productID_label);
		 GridPane.setConstraints(recordRestock_productID_label, 0, 1);
		 
		 recordRestock_productID_t = new TextField();
		 recordRestock_content.add(recordRestock_productID_t);
		 recordRestock_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(recordRestock_productID_t, 1, 1);
		 Label recordRestock_quantity_label = new Label("quantity:");
		 recordRestock_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 recordRestock_content.add(recordRestock_quantity_label);
		 GridPane.setConstraints(recordRestock_quantity_label, 0, 2);
		 
		 recordRestock_quantity_t = new TextField();
		 recordRestock_content.add(recordRestock_quantity_t);
		 recordRestock_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(recordRestock_quantity_t, 1, 2);
		 operationPanels.put("recordRestock", recordRestock);
		 
		 // ==================== GridPane_viewInventoryStockLevel ====================
		 GridPane viewInventoryStockLevel = new GridPane();
		 viewInventoryStockLevel.setHgap(4);
		 viewInventoryStockLevel.setVgap(6);
		 viewInventoryStockLevel.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> viewInventoryStockLevel_content = viewInventoryStockLevel.getChildren();
		 Label viewInventoryStockLevel_label = new Label("This operation is no intput parameters..");
		 viewInventoryStockLevel_label.setMinWidth(Region.USE_PREF_SIZE);
		 viewInventoryStockLevel_content.add(viewInventoryStockLevel_label);
		 GridPane.setConstraints(viewInventoryStockLevel_label, 0, 0);
		 operationPanels.put("viewInventoryStockLevel", viewInventoryStockLevel);
		 
		 // ==================== GridPane_orderStockProducts ====================
		 GridPane orderStockProducts = new GridPane();
		 orderStockProducts.setHgap(4);
		 orderStockProducts.setVgap(6);
		 orderStockProducts.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> orderStockProducts_content = orderStockProducts.getChildren();
		 Label orderStockProducts_productID_label = new Label("productID:");
		 orderStockProducts_productID_label.setMinWidth(Region.USE_PREF_SIZE);
		 orderStockProducts_content.add(orderStockProducts_productID_label);
		 GridPane.setConstraints(orderStockProducts_productID_label, 0, 0);
		 
		 orderStockProducts_productID_t = new TextField();
		 orderStockProducts_content.add(orderStockProducts_productID_t);
		 orderStockProducts_productID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(orderStockProducts_productID_t, 1, 0);
		 Label orderStockProducts_quantity_label = new Label("quantity:");
		 orderStockProducts_quantity_label.setMinWidth(Region.USE_PREF_SIZE);
		 orderStockProducts_content.add(orderStockProducts_quantity_label);
		 GridPane.setConstraints(orderStockProducts_quantity_label, 0, 1);
		 
		 orderStockProducts_quantity_t = new TextField();
		 orderStockProducts_content.add(orderStockProducts_quantity_t);
		 orderStockProducts_quantity_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(orderStockProducts_quantity_t, 1, 1);
		 Label orderStockProducts_restockProductsID_label = new Label("restockProductsID:");
		 orderStockProducts_restockProductsID_label.setMinWidth(Region.USE_PREF_SIZE);
		 orderStockProducts_content.add(orderStockProducts_restockProductsID_label);
		 GridPane.setConstraints(orderStockProducts_restockProductsID_label, 0, 2);
		 
		 orderStockProducts_restockProductsID_t = new TextField();
		 orderStockProducts_content.add(orderStockProducts_restockProductsID_t);
		 orderStockProducts_restockProductsID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(orderStockProducts_restockProductsID_t, 1, 2);
		 operationPanels.put("orderStockProducts", orderStockProducts);
		 
		 // ==================== GridPane_newOrder ====================
		 GridPane newOrder = new GridPane();
		 newOrder.setHgap(4);
		 newOrder.setVgap(6);
		 newOrder.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> newOrder_content = newOrder.getChildren();
		 Label newOrder_orderID_label = new Label("orderID:");
		 newOrder_orderID_label.setMinWidth(Region.USE_PREF_SIZE);
		 newOrder_content.add(newOrder_orderID_label);
		 GridPane.setConstraints(newOrder_orderID_label, 0, 0);
		 
		 newOrder_orderID_t = new TextField();
		 newOrder_content.add(newOrder_orderID_t);
		 newOrder_orderID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(newOrder_orderID_t, 1, 0);
		 Label newOrder_dateOfPurchase_label = new Label("dateOfPurchase:");
		 newOrder_dateOfPurchase_label.setMinWidth(Region.USE_PREF_SIZE);
		 newOrder_content.add(newOrder_dateOfPurchase_label);
		 GridPane.setConstraints(newOrder_dateOfPurchase_label, 0, 1);
		 
		 newOrder_dateOfPurchase_t = new TextField();
		 newOrder_content.add(newOrder_dateOfPurchase_t);
		 newOrder_dateOfPurchase_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(newOrder_dateOfPurchase_t, 1, 1);
		 Label newOrder_totalPrice_label = new Label("totalPrice:");
		 newOrder_totalPrice_label.setMinWidth(Region.USE_PREF_SIZE);
		 newOrder_content.add(newOrder_totalPrice_label);
		 GridPane.setConstraints(newOrder_totalPrice_label, 0, 2);
		 
		 newOrder_totalPrice_t = new TextField();
		 newOrder_content.add(newOrder_totalPrice_t);
		 newOrder_totalPrice_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(newOrder_totalPrice_t, 1, 2);
		 Label newOrder_produceList_label = new Label("produceList:");
		 newOrder_produceList_label.setMinWidth(Region.USE_PREF_SIZE);
		 newOrder_content.add(newOrder_produceList_label);
		 GridPane.setConstraints(newOrder_produceList_label, 0, 3);
		 
		 newOrder_produceList_t = new TextField();
		 newOrder_content.add(newOrder_produceList_t);
		 newOrder_produceList_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(newOrder_produceList_t, 1, 3);
		 operationPanels.put("newOrder", newOrder);
		 
		 // ==================== GridPane_creatingNewSupplier ====================
		 GridPane creatingNewSupplier = new GridPane();
		 creatingNewSupplier.setHgap(4);
		 creatingNewSupplier.setVgap(6);
		 creatingNewSupplier.setPadding(new Insets(8, 8, 8, 8));
		 
		 ObservableList<Node> creatingNewSupplier_content = creatingNewSupplier.getChildren();
		 Label creatingNewSupplier_supplierID_label = new Label("supplierID:");
		 creatingNewSupplier_supplierID_label.setMinWidth(Region.USE_PREF_SIZE);
		 creatingNewSupplier_content.add(creatingNewSupplier_supplierID_label);
		 GridPane.setConstraints(creatingNewSupplier_supplierID_label, 0, 0);
		 
		 creatingNewSupplier_supplierID_t = new TextField();
		 creatingNewSupplier_content.add(creatingNewSupplier_supplierID_t);
		 creatingNewSupplier_supplierID_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(creatingNewSupplier_supplierID_t, 1, 0);
		 Label creatingNewSupplier_companyName_label = new Label("companyName:");
		 creatingNewSupplier_companyName_label.setMinWidth(Region.USE_PREF_SIZE);
		 creatingNewSupplier_content.add(creatingNewSupplier_companyName_label);
		 GridPane.setConstraints(creatingNewSupplier_companyName_label, 0, 1);
		 
		 creatingNewSupplier_companyName_t = new TextField();
		 creatingNewSupplier_content.add(creatingNewSupplier_companyName_t);
		 creatingNewSupplier_companyName_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(creatingNewSupplier_companyName_t, 1, 1);
		 Label creatingNewSupplier_contactDetails_label = new Label("contactDetails:");
		 creatingNewSupplier_contactDetails_label.setMinWidth(Region.USE_PREF_SIZE);
		 creatingNewSupplier_content.add(creatingNewSupplier_contactDetails_label);
		 GridPane.setConstraints(creatingNewSupplier_contactDetails_label, 0, 2);
		 
		 creatingNewSupplier_contactDetails_t = new TextField();
		 creatingNewSupplier_content.add(creatingNewSupplier_contactDetails_t);
		 creatingNewSupplier_contactDetails_t.setMinWidth(Region.USE_PREF_SIZE);
		 GridPane.setConstraints(creatingNewSupplier_contactDetails_t, 1, 2);
		 operationPanels.put("creatingNewSupplier", creatingNewSupplier);
		 
	}	

	public void actorTreeViewBinding() {
		
		 

		TreeItem<String> treeRootadministrator = new TreeItem<String>("Root node");
		
		
					 			
						 		
		treeRootadministrator.getChildren().addAll(Arrays.asList(
				));	
				
	 			treeRootadministrator.setExpanded(true);

		actor_treeview_administrator.setShowRoot(false);
		actor_treeview_administrator.setRoot(treeRootadministrator);
	 		
		actor_treeview_administrator.getSelectionModel().selectedItemProperty().addListener(
		 				 (observable, oldValue, newValue) -> { 
		 				 								
		 				 							 //clear the previous return
		 											 operation_return_pane.setContent(new Label());
		 											 
		 				 							 clickedOp = newValue.getValue();
		 				 							 GridPane op = operationPanels.get(clickedOp);
		 				 							 VBox vb = opInvariantPanel.get(clickedOp);
		 				 							 
		 				 							 //op pannel
		 				 							 if (op != null) {
		 				 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
		 				 								 
		 				 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
		 				 								 choosenOperation = new LinkedList<TextField>();
		 				 								 for (Node n : l) {
		 				 								 	 if (n instanceof TextField) {
		 				 								 	 	choosenOperation.add((TextField)n);
		 				 								 	  }
		 				 								 }
		 				 								 
		 				 								 definition.setText(definitions_map.get(newValue.getValue()));
		 				 								 precondition.setText(preconditions_map.get(newValue.getValue()));
		 				 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
		 				 								 
		 				 						     }
		 				 							 else {
		 				 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
		 				 								 l.setPadding(new Insets(8, 8, 8, 8));
		 				 								 operation_paras.setContent(l);
		 				 							 }	
		 				 							 
		 				 							 //op invariants
		 				 							 if (vb != null) {
		 				 							 	ScrollPane scrollPane = new ScrollPane(vb);
		 				 							 	scrollPane.setFitToWidth(true);
		 				 							 	invariants_panes.setMaxHeight(200); 
		 				 							 	//all_invariant_pane.setContent(scrollPane);	
		 				 							 	
		 				 							 	invariants_panes.setContent(scrollPane);
		 				 							 } else {
		 				 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
		 				 							     l.setPadding(new Insets(8, 8, 8, 8));
		 				 							     invariants_panes.setContent(l);
		 				 							 }
		 				 							 
		 				 							 //reset pre- and post-conditions area color
		 				 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
		 				 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
		 				 							 //reset condition panel title
		 				 							 precondition_pane.setText("Precondition");
		 				 							 postcondition_pane.setText("Postcondition");
		 				 						} 
		 				 				);

		
		
		 
		TreeItem<String> treeRootcustomerorloyaltymember = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_browseProducts = new TreeItem<String>("browseProducts");
			subTreeRoot_browseProducts.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("viewAllProducts"),
					 	new TreeItem<String>("searchProducts")
				 		));	
			TreeItem<String> subTreeRoot_checkOut = new TreeItem<String>("checkOut");
			subTreeRoot_checkOut.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("cartSummary"),
					 	new TreeItem<String>("makePayment"),
					 	new TreeItem<String>("getGuestUserDetails"),
					 	new TreeItem<String>("newOrder")
				 		));	
			TreeItem<String> subTreeRoot_returnProduct = new TreeItem<String>("returnProduct");
			subTreeRoot_returnProduct.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("getTransactionID"),
					 	new TreeItem<String>("productID"),
					 	new TreeItem<String>("getReason"),
					 	new TreeItem<String>("saveReturn")
				 		));	
			TreeItem<String> subTreeRoot_reviewCart = new TreeItem<String>("reviewCart");
			subTreeRoot_reviewCart.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("reviewCart")
				 		));	
			TreeItem<String> subTreeRoot_modifyCart = new TreeItem<String>("modifyCart");
			subTreeRoot_modifyCart.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("modifyCart")
				 		));	
			TreeItem<String> subTreeRoot_giveFeedback = new TreeItem<String>("giveFeedback");
			subTreeRoot_giveFeedback.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("giveFeedback"),
					 	new TreeItem<String>("saveFeedback")
				 		));	
			TreeItem<String> subTreeRoot_membershipStatus = new TreeItem<String>("membershipStatus");
			subTreeRoot_membershipStatus.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("getMembershipStatus"),
					 	new TreeItem<String>("showCurrentStatus")
				 		));	
			TreeItem<String> subTreeRoot_signup = new TreeItem<String>("signup");
			subTreeRoot_signup.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("customerRegUsername"),
					 	new TreeItem<String>("customerRegPassword"),
					 	new TreeItem<String>("customerDetails"),
					 	new TreeItem<String>("saveDetails")
				 		));	
		
		treeRootcustomerorloyaltymember.getChildren().addAll(Arrays.asList(
			subTreeRoot_browseProducts,
			subTreeRoot_checkOut,
			subTreeRoot_returnProduct,
			subTreeRoot_reviewCart,
			subTreeRoot_modifyCart,
			subTreeRoot_giveFeedback,
			subTreeRoot_membershipStatus,
			subTreeRoot_signup
					));
		treeRootcustomerorloyaltymember.getChildren().addAll(Arrays.asList(
			this.deepCopyTree(treeRootcustomerorloyaltymember)));
		
		treeRootcustomerorloyaltymember.setExpanded(true);

		actor_treeview_customerorloyaltymember.setShowRoot(false);
		actor_treeview_customerorloyaltymember.setRoot(treeRootcustomerorloyaltymember);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_customerorloyaltymember.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootcashier = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_scanProducts = new TreeItem<String>("scanProducts");
			subTreeRoot_scanProducts.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("scanProducts"),
					 	new TreeItem<String>("updateCart")
				 		));	
			TreeItem<String> subTreeRoot_processPayment = new TreeItem<String>("processPayment");
			subTreeRoot_processPayment.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("paymentProcess"),
					 	new TreeItem<String>("addLoyaltyPoints")
				 		));	
			TreeItem<String> subTreeRoot_processReturn = new TreeItem<String>("processReturn");
			subTreeRoot_processReturn.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("getCustomerID")
				 		));	
			TreeItem<String> subTreeRoot_printReceipt = new TreeItem<String>("printReceipt");
			subTreeRoot_printReceipt.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("getUserDetails"),
					 	new TreeItem<String>("printReciept")
				 		));	
			TreeItem<String> subTreeRoot_processCheckout = new TreeItem<String>("processCheckout");
			subTreeRoot_processCheckout.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("storeCartSummary"),
					 	new TreeItem<String>("viewSummary")
				 		));	
		
		treeRootcashier.getChildren().addAll(Arrays.asList(
			subTreeRoot_scanProducts,
			subTreeRoot_processPayment,
			subTreeRoot_processReturn,
			subTreeRoot_printReceipt,
			subTreeRoot_processCheckout
					));
		treeRootcashier.getChildren().addAll(Arrays.asList(
			this.deepCopyTree(treeRootcustomerorloyaltymember)
			));
		
		treeRootcashier.setExpanded(true);

		actor_treeview_cashier.setShowRoot(false);
		actor_treeview_cashier.setRoot(treeRootcashier);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_cashier.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootstoremanager = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_viewReports = new TreeItem<String>("viewReports");
			subTreeRoot_viewReports.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("viewAllReports"),
					 	new TreeItem<String>("getReportType"),
					 	new TreeItem<String>("generateReport")
				 		));	
			TreeItem<String> subTreeRoot_manageInventory = new TreeItem<String>("manageInventory");
			subTreeRoot_manageInventory.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("viewInventoryStockLevel"),
					 	new TreeItem<String>("recordRestock"),
					 	new TreeItem<String>("sendToSupplier"),
					 	new TreeItem<String>("orderStockProducts"),
					 	new TreeItem<String>("creatingNewSupplier")
				 		));	
			TreeItem<String> subTreeRoot_accessFeedback = new TreeItem<String>("accessFeedback");
			subTreeRoot_accessFeedback.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("viewAllFeedback"),
					 	new TreeItem<String>("handleFeedback"),
					 	new TreeItem<String>("immediateAction")
				 		));	
		
		treeRootstoremanager.getChildren().addAll(Arrays.asList(
			subTreeRoot_viewReports,
			subTreeRoot_manageInventory,
			subTreeRoot_accessFeedback
					));
		treeRootstoremanager.getChildren().addAll(Arrays.asList(
			this.deepCopyTree(treeRootcustomerorloyaltymember)
			));
		
		treeRootstoremanager.setExpanded(true);

		actor_treeview_storemanager.setShowRoot(false);
		actor_treeview_storemanager.setRoot(treeRootstoremanager);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_storemanager.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootsupplier = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_processOrders = new TreeItem<String>("processOrders");
			subTreeRoot_processOrders.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("processStoreOrder"),
					 	new TreeItem<String>("provideDeliveryInfo")
				 		));	
			TreeItem<String> subTreeRoot_viewNewOrders = new TreeItem<String>("viewNewOrders");
			subTreeRoot_viewNewOrders.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("viewOrders")
				 		));	
		
		treeRootsupplier.getChildren().addAll(Arrays.asList(
			subTreeRoot_processOrders,
			subTreeRoot_viewNewOrders
					));
		treeRootsupplier.getChildren().addAll(Arrays.asList(
			this.deepCopyTree(treeRootcustomerorloyaltymember)
			));
		
		treeRootsupplier.setExpanded(true);

		actor_treeview_supplier.setShowRoot(false);
		actor_treeview_supplier.setRoot(treeRootsupplier);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_supplier.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
		TreeItem<String> treeRootuser = new TreeItem<String>("Root node");
			TreeItem<String> subTreeRoot_systemLogin = new TreeItem<String>("systemLogin");
			subTreeRoot_systemLogin.getChildren().addAll(Arrays.asList(			 		    
					 	new TreeItem<String>("usernameInput"),
					 	new TreeItem<String>("passwordInput")
				 		));	
		
		treeRootuser.getChildren().addAll(Arrays.asList(
			subTreeRoot_systemLogin
					));
		
		treeRootuser.setExpanded(true);

		actor_treeview_user.setShowRoot(false);
		actor_treeview_user.setRoot(treeRootuser);
		
		//TreeView click, then open the GridPane for inputing parameters
		actor_treeview_user.getSelectionModel().selectedItemProperty().addListener(
						 (observable, oldValue, newValue) -> { 
						 								
						 							 //clear the previous return
													 operation_return_pane.setContent(new Label());
													 
						 							 clickedOp = newValue.getValue();
						 							 GridPane op = operationPanels.get(clickedOp);
						 							 VBox vb = opInvariantPanel.get(clickedOp);
						 							 
						 							 //op pannel
						 							 if (op != null) {
						 								 operation_paras.setContent(operationPanels.get(newValue.getValue()));
						 								 
						 								 ObservableList<Node> l = operationPanels.get(newValue.getValue()).getChildren();
						 								 choosenOperation = new LinkedList<TextField>();
						 								 for (Node n : l) {
						 								 	 if (n instanceof TextField) {
						 								 	 	choosenOperation.add((TextField)n);
						 								 	  }
						 								 }
						 								 
						 								 definition.setText(definitions_map.get(newValue.getValue()));
						 								 precondition.setText(preconditions_map.get(newValue.getValue()));
						 								 postcondition.setText(postconditions_map.get(newValue.getValue()));
						 								 
						 						     }
						 							 else {
						 								 Label l = new Label(newValue.getValue() + " is no contract information in requirement model.");
						 								 l.setPadding(new Insets(8, 8, 8, 8));
						 								 operation_paras.setContent(l);
						 							 }	
						 							 
						 							 //op invariants
						 							 if (vb != null) {
						 							 	ScrollPane scrollPane = new ScrollPane(vb);
						 							 	scrollPane.setFitToWidth(true);
						 							 	invariants_panes.setMaxHeight(200); 
						 							 	//all_invariant_pane.setContent(scrollPane);	
						 							 	
						 							 	invariants_panes.setContent(scrollPane);
						 							 } else {
						 							 	 Label l = new Label(newValue.getValue() + " is no related invariants");
						 							     l.setPadding(new Insets(8, 8, 8, 8));
						 							     invariants_panes.setContent(l);
						 							 }
						 							 
						 							 //reset pre- and post-conditions area color
						 							 precondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF ");
						 							 postcondition.setStyle("-fx-background-color:#FFFFFF; -fx-control-inner-background: #FFFFFF");
						 							 //reset condition panel title
						 							 precondition_pane.setText("Precondition");
						 							 postcondition_pane.setText("Postcondition");
						 						} 
						 				);
	}

	/**
	*    Execute Operation
	*/
	@FXML
	public void execute(ActionEvent event) {
		
		switch (clickedOp) {
		case "usernameInput" : usernameInput(); break;
		case "passwordInput" : passwordInput(); break;
		case "validationCheck" : validationCheck(); break;
		case "validationMessage" : validationMessage(); break;
		case "customerRegUsername" : customerRegUsername(); break;
		case "customerRegPassword" : customerRegPassword(); break;
		case "customerDetails" : customerDetails(); break;
		case "saveDetails" : saveDetails(); break;
		case "searchProducts" : searchProducts(); break;
		case "viewAllProducts" : viewAllProducts(); break;
		case "cartSummary" : cartSummary(); break;
		case "makePayment" : makePayment(); break;
		case "getGuestUserDetails" : getGuestUserDetails(); break;
		case "getTransactionID" : getTransactionID(); break;
		case "productID" : productID(); break;
		case "getReason" : getReason(); break;
		case "saveReturn" : saveReturn(); break;
		case "reviewCart" : reviewCart(); break;
		case "modifyCart" : modifyCart(); break;
		case "giveFeedback" : giveFeedback(); break;
		case "saveFeedback" : saveFeedback(); break;
		case "getMembershipStatus" : getMembershipStatus(); break;
		case "showCurrentStatus" : showCurrentStatus(); break;
		case "scanProducts" : scanProducts(); break;
		case "updateCart" : updateCart(); break;
		case "paymentProcess" : paymentProcess(); break;
		case "addLoyaltyPoints" : addLoyaltyPoints(); break;
		case "getCustomerID" : getCustomerID(); break;
		case "getUserDetails" : getUserDetails(); break;
		case "printReciept" : printReciept(); break;
		case "processingUserPayment" : processingUserPayment(); break;
		case "bankContactandAuthorization" : bankContactandAuthorization(); break;
		case "processingInStoreUserPayment" : processingInStoreUserPayment(); break;
		case "bankContactandAuthorizationInStore" : bankContactandAuthorizationInStore(); break;
		case "cashPayment" : cashPayment(); break;
		case "generateReport" : generateReport(); break;
		case "getReportType" : getReportType(); break;
		case "viewAllReports" : viewAllReports(); break;
		case "sendToSupplier" : sendToSupplier(); break;
		case "recordRestock" : recordRestock(); break;
		case "viewInventoryStockLevel" : viewInventoryStockLevel(); break;
		case "orderStockProducts" : orderStockProducts(); break;
		case "newOrder" : newOrder(); break;
		case "creatingNewSupplier" : creatingNewSupplier(); break;
		
		}
		
		System.out.println("execute buttion clicked");
		
		//checking relevant invariants
		opInvairantPanelUpdate();
	}

	/**
	*    Refresh All
	*/		
	@FXML
	public void refresh(ActionEvent event) {
		
		refreshAll();
		System.out.println("refresh all");
	}		
	
	/**
	*    Save All
	*/			
	@FXML
	public void save(ActionEvent event) {
		
		Stage stage = (Stage) mainPane.getScene().getWindow();
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Save State to File");
		fileChooser.setInitialFileName("*.state");
		fileChooser.getExtensionFilters().addAll(
		         new ExtensionFilter("RMCode State File", "*.state"));
		
		File file = fileChooser.showSaveDialog(stage);
		
		if (file != null) {
			System.out.println("save state to file " + file.getAbsolutePath());				
			EntityManager.save(file);
		}
	}
	
	/**
	*    Load All
	*/			
	@FXML
	public void load(ActionEvent event) {
		
		Stage stage = (Stage) mainPane.getScene().getWindow();
		
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open State File");
		fileChooser.getExtensionFilters().addAll(
		         new ExtensionFilter("RMCode State File", "*.state"));
		
		File file = fileChooser.showOpenDialog(stage);
		
		if (file != null) {
			System.out.println("choose file" + file.getAbsolutePath());
			EntityManager.load(file); 
		}
		
		//refresh GUI after load data
		refreshAll();
	}
	
	
	//precondition unsat dialog
	public void preconditionUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("Precondtion is not satisfied");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}
	
	//postcondition unsat dialog
	public void postconditionUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("Postcondtion is not satisfied");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}

	public void thirdpartyServiceUnSat() {
		
		Alert alert = new Alert(AlertType.WARNING, "");
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.initOwner(mainPane.getScene().getWindow());
        alert.getDialogPane().setContentText("third party service is exception");
        alert.getDialogPane().setHeaderText(null);
        alert.showAndWait();	
	}		
	
	
	public void usernameInput() {
		
		System.out.println("execute usernameInput");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: usernameInput in service: SystemLoginService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(systemloginservice_service.usernameInput(
			usernameInput_username_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void passwordInput() {
		
		System.out.println("execute passwordInput");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: passwordInput in service: SystemLoginService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(systemloginservice_service.passwordInput(
			passwordInput_password_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void validationCheck() {
		
		System.out.println("execute validationCheck");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: validationCheck in service: CredentialsCheckService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(credentialscheckservice_service.validationCheck(
			validationCheck_username_t.getText(),
			validationCheck_password_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void validationMessage() {
		
		System.out.println("execute validationMessage");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: validationMessage in service: CredentialsCheckService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(credentialscheckservice_service.validationMessage(
			validationMessage_validationState_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void customerRegUsername() {
		
		System.out.println("execute customerRegUsername");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: customerRegUsername in service: SignupService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(signupservice_service.customerRegUsername(
			customerRegUsername_username_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void customerRegPassword() {
		
		System.out.println("execute customerRegPassword");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: customerRegPassword in service: SignupService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(signupservice_service.customerRegPassword(
			customerRegPassword_password_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void customerDetails() {
		
		System.out.println("execute customerDetails");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: customerDetails in service: SignupService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(signupservice_service.customerDetails(
			customerDetails_email_t.getText(),
			customerDetails_phonenumber_t.getText(),
			customerDetails_address_t.getText(),
			customerDetails_fullName_t.getText(),
			customerDetails_userID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void saveDetails() {
		
		System.out.println("execute saveDetails");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: saveDetails in service: SignupService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(signupservice_service.saveDetails(
			saveDetails_usename_t.getText(),
			saveDetails_password_t.getText(),
			saveDetails_email_t.getText(),
			saveDetails_phonenumber_t.getText(),
			saveDetails_address_t.getText(),
			saveDetails_customerID_t.getText(),
			saveDetails_fullName_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void searchProducts() {
		
		System.out.println("execute searchProducts");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: searchProducts in service: BrowseProductsService ");
		
		try {
			//invoke op with parameters
					List<Product> result = browseproductsservice_service.searchProducts(
					searchProducts_productName_t.getText()
					);
				
					//binding result to GUI
					TableView<Map<String, String>> tableProduct = new TableView<Map<String, String>>();
					TableColumn<Map<String, String>, String> tableProduct_ProductID = new TableColumn<Map<String, String>, String>("ProductID");
					tableProduct_ProductID.setMinWidth("ProductID".length()*10);
					tableProduct_ProductID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ProductID"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_ProductID);
					TableColumn<Map<String, String>, String> tableProduct_ProductName = new TableColumn<Map<String, String>, String>("ProductName");
					tableProduct_ProductName.setMinWidth("ProductName".length()*10);
					tableProduct_ProductName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ProductName"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_ProductName);
					TableColumn<Map<String, String>, String> tableProduct_Price = new TableColumn<Map<String, String>, String>("Price");
					tableProduct_Price.setMinWidth("Price".length()*10);
					tableProduct_Price.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("Price"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_Price);
					TableColumn<Map<String, String>, String> tableProduct_StockLevel = new TableColumn<Map<String, String>, String>("StockLevel");
					tableProduct_StockLevel.setMinWidth("StockLevel".length()*10);
					tableProduct_StockLevel.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("StockLevel"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_StockLevel);
					
					ObservableList<Map<String, String>> dataProduct = FXCollections.observableArrayList();
					for (Product r : result) {
						Map<String, String> unit = new HashMap<String, String>();
						if (r.getProductID() != null)
							unit.put("ProductID", String.valueOf(r.getProductID()));
						else
							unit.put("ProductID", "");
						if (r.getProductName() != null)
							unit.put("ProductName", String.valueOf(r.getProductName()));
						else
							unit.put("ProductName", "");
						unit.put("Price", String.valueOf(r.getPrice()));
						unit.put("StockLevel", String.valueOf(r.getStockLevel()));
						dataProduct.add(unit);
					}
					
					tableProduct.setItems(dataProduct);
					operation_return_pane.setContent(tableProduct);
				
			
			//return type is entity
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void viewAllProducts() {
		
		System.out.println("execute viewAllProducts");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: viewAllProducts in service: BrowseProductsService ");
		
		try {
			//invoke op with parameters
					List<Product> result = browseproductsservice_service.viewAllProducts(
					);
				
					//binding result to GUI
					TableView<Map<String, String>> tableProduct = new TableView<Map<String, String>>();
					TableColumn<Map<String, String>, String> tableProduct_ProductID = new TableColumn<Map<String, String>, String>("ProductID");
					tableProduct_ProductID.setMinWidth("ProductID".length()*10);
					tableProduct_ProductID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ProductID"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_ProductID);
					TableColumn<Map<String, String>, String> tableProduct_ProductName = new TableColumn<Map<String, String>, String>("ProductName");
					tableProduct_ProductName.setMinWidth("ProductName".length()*10);
					tableProduct_ProductName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ProductName"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_ProductName);
					TableColumn<Map<String, String>, String> tableProduct_Price = new TableColumn<Map<String, String>, String>("Price");
					tableProduct_Price.setMinWidth("Price".length()*10);
					tableProduct_Price.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("Price"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_Price);
					TableColumn<Map<String, String>, String> tableProduct_StockLevel = new TableColumn<Map<String, String>, String>("StockLevel");
					tableProduct_StockLevel.setMinWidth("StockLevel".length()*10);
					tableProduct_StockLevel.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("StockLevel"));
					    }
					});	
					tableProduct.getColumns().add(tableProduct_StockLevel);
					
					ObservableList<Map<String, String>> dataProduct = FXCollections.observableArrayList();
					for (Product r : result) {
						Map<String, String> unit = new HashMap<String, String>();
						if (r.getProductID() != null)
							unit.put("ProductID", String.valueOf(r.getProductID()));
						else
							unit.put("ProductID", "");
						if (r.getProductName() != null)
							unit.put("ProductName", String.valueOf(r.getProductName()));
						else
							unit.put("ProductName", "");
						unit.put("Price", String.valueOf(r.getPrice()));
						unit.put("StockLevel", String.valueOf(r.getStockLevel()));
						dataProduct.add(unit);
					}
					
					tableProduct.setItems(dataProduct);
					operation_return_pane.setContent(tableProduct);
				
			
			//return type is entity
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void cartSummary() {
		
		System.out.println("execute cartSummary");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: cartSummary in service: CheckOutService ");
		
		try {
			//invoke op with parameters
					List<Cart> result = new LinkedList<>();
					Cart c = checkoutservice_service.cartSummary(
					cartSummary_listOfProductID_t.getText(),
					cartSummary_quantity_t.getText(),
					cartSummary_orderID_t.getText()
					);
					result.add(c);
				
					//binding result to GUI
					TableView<Map<String, String>> tableCart = new TableView<Map<String, String>>();
					TableColumn<Map<String, String>, String> tableCart_CartID = new TableColumn<Map<String, String>, String>("CartID");
					tableCart_CartID.setMinWidth("CartID".length()*10);
					tableCart_CartID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("CartID"));
					    }
					});	
					tableCart.getColumns().add(tableCart_CartID);
					TableColumn<Map<String, String>, String> tableCart_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
					tableCart_ProductList.setMinWidth("ProductList".length()*10);
					tableCart_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
					    }
					});	
					tableCart.getColumns().add(tableCart_ProductList);
					TableColumn<Map<String, String>, String> tableCart_TotalAmount = new TableColumn<Map<String, String>, String>("TotalAmount");
					tableCart_TotalAmount.setMinWidth("TotalAmount".length()*10);
					tableCart_TotalAmount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("TotalAmount"));
					    }
					});	
					tableCart.getColumns().add(tableCart_TotalAmount);
					TableColumn<Map<String, String>, String> tableCart_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
					tableCart_CustomerID.setMinWidth("CustomerID".length()*10);
					tableCart_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
					    }
					});	
					tableCart.getColumns().add(tableCart_CustomerID);
					TableColumn<Map<String, String>, String> tableCart_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
					tableCart_OrderID.setMinWidth("OrderID".length()*10);
					tableCart_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
					    }
					});	
					tableCart.getColumns().add(tableCart_OrderID);
					
					ObservableList<Map<String, String>> dataCart = FXCollections.observableArrayList();
					for (Cart r : result) {
						Map<String, String> unit = new HashMap<String, String>();
						if (r.getCartID() != null)
							unit.put("CartID", String.valueOf(r.getCartID()));
						else
							unit.put("CartID", "");
						unit.put("ProductList", String.valueOf(r.getProductList()));
						unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
						if (r.getCustomerID() != null)
							unit.put("CustomerID", String.valueOf(r.getCustomerID()));
						else
							unit.put("CustomerID", "");
						if (r.getOrderID() != null)
							unit.put("OrderID", String.valueOf(r.getOrderID()));
						else
							unit.put("OrderID", "");
						dataCart.add(unit);
					}
					
					tableCart.setItems(dataCart);
					operation_return_pane.setContent(tableCart);
				
			
			//return type is entity
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void makePayment() {
		
		System.out.println("execute makePayment");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: makePayment in service: CheckOutService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(checkoutservice_service.makePayment(
			makePayment_paymentMethod_t.getText(),
			makePayment_orderID_t.getText(),
			makePayment_transactionID_t.getText(),
			Float.valueOf(makePayment_totalAmount_t.getText()),
			makePayment_customerID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getGuestUserDetails() {
		
		System.out.println("execute getGuestUserDetails");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getGuestUserDetails in service: CheckOutService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(checkoutservice_service.getGuestUserDetails(
			getGuestUserDetails_fullName_t.getText(),
			getGuestUserDetails_address_t.getText(),
			Integer.valueOf(getGuestUserDetails_phoneNumber_t.getText()),
			getGuestUserDetails_email_t.getText(),
			getGuestUserDetails_customerID_t.getText(),
			getGuestUserDetails_orderID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getTransactionID() {
		
		System.out.println("execute getTransactionID");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getTransactionID in service: ReturnProductService ");
		
		try {
			//invoke op with parameters
					List<Transaction> result = returnproductservice_service.getTransactionID(
					getTransactionID_transactionID_t.getText()
					);
				
					//binding result to GUI
					TableView<Map<String, String>> tableTransaction = new TableView<Map<String, String>>();
					TableColumn<Map<String, String>, String> tableTransaction_TransactionID = new TableColumn<Map<String, String>, String>("TransactionID");
					tableTransaction_TransactionID.setMinWidth("TransactionID".length()*10);
					tableTransaction_TransactionID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("TransactionID"));
					    }
					});	
					tableTransaction.getColumns().add(tableTransaction_TransactionID);
					TableColumn<Map<String, String>, String> tableTransaction_Amount = new TableColumn<Map<String, String>, String>("Amount");
					tableTransaction_Amount.setMinWidth("Amount".length()*10);
					tableTransaction_Amount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("Amount"));
					    }
					});	
					tableTransaction.getColumns().add(tableTransaction_Amount);
					TableColumn<Map<String, String>, String> tableTransaction_PaymentMethod = new TableColumn<Map<String, String>, String>("PaymentMethod");
					tableTransaction_PaymentMethod.setMinWidth("PaymentMethod".length()*10);
					tableTransaction_PaymentMethod.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("PaymentMethod"));
					    }
					});	
					tableTransaction.getColumns().add(tableTransaction_PaymentMethod);
					TableColumn<Map<String, String>, String> tableTransaction_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
					tableTransaction_OrderID.setMinWidth("OrderID".length()*10);
					tableTransaction_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
					    }
					});	
					tableTransaction.getColumns().add(tableTransaction_OrderID);
					
					ObservableList<Map<String, String>> dataTransaction = FXCollections.observableArrayList();
					for (Transaction r : result) {
						Map<String, String> unit = new HashMap<String, String>();
						if (r.getTransactionID() != null)
							unit.put("TransactionID", String.valueOf(r.getTransactionID()));
						else
							unit.put("TransactionID", "");
						unit.put("Amount", String.valueOf(r.getAmount()));
						if (r.getPaymentMethod() != null)
							unit.put("PaymentMethod", String.valueOf(r.getPaymentMethod()));
						else
							unit.put("PaymentMethod", "");
						if (r.getOrderID() != null)
							unit.put("OrderID", String.valueOf(r.getOrderID()));
						else
							unit.put("OrderID", "");
						dataTransaction.add(unit);
					}
					
					tableTransaction.setItems(dataTransaction);
					operation_return_pane.setContent(tableTransaction);
				
			
			//return type is entity
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void productID() {
		
		System.out.println("execute productID");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: productID in service: ReturnProductService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(returnproductservice_service.productID(
			productID_productID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getReason() {
		
		System.out.println("execute getReason");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getReason in service: ReturnProductService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(returnproductservice_service.getReason(
			getReason_reasonOfReturn_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void saveReturn() {
		
		System.out.println("execute saveReturn");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: saveReturn in service: ReturnProductService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(returnproductservice_service.saveReturn(
			saveReturn_customerID_t.getText(),
			saveReturn_transactionID_t.getText(),
			saveReturn_reasonOfReturn_t.getText(),
			saveReturn_returnID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void reviewCart() {
		
		System.out.println("execute reviewCart");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: reviewCart in service: ReviewCartService ");
		
		try {
			//invoke op with parameters
				Cart r = reviewcartservice_service.reviewCart(
				reviewCart_sessionID_t.getText()
				);
			
				//binding result to GUI
				TableView<Map<String, String>> tableCart = new TableView<Map<String, String>>();
				TableColumn<Map<String, String>, String> tableCart_CartID = new TableColumn<Map<String, String>, String>("CartID");
				tableCart_CartID.setMinWidth("CartID".length()*10);
				tableCart_CartID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("CartID"));
				    }
				});	
				tableCart.getColumns().add(tableCart_CartID);
				TableColumn<Map<String, String>, String> tableCart_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
				tableCart_ProductList.setMinWidth("ProductList".length()*10);
				tableCart_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
				    }
				});	
				tableCart.getColumns().add(tableCart_ProductList);
				TableColumn<Map<String, String>, String> tableCart_TotalAmount = new TableColumn<Map<String, String>, String>("TotalAmount");
				tableCart_TotalAmount.setMinWidth("TotalAmount".length()*10);
				tableCart_TotalAmount.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("TotalAmount"));
				    }
				});	
				tableCart.getColumns().add(tableCart_TotalAmount);
				TableColumn<Map<String, String>, String> tableCart_CustomerID = new TableColumn<Map<String, String>, String>("CustomerID");
				tableCart_CustomerID.setMinWidth("CustomerID".length()*10);
				tableCart_CustomerID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("CustomerID"));
				    }
				});	
				tableCart.getColumns().add(tableCart_CustomerID);
				TableColumn<Map<String, String>, String> tableCart_OrderID = new TableColumn<Map<String, String>, String>("OrderID");
				tableCart_OrderID.setMinWidth("OrderID".length()*10);
				tableCart_OrderID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("OrderID"));
				    }
				});	
				tableCart.getColumns().add(tableCart_OrderID);
				
				ObservableList<Map<String, String>> dataCart = FXCollections.observableArrayList();
				
					Map<String, String> unit = new HashMap<String, String>();
					if (r.getCartID() != null)
						unit.put("CartID", String.valueOf(r.getCartID()));
					else
						unit.put("CartID", "");
					unit.put("ProductList", String.valueOf(r.getProductList()));
					unit.put("TotalAmount", String.valueOf(r.getTotalAmount()));
					if (r.getCustomerID() != null)
						unit.put("CustomerID", String.valueOf(r.getCustomerID()));
					else
						unit.put("CustomerID", "");
					if (r.getOrderID() != null)
						unit.put("OrderID", String.valueOf(r.getOrderID()));
					else
						unit.put("OrderID", "");
					dataCart.add(unit);
				
				
				tableCart.setItems(dataCart);
				operation_return_pane.setContent(tableCart);					
					
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void modifyCart() {
		
		System.out.println("execute modifyCart");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: modifyCart in service: ModifyCartService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(modifycartservice_service.modifyCart(
			modifyCart_sessionID_t.getText(),
			modifyCart_productID_t.getText(),
			modifyCart_quantity_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void giveFeedback() {
		
		System.out.println("execute giveFeedback");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: giveFeedback in service: GiveFeedbackService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(givefeedbackservice_service.giveFeedback(
			giveFeedback_textFeedback_t.getText(),
			giveFeedback_customerID_t.getText(),
			giveFeedback_feedbackID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void saveFeedback() {
		
		System.out.println("execute saveFeedback");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: saveFeedback in service: GiveFeedbackService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(givefeedbackservice_service.saveFeedback(
			saveFeedback_customerID_t.getText(),
			saveFeedback_textFeedback_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getMembershipStatus() {
		
		System.out.println("execute getMembershipStatus");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getMembershipStatus in service: MembershipStatusService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(membershipstatusservice_service.getMembershipStatus(
			getMembershipStatus_memberID_t.getText(),
			getMembershipStatus_email_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void showCurrentStatus() {
		
		System.out.println("execute showCurrentStatus");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: showCurrentStatus in service: MembershipStatusService ");
		
		try {
			//invoke op with parameters
				Member r = membershipstatusservice_service.showCurrentStatus(
				);
			
				//binding result to GUI
				TableView<Map<String, String>> tableMember = new TableView<Map<String, String>>();
				TableColumn<Map<String, String>, String> tableMember_MemberID = new TableColumn<Map<String, String>, String>("MemberID");
				tableMember_MemberID.setMinWidth("MemberID".length()*10);
				tableMember_MemberID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("MemberID"));
				    }
				});	
				tableMember.getColumns().add(tableMember_MemberID);
				TableColumn<Map<String, String>, String> tableMember_FullName = new TableColumn<Map<String, String>, String>("FullName");
				tableMember_FullName.setMinWidth("FullName".length()*10);
				tableMember_FullName.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("FullName"));
				    }
				});	
				tableMember.getColumns().add(tableMember_FullName);
				TableColumn<Map<String, String>, String> tableMember_Tier = new TableColumn<Map<String, String>, String>("Tier");
				tableMember_Tier.setMinWidth("Tier".length()*10);
				tableMember_Tier.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("Tier"));
				    }
				});	
				tableMember.getColumns().add(tableMember_Tier);
				TableColumn<Map<String, String>, String> tableMember_LoyaltyPoints = new TableColumn<Map<String, String>, String>("LoyaltyPoints");
				tableMember_LoyaltyPoints.setMinWidth("LoyaltyPoints".length()*10);
				tableMember_LoyaltyPoints.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("LoyaltyPoints"));
				    }
				});	
				tableMember.getColumns().add(tableMember_LoyaltyPoints);
				
				ObservableList<Map<String, String>> dataMember = FXCollections.observableArrayList();
				
					Map<String, String> unit = new HashMap<String, String>();
					if (r.getMemberID() != null)
						unit.put("MemberID", String.valueOf(r.getMemberID()));
					else
						unit.put("MemberID", "");
					if (r.getFullName() != null)
						unit.put("FullName", String.valueOf(r.getFullName()));
					else
						unit.put("FullName", "");
					if (r.getTier() != null)
						unit.put("Tier", String.valueOf(r.getTier()));
					else
						unit.put("Tier", "");
					unit.put("LoyaltyPoints", String.valueOf(r.getLoyaltyPoints()));
					dataMember.add(unit);
				
				
				tableMember.setItems(dataMember);
				operation_return_pane.setContent(tableMember);					
					
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void scanProducts() {
		
		System.out.println("execute scanProducts");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: scanProducts in service: ScanProductsService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(scanproductsservice_service.scanProducts(
			scanProducts_barcode_t.getText(),
			scanProducts_quantity_t.getText(),
			scanProducts_CartID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void updateCart() {
		
		System.out.println("execute updateCart");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: updateCart in service: ScanProductsService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(scanproductsservice_service.updateCart(
			updateCart_productID_t.getText(),
			updateCart_productName_t.getText(),
			Integer.valueOf(updateCart_quantity_t.getText()),
			Float.valueOf(updateCart_price_t.getText())
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void paymentProcess() {
		
		System.out.println("execute paymentProcess");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: paymentProcess in service: ProcessPaymentService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(processpaymentservice_service.paymentProcess(
			paymentProcess_paymentMethod_t.getText(),
			paymentProcess_totalAmount_t.getText(),
			paymentProcess_customerID_t.getText(),
			paymentProcess_orderID_t.getText(),
			paymentProcess_transactionID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void addLoyaltyPoints() {
		
		System.out.println("execute addLoyaltyPoints");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: addLoyaltyPoints in service: ProcessPaymentService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(processpaymentservice_service.addLoyaltyPoints(
			Integer.valueOf(addLoyaltyPoints_points_t.getText()),
			addLoyaltyPoints_memberID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getCustomerID() {
		
		System.out.println("execute getCustomerID");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getCustomerID in service: ProcessReturnService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(processreturnservice_service.getCustomerID(
			getCustomerID_customerID_t.getText(),
			getCustomerID_transactionID_t.getText(),
			getCustomerID_reasonOfReturn_t.getText(),
			getCustomerID_productID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getUserDetails() {
		
		System.out.println("execute getUserDetails");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getUserDetails in service: PrintReceiptService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(printreceiptservice_service.getUserDetails(
			getUserDetails_customerID_t.getText(),
			getUserDetails_transactionID_t.getText(),
			getUserDetails_orderID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void printReciept() {
		
		System.out.println("execute printReciept");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: printReciept in service: PrintReceiptService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(printreceiptservice_service.printReciept(
			printReciept_transactionID_t.getText(),
			printReciept_customerID_t.getText(),
			printReciept_orderID_t.getText(),
			printReciept_cartID_t.getText(),
			printReciept_receiptID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void processingUserPayment() {
		
		System.out.println("execute processingUserPayment");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: processingUserPayment in service: PaymentValidationService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(paymentvalidationservice_service.processingUserPayment(
			processingUserPayment_creditcardNumber_t.getText(),
			LocalDate.parse(processingUserPayment_expiryDate_t.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))						,
			processingUserPayment_cvvCode_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void bankContactandAuthorization() {
		
		System.out.println("execute bankContactandAuthorization");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: bankContactandAuthorization in service: PaymentValidationService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = Boolean.toString(paymentvalidationservice_service.bankContactandAuthorization(
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void processingInStoreUserPayment() {
		
		System.out.println("execute processingInStoreUserPayment");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: processingInStoreUserPayment in service: InStorePaymentValidationService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(instorepaymentvalidationservice_service.processingInStoreUserPayment(
			processingInStoreUserPayment_cerditCardNumber_t.getText(),
			LocalDate.parse(processingInStoreUserPayment_expiryDate_t.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd")),						
			processingInStoreUserPayment_cvvCode_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void bankContactandAuthorizationInStore() {
		
		System.out.println("execute bankContactandAuthorizationInStore");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: bankContactandAuthorizationInStore in service: InStorePaymentValidationService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = Boolean.toString(instorepaymentvalidationservice_service.bankContactandAuthorizationInStore(
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void cashPayment() {
		
		System.out.println("execute cashPayment");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: cashPayment in service: InStorePaymentValidationService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(instorepaymentvalidationservice_service.cashPayment(
			cashPayment_amount_t.getText(),
			cashPayment_cartID_t.getText(),
			Float.valueOf(cashPayment_cashByUser_t.getText())
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void generateReport() {
		
		System.out.println("execute generateReport");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: generateReport in service: ViewReportsService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(viewreportsservice_service.generateReport(
			generateReport_type_t.getText(),
			LocalDate.parse(generateReport_startDate_t.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))						,
			LocalDate.parse(generateReport_endDate_t.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd"))						,
			generateReport_reportID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void getReportType() {
		
		System.out.println("execute getReportType");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: getReportType in service: ViewReportsService ");
		
		try {
			//invoke op with parameters
				Report r = viewreportsservice_service.getReportType(
				getReportType_reportID_t.getText()
				);
			
				//binding result to GUI
				TableView<Map<String, String>> tableReport = new TableView<Map<String, String>>();
				TableColumn<Map<String, String>, String> tableReport_ReportID = new TableColumn<Map<String, String>, String>("ReportID");
				tableReport_ReportID.setMinWidth("ReportID".length()*10);
				tableReport_ReportID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("ReportID"));
				    }
				});	
				tableReport.getColumns().add(tableReport_ReportID);
				TableColumn<Map<String, String>, String> tableReport_DateGenerated = new TableColumn<Map<String, String>, String>("DateGenerated");
				tableReport_DateGenerated.setMinWidth("DateGenerated".length()*10);
				tableReport_DateGenerated.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("DateGenerated"));
				    }
				});	
				tableReport.getColumns().add(tableReport_DateGenerated);
				TableColumn<Map<String, String>, String> tableReport_ReportResult = new TableColumn<Map<String, String>, String>("ReportResult");
				tableReport_ReportResult.setMinWidth("ReportResult".length()*10);
				tableReport_ReportResult.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("ReportResult"));
				    }
				});	
				tableReport.getColumns().add(tableReport_ReportResult);
				TableColumn<Map<String, String>, String> tableReport_TypeOfReport = new TableColumn<Map<String, String>, String>("TypeOfReport");
				tableReport_TypeOfReport.setMinWidth("TypeOfReport".length()*10);
				tableReport_TypeOfReport.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("TypeOfReport"));
				    }
				});	
				tableReport.getColumns().add(tableReport_TypeOfReport);
				
				ObservableList<Map<String, String>> dataReport = FXCollections.observableArrayList();
				
					Map<String, String> unit = new HashMap<String, String>();
					if (r.getReportID() != null)
						unit.put("ReportID", String.valueOf(r.getReportID()));
					else
						unit.put("ReportID", "");
					if (r.getDateGenerated() != null)
						unit.put("DateGenerated", r.getDateGenerated().format(dateformatter));
					else
						unit.put("DateGenerated", "");
					if (r.getReportResult() != null)
						unit.put("ReportResult", String.valueOf(r.getReportResult()));
					else
						unit.put("ReportResult", "");
					if (r.getTypeOfReport() != null)
						unit.put("TypeOfReport", String.valueOf(r.getTypeOfReport()));
					else
						unit.put("TypeOfReport", "");
					dataReport.add(unit);
				
				
				tableReport.setItems(dataReport);
				operation_return_pane.setContent(tableReport);					
					
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void viewAllReports() {
		
		System.out.println("execute viewAllReports");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: viewAllReports in service: ViewReportsService ");
		
		try {
			//invoke op with parameters
					List<Report> result = viewreportsservice_service.viewAllReports(
					);
				
					//binding result to GUI
					TableView<Map<String, String>> tableReport = new TableView<Map<String, String>>();
					TableColumn<Map<String, String>, String> tableReport_ReportID = new TableColumn<Map<String, String>, String>("ReportID");
					tableReport_ReportID.setMinWidth("ReportID".length()*10);
					tableReport_ReportID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ReportID"));
					    }
					});	
					tableReport.getColumns().add(tableReport_ReportID);
					TableColumn<Map<String, String>, String> tableReport_DateGenerated = new TableColumn<Map<String, String>, String>("DateGenerated");
					tableReport_DateGenerated.setMinWidth("DateGenerated".length()*10);
					tableReport_DateGenerated.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("DateGenerated"));
					    }
					});	
					tableReport.getColumns().add(tableReport_DateGenerated);
					TableColumn<Map<String, String>, String> tableReport_ReportResult = new TableColumn<Map<String, String>, String>("ReportResult");
					tableReport_ReportResult.setMinWidth("ReportResult".length()*10);
					tableReport_ReportResult.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("ReportResult"));
					    }
					});	
					tableReport.getColumns().add(tableReport_ReportResult);
					TableColumn<Map<String, String>, String> tableReport_TypeOfReport = new TableColumn<Map<String, String>, String>("TypeOfReport");
					tableReport_TypeOfReport.setMinWidth("TypeOfReport".length()*10);
					tableReport_TypeOfReport.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
						@Override
					    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
					        return new ReadOnlyStringWrapper(data.getValue().get("TypeOfReport"));
					    }
					});	
					tableReport.getColumns().add(tableReport_TypeOfReport);
					
					ObservableList<Map<String, String>> dataReport = FXCollections.observableArrayList();
					for (Report r : result) {
						Map<String, String> unit = new HashMap<String, String>();
						if (r.getReportID() != null)
							unit.put("ReportID", String.valueOf(r.getReportID()));
						else
							unit.put("ReportID", "");
						if (r.getDateGenerated() != null)
							unit.put("DateGenerated", r.getDateGenerated().format(dateformatter));
						else
							unit.put("DateGenerated", "");
						if (r.getReportResult() != null)
							unit.put("ReportResult", String.valueOf(r.getReportResult()));
						else
							unit.put("ReportResult", "");
						if (r.getTypeOfReport() != null)
							unit.put("TypeOfReport", String.valueOf(r.getTypeOfReport()));
						else
							unit.put("TypeOfReport", "");
						dataReport.add(unit);
					}
					
					tableReport.setItems(dataReport);
					operation_return_pane.setContent(tableReport);
				
			
			//return type is entity
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void sendToSupplier() {
		
		System.out.println("execute sendToSupplier");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: sendToSupplier in service: ManageInventoryService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(manageinventoryservice_service.sendToSupplier(
			sendToSupplier_supplierID_t.getText(),
			sendToSupplier_productID_t.getText(),
			sendToSupplier_supplierOrderID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void recordRestock() {
		
		System.out.println("execute recordRestock");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: recordRestock in service: ManageInventoryService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(manageinventoryservice_service.recordRestock(
			recordRestock_productName_t.getText(),
			recordRestock_productID_t.getText(),
			Integer.valueOf(recordRestock_quantity_t.getText())
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void viewInventoryStockLevel() {
		
		System.out.println("execute viewInventoryStockLevel");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: viewInventoryStockLevel in service: ManageInventoryService ");
		
		try {
			//invoke op with parameters
				List<Inventory> r = manageinventoryservice_service.viewInventoryStockLevel(
				);
			
				//binding result to GUI
				TableView<Map<String, String>> tableInventory = new TableView<Map<String, String>>();
				TableColumn<Map<String, String>, String> tableInventory_InventoryID = new TableColumn<Map<String, String>, String>("InventoryID");
				tableInventory_InventoryID.setMinWidth("InventoryID".length()*10);
				tableInventory_InventoryID.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("InventoryID"));
				    }
				});	
				tableInventory.getColumns().add(tableInventory_InventoryID);
				TableColumn<Map<String, String>, String> tableInventory_ProductList = new TableColumn<Map<String, String>, String>("ProductList");
				tableInventory_ProductList.setMinWidth("ProductList".length()*10);
				tableInventory_ProductList.setCellValueFactory(new Callback<CellDataFeatures<Map<String, String>, String>, ObservableValue<String>>() {	   
					@Override
				    public ObservableValue<String> call(CellDataFeatures<Map<String, String>, String> data) {
				        return new ReadOnlyStringWrapper(data.getValue().get("ProductList"));
				    }
				});	
				tableInventory.getColumns().add(tableInventory_ProductList);
				
				ObservableList<Map<String, String>> dataInventory = FXCollections.observableArrayList();
				
					Map<String, String> unit = new HashMap<String, String>();
					for (Inventory element:r) {
						if (element.getInventoryID() != null)
							unit.put("InventoryID", String.valueOf(element.getInventoryID()));
						else
							unit.put("InventoryID", "");
						unit.put("ProductList", String.valueOf(element.getProductList()));
						dataInventory.add(unit);
					}
				
				
				tableInventory.setItems(dataInventory);
				operation_return_pane.setContent(tableInventory);					
					
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void orderStockProducts() {
		
		System.out.println("execute orderStockProducts");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: orderStockProducts in service: ManageInventoryService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(manageinventoryservice_service.orderStockProducts(
			orderStockProducts_productID_t.getText(),
			Integer.valueOf(orderStockProducts_quantity_t.getText()),
			orderStockProducts_restockProductsID_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void newOrder() {
		
		System.out.println("execute newOrder");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: newOrder in service: CheckOutService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(checkoutservice_service.newOrder(
			newOrder_orderID_t.getText(),
			LocalDate.parse(newOrder_dateOfPurchase_t.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd")),
			Float.valueOf(newOrder_totalPrice_t.getText())
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}
	public void creatingNewSupplier() {
		
		System.out.println("execute creatingNewSupplier");
		String time = String.format("%1$tH:%1$tM:%1$tS", System.currentTimeMillis());
		log.appendText(time + " -- execute operation: creatingNewSupplier in service: ManageInventoryService ");
		
		try {
			//invoke op with parameters
			//return value is primitive type, bind result to label.
			String result = String.valueOf(manageinventoryservice_service.creatingNewSupplier(
			creatingNewSupplier_supplierID_t.getText(),
			creatingNewSupplier_companyName_t.getText(),
			creatingNewSupplier_contactDetails_t.getText()
			));	
			Label l = new Label(result);
			l.setPadding(new Insets(8, 8, 8, 8));
			operation_return_pane.setContent(l);
		    log.appendText(" -- success!\n");
		    //set pre- and post-conditions text area color
		    precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #7CFC00");
		    //contract evaluation result
		    precondition_pane.setText("Precondition: True");
		    postcondition_pane.setText("Postcondition: True");
		    
		    
		} catch (PreconditionException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (PostconditionException e) {
			log.appendText(" -- failed!\n");
			postcondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");	
			postcondition_pane.setText("Postcondition: False");
			postconditionUnSat();
			
		} catch (NumberFormatException e) {
			log.appendText(" -- failed!\n");
			precondition.setStyle("-fx-background-color:#000000; -fx-control-inner-background: #FF0000");
			precondition_pane.setText("Precondition: False");	
			preconditionUnSat();
			
		} catch (Exception e ) {		
			if (e instanceof ThirdPartyServiceException)
				thirdpartyServiceUnSat();
		}
	}




	//select object index
	int objectindex;
	
	@FXML
	TabPane mainPane;

	@FXML
	TextArea log;
	
	@FXML
	TreeView<String> actor_treeview_customerorloyaltymember;
	@FXML
	TreeView<String> actor_treeview_cashier;
	@FXML
	TreeView<String> actor_treeview_storemanager;
	@FXML
	TreeView<String> actor_treeview_supplier;
	@FXML
	TreeView<String> actor_treeview_user;
	
	@FXML
	TreeView<String> actor_treeview_administrator;


	@FXML
	TextArea definition;
	@FXML
	TextArea precondition;
	@FXML
	TextArea postcondition;
	@FXML
	TextArea invariants;
	
	@FXML
	TitledPane precondition_pane;
	@FXML
	TitledPane postcondition_pane;
	
	//chosen operation textfields
	List<TextField> choosenOperation;
	String clickedOp;
		
	@FXML
	TableView<ClassInfo> class_statisic;
	@FXML
	TableView<AssociationInfo> association_statisic;
	
	Map<String, ObservableList<AssociationInfo>> allassociationData;
	ObservableList<ClassInfo> classInfodata;
	
	Electronics electronics_service;
	ThirdPartyServices thirdpartyservices_service;
	SignupService signupservice_service;
	SystemLoginService systemloginservice_service;
	CredentialsCheckService credentialscheckservice_service;
	BrowseProductsService browseproductsservice_service;
	CheckOutService checkoutservice_service;
	ReturnProductService returnproductservice_service;
	ReviewCartService reviewcartservice_service;
	ModifyCartService modifycartservice_service;
	GiveFeedbackService givefeedbackservice_service;
	MembershipStatusService membershipstatusservice_service;
	ScanProductsService scanproductsservice_service;
	ProcessPaymentService processpaymentservice_service;
	ProcessReturnService processreturnservice_service;
	PrintReceiptService printreceiptservice_service;
	PaymentValidationService paymentvalidationservice_service;
	InStorePaymentValidationService instorepaymentvalidationservice_service;
	ViewReportsService viewreportsservice_service;
	ManageInventoryService manageinventoryservice_service;
	AccessFeedbackService accessfeedbackservice_service;
	ProcessOrdersService processordersservice_service;
	ProcessCheckoutService processcheckoutservice_service;
	ViewNewOrdersService viewnewordersservice_service;
	ElectronicsStore111System electronicsstore111system_service;
	
	ClassInfo customer;
	ClassInfo member;
	ClassInfo cashier;
	ClassInfo storemanager;
	ClassInfo product;
	ClassInfo supplier;
	ClassInfo inventory;
	ClassInfo order;
	ClassInfo transaction;
	ClassInfo feedback;
	ClassInfo receipt;
	ClassInfo supplierorder;
	ClassInfo users;
	ClassInfo cart;
	ClassInfo returnedproducts;
	ClassInfo report;
	ClassInfo restockproducts;
		
	@FXML
	TitledPane object_statics;
	Map<String, TableView> allObjectTables;
	
	@FXML
	TitledPane operation_paras;
	
	@FXML
	TitledPane operation_return_pane;
	
	@FXML 
	TitledPane all_invariant_pane;
	
	@FXML
	TitledPane invariants_panes;
	
	Map<String, GridPane> operationPanels;
	Map<String, VBox> opInvariantPanel;
	
	//all textfiled or eumntity
	TextField usernameInput_username_t;
	TextField passwordInput_password_t;
	TextField validationCheck_username_t;
	TextField validationCheck_password_t;
	TextField validationMessage_validationState_t;
	TextField customerRegUsername_username_t;
	TextField customerRegPassword_password_t;
	TextField customerDetails_email_t;
	TextField customerDetails_phonenumber_t;
	TextField customerDetails_address_t;
	TextField customerDetails_fullName_t;
	TextField customerDetails_userID_t;
	TextField saveDetails_usename_t;
	TextField saveDetails_password_t;
	TextField saveDetails_email_t;
	TextField saveDetails_phonenumber_t;
	TextField saveDetails_address_t;
	TextField saveDetails_customerID_t;
	TextField saveDetails_fullName_t;
	TextField searchProducts_productName_t;
	TextField cartSummary_listOfProductID_t;
	TextField cartSummary_quantity_t;
	TextField cartSummary_orderID_t;
	TextField makePayment_paymentMethod_t;
	TextField makePayment_orderID_t;
	TextField makePayment_transactionID_t;
	TextField makePayment_totalAmount_t;
	TextField makePayment_customerID_t;
	TextField getGuestUserDetails_fullName_t;
	TextField getGuestUserDetails_address_t;
	TextField getGuestUserDetails_phoneNumber_t;
	TextField getGuestUserDetails_email_t;
	TextField getGuestUserDetails_customerID_t;
	TextField getGuestUserDetails_orderID_t;
	TextField getTransactionID_transactionID_t;
	TextField productID_productID_t;
	TextField getReason_reasonOfReturn_t;
	TextField saveReturn_customerID_t;
	TextField saveReturn_transactionID_t;
	TextField saveReturn_reasonOfReturn_t;
	TextField saveReturn_returnID_t;
	TextField reviewCart_sessionID_t;
	TextField modifyCart_sessionID_t;
	TextField modifyCart_productID_t;
	TextField modifyCart_quantity_t;
	TextField giveFeedback_textFeedback_t;
	TextField giveFeedback_customerID_t;
	TextField giveFeedback_feedbackID_t;
	TextField saveFeedback_customerID_t;
	TextField saveFeedback_textFeedback_t;
	TextField getMembershipStatus_memberID_t;
	TextField getMembershipStatus_email_t;
	TextField scanProducts_barcode_t;
	TextField scanProducts_CartID_t;
	TextField scanProducts_quantity_t;
	TextField updateCart_productID_t;
	TextField updateCart_productName_t;
	TextField updateCart_quantity_t;
	TextField updateCart_price_t;
	TextField paymentProcess_paymentMethod_t;
	TextField paymentProcess_totalAmount_t;
	TextField paymentProcess_customerID_t;
	TextField paymentProcess_orderID_t;
	TextField paymentProcess_transactionID_t;
	TextField addLoyaltyPoints_points_t;
	TextField addLoyaltyPoints_memberID_t;
	TextField getCustomerID_customerID_t;
	TextField getCustomerID_transactionID_t;
	TextField getCustomerID_reasonOfReturn_t;
	TextField getCustomerID_productID_t;
	TextField getUserDetails_customerID_t;
	TextField getUserDetails_transactionID_t;
	TextField getUserDetails_orderID_t;
	TextField printReciept_transactionID_t;
	TextField printReciept_customerID_t;
	TextField printReciept_orderID_t;
	TextField printReciept_cartID_t;
	TextField printReciept_receiptID_t;
	TextField processingUserPayment_creditcardNumber_t;
	TextField processingUserPayment_expiryDate_t;
	TextField processingUserPayment_cvvCode_t;
	TextField processingInStoreUserPayment_cerditCardNumber_t;
	TextField processingInStoreUserPayment_expiryDate_t;
	TextField processingInStoreUserPayment_cvvCode_t;
	TextField cashPayment_amount_t;
	TextField cashPayment_cartID_t;
	TextField cashPayment_cashByUser_t;
	TextField generateReport_type_t;
	TextField generateReport_startDate_t;
	TextField generateReport_endDate_t;
	TextField generateReport_reportID_t;
	TextField getReportType_reportID_t;
	TextField sendToSupplier_supplierID_t;
	TextField sendToSupplier_productID_t;
	TextField sendToSupplier_supplierOrderID_t;
	TextField recordRestock_productName_t;
	TextField recordRestock_productID_t;
	TextField recordRestock_quantity_t;
	TextField orderStockProducts_productID_t;
	TextField orderStockProducts_quantity_t;
	TextField orderStockProducts_restockProductsID_t;
	TextField newOrder_orderID_t;
	TextField newOrder_dateOfPurchase_t;
	TextField newOrder_totalPrice_t;
	TextField newOrder_produceList_t;
	TextField creatingNewSupplier_supplierID_t;
	TextField creatingNewSupplier_companyName_t;
	TextField creatingNewSupplier_contactDetails_t;
	
	HashMap<String, String> definitions_map;
	HashMap<String, String> preconditions_map;
	HashMap<String, String> postconditions_map;
	HashMap<String, String> invariants_map;
	LinkedHashMap<String, String> service_invariants_map;
	LinkedHashMap<String, String> entity_invariants_map;
	LinkedHashMap<String, Label> service_invariants_label_map;
	LinkedHashMap<String, Label> entity_invariants_label_map;
	LinkedHashMap<String, Label> op_entity_invariants_label_map;
	LinkedHashMap<String, Label> op_service_invariants_label_map;
	

	
}
