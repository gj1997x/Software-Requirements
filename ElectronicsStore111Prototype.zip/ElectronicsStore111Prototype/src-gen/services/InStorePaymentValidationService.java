package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface InStorePaymentValidationService {

	/* all system operations of the use case*/
	boolean processingInStoreUserPayment(String cerditCardNumber, LocalDate expiryDate, String cvvCode) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean bankContactandAuthorizationInStore() throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean cashPayment(String amount, String cartID, float cashByUser) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	int getCvvCodeSize();
	void setCvvCodeSize(int cvvcodesize);
	boolean getCvvValid();
	void setCvvValid(boolean cvvvalid);
	int getCreditCardsize();
	void setCreditCardsize(int creditcardsize);
	boolean getCreditCardValid();
	void setCreditCardValid(boolean creditcardvalid);
	boolean getCreditCardDateValid();
	void setCreditCardDateValid(boolean creditcarddatevalid);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
