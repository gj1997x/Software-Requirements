package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ScanProductsService {

	/* all system operations of the use case*/
	boolean scanProducts(String barcode, String quantity, String CartID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean updateCart(String productID, String productName, int quantity, float price, Cart c) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
