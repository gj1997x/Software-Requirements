package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ProcessPaymentService {

	/* all system operations of the use case*/
	boolean paymentProcess(String paymentMethod, String totalAmount, String customerID, String orderID, String transactionID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean addLoyaltyPoints(int points, String memberID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
