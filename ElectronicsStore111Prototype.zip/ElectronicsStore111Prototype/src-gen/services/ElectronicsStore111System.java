package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ElectronicsStore111System {

	/* all system operations of the use case*/
	
	/* all get and set functions for temp property*/
	
	
	/* invariant checking function */
}
