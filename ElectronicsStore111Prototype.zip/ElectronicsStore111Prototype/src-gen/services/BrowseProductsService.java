package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface BrowseProductsService {

	/* all system operations of the use case*/
	List<Product> viewAllProducts() throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	List<Product> searchProducts(String productName) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
