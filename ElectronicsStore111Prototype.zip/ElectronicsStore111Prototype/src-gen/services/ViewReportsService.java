package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ViewReportsService {

	/* all system operations of the use case*/
	List<Report> viewAllReports() throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	Report getReportType(String reportID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean generateReport(String type, LocalDate startDate, LocalDate endDate, String reportID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	List<String> getValidReportTypes();
	void setValidReportTypes(List<String> validreporttypes);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
