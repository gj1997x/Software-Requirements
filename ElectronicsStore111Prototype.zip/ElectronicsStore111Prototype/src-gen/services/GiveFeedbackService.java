package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface GiveFeedbackService {

	/* all system operations of the use case*/
	boolean giveFeedback(String textFeedback, String customerID, String feedbackID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean saveFeedback(String customerID, String textFeedback) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getFeedback();
	void setFeedback(String feedback);
	String getCustomerID();
	void setCustomerID(String customerid);
	String getFeedbackID();
	void setFeedbackID(String feedbackid);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
