package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface PaymentValidationService {

	/* all system operations of the use case*/
	boolean processingUserPayment(String creditcardNumber, LocalDate expiryDate, String cvvCode) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean bankContactandAuthorization() throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	int getCvvCodeSize();
	void setCvvCodeSize(int cvvcodesize);
	boolean getCvvValid();
	void setCvvValid(boolean cvvvalid);
	int getCreditCardsize();
	void setCreditCardsize(int creditcardsize);
	boolean getCreditCardValid();
	void setCreditCardValid(boolean creditcardvalid);
	boolean getCreditCardDateValid();
	void setCreditCardDateValid(boolean creditcarddatevalid);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
