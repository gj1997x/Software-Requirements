package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ProcessPaymentServiceImpl implements ProcessPaymentService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ProcessPaymentServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean paymentProcess(String paymentMethod, String totalAmount, String customerID, String orderID, String transactionID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (paymentMethod != "" && totalAmount != "" ) 
		{ 
			/* Logic here */
			Transaction t = null;
			t = (Transaction) EntityManager.createObject("Transaction");
			t.setTransactionID(transactionID);
			t.setPaymentMethod(paymentMethod);
			t.setOrderID(orderID);
			t.setAmount(Float.parseFloat(totalAmount));
			t.setCanProcess(c);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			t.getTransactionID() == transactionID
			 && 
			t.getPaymentMethod() == paymentMethod
			 && 
			t.getOrderID() == orderID
			 && 
			t.getAmount() == Float.parseFloat(totalAmount)
			 /*&& 
			StandardOPs.includes(List<transactionID>, c.getCanBeProcessedBy())*/
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [paymentMethod, totalAmount, customerID, orderID, transactionID] 
		//all relevant vars : t
		//all relevant entities : Transaction
	}  
	
	static {opINVRelatedEntity.put("paymentProcess", Arrays.asList("Transaction"));}
	 
	@SuppressWarnings("unchecked")
	public boolean addLoyaltyPoints(int points, String memberID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get m
		Member m = null;
		//no nested iterator --  iterator: any previous:any
		for (Member m1 : (List<Member>)EntityManager.getAllInstancesOf("Member"))
		{
			if (m1.getMemberID().equals(memberID))
			{
				m = m1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(m) == false) 
		{ 
			/* Logic here */
			m.setLoyaltyPoints(m.getLoyaltyPoints()+points);
			
			
			refresh();
			// post-condition checking
			if (!(m.getLoyaltyPoints() == m.getLoyaltyPoints()+points
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [memberID] 
		//all relevant vars : m
		//all relevant entities : Member
	}  
	
	static {opINVRelatedEntity.put("addLoyaltyPoints", Arrays.asList("Member"));}
	 
	
	
	
	/* temp property for controller */
			
	/* all get and set functions for temp property*/
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
