package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class InStorePaymentValidationServiceImpl implements InStorePaymentValidationService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public InStorePaymentValidationServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean processingInStoreUserPayment(String creditCardNumber, LocalDate expiryDate, String cvvCode) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (this.getCvvCodeSize() == StandardOPs.size(cvvCode) && this.getCreditCardsize() == StandardOPs.size(creditCardNumber) && this.getCvvCodeSize()==3  && this.getCreditCardsize()==16) 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean bankContactandAuthorizationInStore() throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (true) 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
		
		}
		else
		{
			throw new PreconditionException();
		}
		return true;
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean cashPayment(String amount, String cartID, float cashByUser) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get ca
		Cart ca = null;
		//no nested iterator --  iterator: any previous:any
		for (Cart ca1 : (List<Cart>)EntityManager.getAllInstancesOf("Cart"))
		{
			if (ca1.getCartID().equals(cartID))
			{
				ca = ca1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (amount != "" && cartID != "" && cashByUser != 0) 
		{ 
			/* Logic here */
			if (cashByUser >= ca.getTotalAmount())
			{
				
				refresh();
				// post-condition checking
				if (!((cashByUser >= ca.getTotalAmount() ? true : true))) {
					throw new PostconditionException();
				}
				
				//return code
				refresh();
				return true;
			}
			else
			{
			 	
			 	refresh();
			 	// post-condition checking
			 	if (!((cashByUser >= ca.getTotalAmount() ? true : true))) {
			 		throw new PostconditionException();
			 	}
			 	
			 	//return code
			 	refresh();
			 	return false;
			}
			
			
			
		
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [amount, cartID] 
	}  
	
	 
	
	
	
	/* temp property for controller */
	private int CvvCodeSize;
	private boolean CvvValid;
	private int CreditCardsize;
	private boolean CreditCardValid;
	private boolean CreditCardDateValid;
			
	/* all get and set functions for temp property*/
	public int getCvvCodeSize() {
		return CvvCodeSize;
	}	
	
	public void setCvvCodeSize(int cvvcodesize) {
		this.CvvCodeSize = cvvcodesize;
	}
	public boolean getCvvValid() {
		return CvvValid;
	}	
	
	public void setCvvValid(boolean cvvvalid) {
		this.CvvValid = cvvvalid;
	}
	public int getCreditCardsize() {
		return CreditCardsize;
	}	
	
	public void setCreditCardsize(int creditcardsize) {
		this.CreditCardsize = creditcardsize;
	}
	public boolean getCreditCardValid() {
		return CreditCardValid;
	}	
	
	public void setCreditCardValid(boolean creditcardvalid) {
		this.CreditCardValid = creditcardvalid;
	}
	public boolean getCreditCardDateValid() {
		return CreditCardDateValid;
	}	
	
	public void setCreditCardDateValid(boolean creditcarddatevalid) {
		this.CreditCardDateValid = creditcarddatevalid;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
