package services.impl;

import services.*;

import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class CheckOutServiceImpl implements CheckOutService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public CheckOutServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public Cart cartSummary(String listOfProductID, String quantity, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Cart c = null;
		//no nested iterator --  iterator: any previous:any
		for (Cart i : (List<Cart>)EntityManager.getAllInstancesOf("Cart"))
		{
			if (i.getOrderID().equals(orderID))
			{
				c = i;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(c) == false) 
		{ 
			/* Logic here */
			this.setDateOfPurchase(LocalDate.now());
			newOrder(orderID, this.getDateOfPurchase(), c.getTotalAmount(), c.getProductList());
			
			
			refresh();
			// post-condition checking
			if (!(this.getDateOfPurchase().isEqual(LocalDate.now())
			 && 
			true
			 && 
			true)) {
				throw new PostconditionException();
			}
			
			refresh(); return c;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [listOfProductID, quantity, orderID] 
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean makePayment(String paymentMethod, String orderID, String transactionID, float totalAmount, String customerID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer temp : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (temp.getCustomerID().equals(customerID))
			{
				c = temp;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (paymentMethod != "" && orderID != "" && transactionID != "") 
		{ 
			/* Logic here */
			Transaction t = null;
			t = (Transaction) EntityManager.createObject("Transaction");
			t.setTransactionID(transactionID);
			t.setPaymentMethod(paymentMethod);
			t.setOrderID(orderID);
			t.setAmount(totalAmount);
			c.setCanBeProcessedBy(t);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			t.getTransactionID() == transactionID
			 && 
			t.getPaymentMethod() == paymentMethod
			 && 
			t.getOrderID() == orderID
			 && 
			t.getAmount() == totalAmount
			// && 
			//StandardOPs.includes(c.getCanBeProcessedBy(), t)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [paymentMethod, orderID, transactionID, customerID] 
		//all relevant vars : t
		//all relevant entities : Transaction
	}  
	
	static {opINVRelatedEntity.put("makePayment", Arrays.asList("Transaction"));}
	 
	@SuppressWarnings("unchecked")
	public boolean getGuestUserDetails(String fullName, String address, int phoneNumber, String email, String customerID, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get u
		Users u = null;
		
		//(List<Users>)EntityManager.getAllInstancesOf("Users");
		/* previous state in post-condition*/
 
		/* check precondition */
		if (fullName != "" && address != "" && phoneNumber != 0 && email != "") 
		{ 
			/* Logic here */
			Customer c = null;
			c = (Customer) EntityManager.createObject("Customer");
			c.setFullName(fullName);
			c.setAddress(address);
			c.setPhoneNumber(phoneNumber);
			c.setEmail(email);
			c.setCustomerID(customerID);
			EntityManager.addObject("Customer", c);
			u.setRelatedTo(c);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			c.getFullName() == fullName
			 && 
			c.getAddress() == address
			 && 
			c.getPhoneNumber() == phoneNumber
			 && 
			c.getEmail() == email
			 && 
			c.getCustomerID() == customerID
			 && 
			StandardOPs.includes(((List<Customer>)EntityManager.getAllInstancesOf("Customer")), c)
			 //&& 
			//StandardOPs.includes(u.getRelatedTo(), c)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [fullName, address, phoneNumber, email, customerID, orderID] 
		//all relevant vars : c
		//all relevant entities : Customer
	}  
	
	static {opINVRelatedEntity.put("getGuestUserDetails", Arrays.asList("Customer"));}
	 
	@SuppressWarnings("unchecked")
	public boolean newOrder(String orderID, LocalDate dateOfPurchase, float totalPrice, List<Product> produceList) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (true) 
		{ 
			/* Logic here */
			Order o = null;
			o = (Order) EntityManager.createObject("Order");
			o.setOrderID(orderID);
			o.setDateOfPurchase(dateOfPurchase);
			o.setTotalPrice(totalPrice);
			o.setProductsList(produceList);
			EntityManager.addObject("Order", o);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			o.getOrderID() == orderID
			 && 
			o.getDateOfPurchase().equals(dateOfPurchase)
			 && 
			o.getTotalPrice() == totalPrice
			 && /*
			StandardOPs.includes(o.setProductsList(produceList), produceList)
			 && 
			StandardOPs.includes(((List<o>)EntityManager.getAllInstancesOf("o")), o)*/
			 //&& 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [orderID, dateOfPurchase] 
		//all relevant vars : produceList o
		//all relevant entities :  Order
	}  
	
	static {opINVRelatedEntity.put("newOrder", Arrays.asList("","Order"));}
	 
	
	
	
	/* temp property for controller */
	private String FullName;
	private String Address;
	private int PhoneNumber;
	private String Email;
	private String UserID;
	private LocalDate DateOfPurchase;
			
	/* all get and set functions for temp property*/
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public String getAddress() {
		return Address;
	}	
	
	public void setAddress(String address) {
		this.Address = address;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}	
	
	public void setPhoneNumber(int phonenumber) {
		this.PhoneNumber = phonenumber;
	}
	public String getEmail() {
		return Email;
	}	
	
	public void setEmail(String email) {
		this.Email = email;
	}
	public String getUserID() {
		return UserID;
	}	
	
	public void setUserID(String userid) {
		this.UserID = userid;
	}
	public LocalDate getDateOfPurchase() {
		return DateOfPurchase;
	}	
	
	public void setDateOfPurchase(LocalDate dateofpurchase) {
		this.DateOfPurchase = dateofpurchase;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
