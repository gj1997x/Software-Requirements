package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ProcessReturnServiceImpl implements ProcessReturnService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ProcessReturnServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean getCustomerID(String customerID, String transactionID, String reasonOfReturn, String productID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		Transaction t = null;
		//no nested iterator --  iterator: any previous:any
		for (Transaction t1 : (List<Transaction>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (t1.getTransactionID().equals(transactionID))
			{
				t = t1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (true) 
		{ 
			/* Logic here */
			ReturnedProducts r = null;
			r = (ReturnedProducts) EntityManager.createObject("ReturnedProducts");
			r.setCustomerID(customerID);
			r.setReturnID(productID);
			r.setTransactionID(transactionID);
			r.setReasonOfReturn(reasonOfReturn);
			EntityManager.addObject("ReturnedProducts", r);
			c.setReturnedBy(r);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			r.getCustomerID() == customerID
			 && 
			r.getReturnID() == productID
			 && 
			r.getTransactionID() == transactionID
			 && 
			r.getReasonOfReturn() == reasonOfReturn
			 && 
			StandardOPs.includes(((List<ReturnedProducts>)EntityManager.getAllInstancesOf("ReturnedProducts")), r)
			// && 
			//StandardOPs.includes(c.getReturnedBy(), t)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [customerID, transactionID, reasonOfReturn, productID] 
		//all relevant vars : r t
		//all relevant entities : ReturnedProducts 
	}  
	
	static {opINVRelatedEntity.put("getCustomerID", Arrays.asList("ReturnedProducts",""));}
	 
	
	
	
	/* temp property for controller */
	private String CustomerID;
	private String TransactionID;
	private String OrderID;
			
	/* all get and set functions for temp property*/
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String transactionid) {
		this.TransactionID = transactionid;
	}
	public String getOrderID() {
		return OrderID;
	}	
	
	public void setOrderID(String orderid) {
		this.OrderID = orderid;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
