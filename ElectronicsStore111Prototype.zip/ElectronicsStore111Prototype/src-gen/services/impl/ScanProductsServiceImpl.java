package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ScanProductsServiceImpl implements ScanProductsService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ScanProductsServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean scanProducts(String barcode, String quantity, String cartID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get p
		Product p = null;
		//no nested iterator --  iterator: any previous:any
		for (Product p1 : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p1.getProductID().equals(barcode))
			{
				p = p1;
				break;
			}
				
			
		}
		Cart ca = null;
		//no nested iterator --  iterator: any previous:any
		for (Cart cart : (List<Cart>)EntityManager.getAllInstancesOf("Cart"))
		{
			if (cart.getCartID().equals(cartID))
			{
				ca = cart;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(p) == false && Integer.valueOf(quantity) > 0) 
		{ 
			/* Logic here */
			if ((p.getStockLevel() != Integer.valueOf(quantity)))
			{
				updateCart(p.getProductID(), p.getProductName(), Integer.valueOf(quantity), p.getPrice(),ca);
				
				refresh();
				// post-condition checking
				if (!(((p.getStockLevel() >= Integer.valueOf(quantity)) ? true
				 && 
				true : true))) {
					throw new PostconditionException();
				}
				
				//return code
				refresh();
				return true;
			}
			else
			{
			 	
			 	refresh();
			 	// post-condition checking
			 	if (!(((p.getStockLevel() >= Integer.valueOf(quantity)) ? true
			 	 && 
			 	true : true))) {
			 		throw new PostconditionException();
			 	}
			 	
			 	//return code
			 	refresh();
			 	return false;
			}
			
			
			
		
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [barcode, quantity] 
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean updateCart(String productID, String productName, int quantity, float price,Cart c) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get selectedProduct
		Product selectedProduct = null;
		//no nested iterator --  iterator: any previous:any
		for (Product p : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p.getProductID().equals(productID) && p.getProductName().equals(productName))
			{
				selectedProduct = p;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
		/* service reference */
		/* service temp attribute */
		/* objects in definition */  
		Product Pre_selectedProduct = SerializationUtils.clone(selectedProduct);
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(selectedProduct) == false && Integer.valueOf(quantity) > 0) 
		{ 
			/* Logic here */
			if ((selectedProduct.getStockLevel() >= Integer.valueOf(quantity)))
			{
				c.setProductList(selectedProduct);
				selectedProduct.setStockLevel(selectedProduct.getStockLevel()-Integer.valueOf(quantity));
				
				refresh();
				// post-condition checking
				if (!(((selectedProduct.getStockLevel() >= Integer.valueOf(quantity)) ? StandardOPs.includes(c.getProductList(), selectedProduct)
				 && 
				selectedProduct.getStockLevel() == Pre_selectedProduct.getStockLevel()-Integer.valueOf(quantity)
				 && 
				true : true))) {
					throw new PostconditionException();
				}
				
				//return code
				refresh();
				return true;
			}
			else
			{
			 	
			 	refresh();
			 	// post-condition checking
			 	if (!(((selectedProduct.getStockLevel() >= Integer.valueOf(quantity)) ? StandardOPs.includes(c.getProductList(), selectedProduct)
			 	 && 
			 	selectedProduct.getStockLevel() == Pre_selectedProduct.getStockLevel()-Integer.valueOf(quantity)
			 	 && 
			 	true : true))) {
			 		throw new PostconditionException();
			 	}
			 	
			 	//return code
			 	refresh();
			 	return false;
			}
			
			
			
		
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [productID, productName] 
		//all relevant vars : selectedProduct
		//all relevant entities : Product
	}  
	
	static {opINVRelatedEntity.put("updateCart", Arrays.asList("Product"));}
	 
	
	
	
	/* temp property for controller */
			
	/* all get and set functions for temp property*/
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
