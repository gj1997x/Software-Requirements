package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ManageInventoryServiceImpl implements ManageInventoryService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ManageInventoryServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public List<Inventory> viewInventoryStockLevel() throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get i
		List<Inventory> Inventory = new LinkedList<>();
		Inventory = (List<Inventory>)EntityManager.getAllInstancesOf("Inventory");
		/* previous state in post-condition*/
 
		/* check precondition */
		if (true) 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
			refresh(); return Inventory;
		}
		else
		{
			throw new PreconditionException();
		}
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean recordRestock(String productName, String productID, int quantity) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get p
		Product p = null;
		//no nested iterator --  iterator: any previous:any
		for ( Product p1 : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p1.getProductID().equals(productID) && p1.getProductName().equals(productName))
			{
				p = p1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
		/* service reference */
		/* service temp attribute */
		/* objects in definition */  
		Product Pre_p = SerializationUtils.clone(p);
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(p) == false) 
		{ 
			/* Logic here */
			p.setStockLevel(p.getStockLevel()+quantity);
			
			
			refresh();
			// post-condition checking
			if (!(p.getStockLevel() == Pre_p.getStockLevel()+quantity
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [productName, productID] 
		//all relevant vars : p
		//all relevant entities : Product
	}  
	
	static {opINVRelatedEntity.put("recordRestock", Arrays.asList("Product"));}
	 
	@SuppressWarnings("unchecked")
	public boolean sendToSupplier(String supplierID, String productID, String supplierOrderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get s
		Supplier s = null;
		//no nested iterator --  iterator: any previous:any
		for ( Supplier s1 : (List<Supplier>)EntityManager.getAllInstancesOf("Supplier"))
		{
			if (s1.getSupplierID().equals(supplierID))
			{
				s = s1;
				break;
			}
				
			
		}
		//Get p
		Product p = null;
		//no nested iterator --  iterator: any previous:any
		for ( Product p1 : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p1.getProductID().equals(productID))
			{
				p = p1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(s) == false && StandardOPs.oclIsundefined(p) == false) 
		{ 
			/* Logic here */
			SupplierOrder so = null;
			so = (SupplierOrder) EntityManager.createObject("Supplier");
			so.setSupplierID(supplierID);
			so.setSupplierOrderID(supplierOrderID);
			so.setProductsList(p);
			so.setStatus("New Order");
			EntityManager.addObject("Supplier", so);
			s.addFulfilledBy(so);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			so.getSupplierID() == supplierID
			 && 
			so.getSupplierOrderID() == supplierOrderID
			 && 
			StandardOPs.includes(so.getProductsList(), p)
			 && 
			so.getStatus() == "New Order"
			/* && 
			StandardOPs.includes(((List<so>)EntityManager.getAllInstancesOf("so")), so)
			 && 
			StandardOPs.includes(s.getFulfill(), so)*/
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [supplierID, productID, supplierOrderID] 
		//all relevant vars : p so
		//all relevant entities : Product Supplier
	}  
	
	static {opINVRelatedEntity.put("sendToSupplier", Arrays.asList("Product","Supplier"));}
	 
	@SuppressWarnings("unchecked")
	public boolean orderStockProducts(String productID, int quantity, String restockProductsID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get p
		Product p = null;
		//no nested iterator --  iterator: any previous:any
		for ( Product p1 : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p1.getProductID().equals(productID))
			{
				p = p1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(p) == false && quantity > 0) 
		{ 
			/* Logic here */
			RestockProducts rp = null;
			rp = (RestockProducts) EntityManager.createObject("RestockProducts");
			rp.setProductsNeededList(p);
			rp.setRestockProductsID(restockProductsID);
			EntityManager.addObject("RestockProducts", rp);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			rp.getProductsNeededList() == p
			 && 
			rp.getRestockProductsID() == restockProductsID
			 && 
			StandardOPs.includes(((List<RestockProducts>)EntityManager.getAllInstancesOf("rp")), rp)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [productID, restockProductsID] 
		//all relevant vars : rp
		//all relevant entities : RestockProducts
	}  
	
	static {opINVRelatedEntity.put("orderStockProducts", Arrays.asList("RestockProducts"));}
	 
	@SuppressWarnings("unchecked")
	public boolean creatingNewSupplier(String supplierID, String companyName, String contactDetails) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get s
		 Supplier s = null;
		//no nested iterator --  iterator: any previous:any
		for ( Supplier s1 : (List<Supplier>)EntityManager.getAllInstancesOf("Supplier"))
		{
			if (s1.getSupplierID().equals(supplierID))
			{
				s = s1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(s) == true) 
		{ 
			/* Logic here */
			Supplier s1 = null;
			s1 = (Supplier) EntityManager.createObject("Supplier");
			s1.setSupplierID(supplierID);
			s1.setCompanyName(companyName);
			s1.setContactDetails(contactDetails);
			EntityManager.addObject("Supplier", s1);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			s1.getSupplierID() == supplierID
			 && 
			s1.getCompanyName() == companyName
			 && 
			s1.getContactDetails() == contactDetails
			 && 
			StandardOPs.includes(((List<Supplier>)EntityManager.getAllInstancesOf("s")), s1)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [supplierID, companyName, contactDetails] 
		//all relevant vars : s
		//all relevant entities : Supplier
	}  
	
	static {opINVRelatedEntity.put("creatingNewSupplier", Arrays.asList("Supplier"));}
	 
	
	
	
	/* temp property for controller */
	private Supplier ExistingSupplier;
			
	/* all get and set functions for temp property*/
	public Supplier getExistingSupplier() {
		return ExistingSupplier;
	}	
	
	public void setExistingSupplier(Supplier existingsupplier) {
		this.ExistingSupplier = existingsupplier;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
