package services.impl;

import entities.*;
import services.*;

public class DataFitService {
	
	public static void fit()  throws PreconditionException {
		//Write your data code here....
	}
	
}	
