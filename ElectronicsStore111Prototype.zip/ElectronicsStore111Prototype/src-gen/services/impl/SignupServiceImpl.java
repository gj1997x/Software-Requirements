package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class SignupServiceImpl implements SignupService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public SignupServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean customerRegUsername(String username) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (username != "") 
		{ 
			/* Logic here */
			this.setUserName(username);
			
			
			refresh();
			// post-condition checking
			if (!(this.getUserName() == username
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [username] 
		//all relevant vars : this
		//all relevant entities : 
	}  
	
	static {opINVRelatedEntity.put("customerRegUsername", Arrays.asList(""));}
	 
	@SuppressWarnings("unchecked")
	public boolean customerRegPassword(String password) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (password != "") 
		{ 
			/* Logic here */
			this.setPassword(password);
			
			
			refresh();
			// post-condition checking
			if (!(this.getPassword() == password
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [password] 
		//all relevant vars : this
		//all relevant entities : 
	}  
	
	static {opINVRelatedEntity.put("customerRegPassword", Arrays.asList(""));}
	 
	@SuppressWarnings("unchecked")
	public boolean customerDetails(String email, String phonenumber, String address, String fullName, String userID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (email != "" && phonenumber != "" && address != "" && fullName != "" && userID != "") 
		{ 
			/* Logic here */
			Users u = null;
			u = (Users) EntityManager.createObject("Users");
			u.setUserID(userID);
			u.setUserName(this.getUserName());
			u.setPassword(this.getPassword());
			EntityManager.addObject("Users", u);
			//this.setEmail(email);
			//u.setPhoneNumber(phonenumber);
			//this.setAddress(address);
			//this.setFullName(fullName);
			//c.addRelatedTo(u);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			u.getUserID() == userID
			 && 
			u.getUserName() == this.getUserName()
			 && 
			u.getPassword() == this.getPassword()
			 && 
			/*this.getEmail() == email
			 && 
			this.getPhoneNumber() == phonenumber
			 && 
			this.getAddress() == address
			 && 
			this.getFullName() == fullName
			 && */
			//StandardOPs.includes(c.getRelatedTo(), u)
			 //&& 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [email, phonenumber, address, fullName, userID] 
		//all relevant vars : u this
		//all relevant entities :  
	}  
	
	static {opINVRelatedEntity.put("customerDetails", Arrays.asList("",""));}
	 
	@SuppressWarnings("unchecked")
	public boolean saveDetails(String usename, String password, String email, String phonenumber, String address, String customerID, String fullName) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get newMember
		//Member newMember = null;
		//newMember =(Member) EntityManager.createObject("Member");;
		//newMember.setMemberID("M"+customerID);
		//newMember.setFullName(fullName);
		//newMember.setLoyaltyPoints(0);
		//newMember.setTier("Tier 1");
		//ReturnedProducts r = null;
		//r = (ReturnedProducts) EntityManager.createObject("ReturnedProducts");
		//this.setProductID(productID);
		//r.setProductID(productID);
		//EntityManager.addObject("ReturnedProducts", r);
		
		
		refresh();
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		//Get u
		Users u = null;
		//no nested iterator --  iterator: any previous:any
		for (Users u1 : (List<Users>)EntityManager.getAllInstancesOf("Users"))
		{
			if (u1.getUserName().equals(usename))
			{
				u = u1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (usename != "" && password!= "" && email != "" && phonenumber != "" && address != "" && fullName != "" && customerID != "") 
		{ 
			/* Logic here */
			Member newMember = null;
			newMember =(Member) EntityManager.createObject("Member");
			newMember.setMemberID("M"+customerID);
			newMember.setFullName(fullName);
			newMember.setLoyaltyPoints(0);
			newMember.setTier("Tier 1");
			EntityManager.addObject("Member", newMember);
			u.setUserName(usename);
			u.setPassword(password);
			EntityManager.addObject("Users", u);
			c.setEmail(email);
			c.setPhoneNumber(Integer.valueOf(PhoneNumber));
			c.setAddress(address);
			c.setCustomerID(customerID);
			c.setFullName(fullName);
			EntityManager.addObject("Customer", c);
			c.setBecomes(newMember);
			u.setMustBeAlso(newMember);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			u.getUserName() == usename
			 && 
			u.getPassword() == password
			 && 
			c.getEmail() == email
			 && 
			c.getPhoneNumber() == Integer.valueOf(PhoneNumber)
			 && 
			c.getAddress() == address
			 && 
			c.getCustomerID() == customerID
			 && 
			c.getFullName() == fullName
			// && 
			//StandardOPs.includes(List<Customer> c.getAre(), newMember)
			 //&& 
			//StandardOPs.includes(u.getBelongTo(), m)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [usename, password, email, phonenumber, address, customerID, fullName] 
		//all relevant vars : m
		//all relevant entities : Member
	}  
	
	static {opINVRelatedEntity.put("saveDetails", Arrays.asList("Member"));}
	 
	
	
	
	/* temp property for controller */
	private String UserName;
	private String Password;
	private String FullName;
	private String Address;
	private int PhoneNumber;
	private String Email;
			
	/* all get and set functions for temp property*/
	public String getUserName() {
		return UserName;
	}	
	
	public void setUserName(String username) {
		this.UserName = username;
	}
	public String getPassword() {
		return Password;
	}	
	
	public void setPassword(String password) {
		this.Password = password;
	}
	public String getFullName() {
		return FullName;
	}	
	
	public void setFullName(String fullname) {
		this.FullName = fullname;
	}
	public String getAddress() {
		return Address;
	}	
	
	public void setAddress(String address) {
		this.Address = address;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}	
	
	public void setPhoneNumber(int phonenumber) {
		this.PhoneNumber = phonenumber;
	}
	public String getEmail() {
		return Email;
	}	
	
	public void setEmail(String email) {
		this.Email = email;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
