package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class PrintReceiptServiceImpl implements PrintReceiptService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public PrintReceiptServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean getUserDetails(String customerID, String transactionID, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		//Get t
		Transaction t = null;
		//no nested iterator --  iterator: any previous:any
		for (Transaction t1 : (List<Transaction>)EntityManager.getAllInstancesOf("Transaction"))
		{
			if (t1.getTransactionID().equals(transactionID))
			{
				t = t1;
				break;
			}
				
			
		}
		//Get o
		Order o = null;
		//no nested iterator --  iterator: any previous:any
		for (Order o1 : (List<Order>)EntityManager.getAllInstancesOf("Order"))
		{
			if (o1.getOrderID().equals(orderID))
			{
				o = o1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(c) == false && StandardOPs.oclIsundefined(t) == false && StandardOPs.oclIsundefined(o) == false) 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [customerID, transactionID, orderID] 
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean printReciept(String transactionID, String customerID, String orderID, String cartID, String receiptID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		//Get t
		Transaction t = null;
		//no nested iterator --  iterator: any previous:any
		for (Transaction t2 : (List<Transaction>)EntityManager.getAllInstancesOf("Transaction"))
		{
			if (t2.getTransactionID().equals(transactionID))
			{
				t = t2;
				break;
			}
				
			
		}
		//Get o
		Order o = null;
		//no nested iterator --  iterator: any previous:any
		for (Order o2 : (List<Order>)EntityManager.getAllInstancesOf("Order"))
		{
			if (o2.getOrderID().equals(orderID))
			{
				o = o2;
				break;
			}
				
			
		}
		//Get ca
		Cart ca = null;
		//no nested iterator --  iterator: any previous:any
		for (Cart ca1 : (List<Cart>)EntityManager.getAllInstancesOf("Cart"))
		{
			if (ca1.getCartID().equals(cartID))
			{
				ca = ca1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (StandardOPs.oclIsundefined(c) == false && StandardOPs.oclIsundefined(t) == false && StandardOPs.oclIsundefined(o) == false && StandardOPs.oclIsundefined(ca) == false) 
		{ 
			/* Logic here */
			Receipt re = null;
			re = (Receipt) EntityManager.createObject("Receipt");
			re.setReceiptID(receiptID);
			re.setPaymentMethod(t.getPaymentMethod());
			re.setTransactionID(t.getTransactionID());
			re.setTotalPrice(ca.getTotalAmount());
			re.setDateOfPurchase(LocalDate.now());
			EntityManager.addObject("Receipt", re);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			re.getReceiptID() == receiptID
			 && 
			re.getPaymentMethod() == t.getPaymentMethod()
			 && 
			re.getTransactionID() == t.getTransactionID()
			 && 
			re.getTotalPrice() == ca.getTotalAmount()
			 && 
			re.getDateOfPurchase().isEqual(LocalDate.now())
			 && 
			StandardOPs.includes(((List<Receipt>)EntityManager.getAllInstancesOf("Receipt")), re)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [transactionID, customerID, orderID, cartID, receiptID] 
		//all relevant vars : re
		//all relevant entities : Receipt
	}  
	
	static {opINVRelatedEntity.put("printReciept", Arrays.asList("Receipt"));}
	 
	
	
	
	/* temp property for controller */
	private String CustomerID;
	private String TransactionID;
	private String OrderID;
			
	/* all get and set functions for temp property*/
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String transactionid) {
		this.TransactionID = transactionid;
	}
	public String getOrderID() {
		return OrderID;
	}	
	
	public void setOrderID(String orderid) {
		this.OrderID = orderid;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
