package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ReturnProductServiceImpl implements ReturnProductService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ReturnProductServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public List<Transaction> getTransactionID(String transactionID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get t
		List<Transaction> tList = new LinkedList<>();
		Transaction t = null;
		//no nested iterator --  iterator: any previous:any
		for (Transaction t1 : (List<Transaction>)EntityManager.getAllInstancesOf("Transaction"))
		{
			if (t1.getTransactionID().equals(transactionID))
			{
				t = t1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (transactionID != "") 
		{ 
			/* Logic here */
			this.setTransactionID(transactionID);
			
			
			refresh();
			// post-condition checking
			if (!(this.getTransactionID() == transactionID
			 && 
			true)) {
				tList.add(t);
				throw new PostconditionException();
			}
			
			refresh(); return tList;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [transactionID] 
		//all relevant vars : this
		//all relevant entities : 
	}  
	
	static {opINVRelatedEntity.put("getTransactionID", Arrays.asList(""));}
	 
	@SuppressWarnings("unchecked")
	public boolean productID(String productID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get p
		Product p = null;
		//no nested iterator --  iterator: any previous:any
		for (Product p1 : (List<Product>)EntityManager.getAllInstancesOf("Product"))
		{
			if (p1.getProductID().equals(productID))
			{
				p = p1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (productID != "") 
		{ 
			/* Logic here */
			ReturnedProducts r = null;
			r = (ReturnedProducts) EntityManager.createObject("ReturnedProducts");
			this.setProductID(productID);
			r.setProductID(productID);
			EntityManager.addObject("ReturnedProducts", r);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			this.getProductID() == productID
			 && 
			r.getProductID() == productID
			 && 
			StandardOPs.includes(((List<ReturnedProducts>)EntityManager.getAllInstancesOf("ReturnedProducts")), r)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [productID] 
		//all relevant vars : r this
		//all relevant entities : ReturnedProducts 
	}  
	
	static {opINVRelatedEntity.put("productID", Arrays.asList("ReturnedProducts",""));}
	 
	@SuppressWarnings("unchecked")
	public boolean getReason(String reasonOfReturn) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (reasonOfReturn != "") 
		{ 
			/* Logic here */
			this.setReason(reasonOfReturn);
			
			
			refresh();
			// post-condition checking
			if (!(this.getReason() == reasonOfReturn)) {
				throw new PostconditionException();
			}
			return true;
		
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [reasonOfReturn] 
		//all relevant vars : this
		//all relevant entities : 
	}  
	
	static {opINVRelatedEntity.put("getReason", Arrays.asList(""));}
	 
	@SuppressWarnings("unchecked")
	public boolean saveReturn(String customerID, String transactionID, String reasonOfReturn, String returnID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get r
		ReturnedProducts r = null;
		//no nested iterator --  iterator: any previous:any
		for (ReturnedProducts r1 : (List<ReturnedProducts>)EntityManager.getAllInstancesOf("ReturnedProducts"))
		{
			if (r1.getProductID() == this.getProductID())
			{
				r = r1;
				break;
			}
				
			
		}
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer c1 : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (c1.getCustomerID().equals(customerID))
			{
				c = c1;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (customerID != "" && transactionID != "" && reasonOfReturn != "" && returnID !="") 
		{ 
			/* Logic here */
			r.setCustomerID(customerID);
			r.setTransactionID(transactionID);
			r.setReasonOfReturn(reasonOfReturn);
			r.setReturnID(returnID);
			r.setCustomerID(customerID);
			r.setTransactionID(transactionID);
			r.setReasonOfReturn(this.getReason());
			r.addCanReturn(c);
			
			
			refresh();
			// post-condition checking
			if (!(c.getCustomerID() == customerID
			 && 
			this.getTransactionID() == transactionID
			 && 
			this.getReason() == reasonOfReturn
			 && 
			r.getReturnID() == returnID
			 && 
			r.getCustomerID() == c.getCustomerID()
			 && 
			r.getTransactionID() == this.getTransactionID()
			 && 
			r.getReasonOfReturn() == this.getReason()
			 && 
			StandardOPs.includes(c.getCanReturn(), r)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [customerID, transactionID, reasonOfReturn, returnID] 
		//all relevant vars : r this
		//all relevant entities : ReturnedProducts 
	}  
	
	static {opINVRelatedEntity.put("saveReturn", Arrays.asList("ReturnedProducts",""));}
	 
	
	
	
	/* temp property for controller */
	private String ProductID;
	private String TransactionID;
	private String Reason;
			
	/* all get and set functions for temp property*/
	public String getProductID() {
		return ProductID;
	}	
	
	public void setProductID(String productid) {
		this.ProductID = productid;
	}
	public String getTransactionID() {
		return TransactionID;
	}	
	
	public void setTransactionID(String transactionid) {
		this.TransactionID = transactionid;
	}
	public String getReason() {
		return Reason;
	}	
	
	public void setReason(String reason) {
		this.Reason = reason;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
