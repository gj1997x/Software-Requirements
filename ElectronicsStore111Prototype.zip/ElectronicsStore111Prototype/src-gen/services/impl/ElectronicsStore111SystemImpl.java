package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ElectronicsStore111SystemImpl implements ElectronicsStore111System, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ElectronicsStore111SystemImpl() {
		services = new ThirdPartyServicesImpl();
	}

	public void refresh() {
		Electronics electronics_service = (Electronics) ServiceManager
				.getAllInstancesOf("Electronics").get(0);
		SignupService signupservice_service = (SignupService) ServiceManager
				.getAllInstancesOf("SignupService").get(0);
		SystemLoginService systemloginservice_service = (SystemLoginService) ServiceManager
				.getAllInstancesOf("SystemLoginService").get(0);
		CredentialsCheckService credentialscheckservice_service = (CredentialsCheckService) ServiceManager
				.getAllInstancesOf("CredentialsCheckService").get(0);
		BrowseProductsService browseproductsservice_service = (BrowseProductsService) ServiceManager
				.getAllInstancesOf("BrowseProductsService").get(0);
		CheckOutService checkoutservice_service = (CheckOutService) ServiceManager
				.getAllInstancesOf("CheckOutService").get(0);
		ReturnProductService returnproductservice_service = (ReturnProductService) ServiceManager
				.getAllInstancesOf("ReturnProductService").get(0);
		ReviewCartService reviewcartservice_service = (ReviewCartService) ServiceManager
				.getAllInstancesOf("ReviewCartService").get(0);
		ModifyCartService modifycartservice_service = (ModifyCartService) ServiceManager
				.getAllInstancesOf("ModifyCartService").get(0);
		GiveFeedbackService givefeedbackservice_service = (GiveFeedbackService) ServiceManager
				.getAllInstancesOf("GiveFeedbackService").get(0);
		MembershipStatusService membershipstatusservice_service = (MembershipStatusService) ServiceManager
				.getAllInstancesOf("MembershipStatusService").get(0);
		ScanProductsService scanproductsservice_service = (ScanProductsService) ServiceManager
				.getAllInstancesOf("ScanProductsService").get(0);
		ProcessPaymentService processpaymentservice_service = (ProcessPaymentService) ServiceManager
				.getAllInstancesOf("ProcessPaymentService").get(0);
		ProcessReturnService processreturnservice_service = (ProcessReturnService) ServiceManager
				.getAllInstancesOf("ProcessReturnService").get(0);
		PrintReceiptService printreceiptservice_service = (PrintReceiptService) ServiceManager
				.getAllInstancesOf("PrintReceiptService").get(0);
		PaymentValidationService paymentvalidationservice_service = (PaymentValidationService) ServiceManager
				.getAllInstancesOf("PaymentValidationService").get(0);
		InStorePaymentValidationService instorepaymentvalidationservice_service = (InStorePaymentValidationService) ServiceManager
				.getAllInstancesOf("InStorePaymentValidationService").get(0);
		ViewReportsService viewreportsservice_service = (ViewReportsService) ServiceManager
				.getAllInstancesOf("ViewReportsService").get(0);
		ManageInventoryService manageinventoryservice_service = (ManageInventoryService) ServiceManager
				.getAllInstancesOf("ManageInventoryService").get(0);
		AccessFeedbackService accessfeedbackservice_service = (AccessFeedbackService) ServiceManager
				.getAllInstancesOf("AccessFeedbackService").get(0);
		ProcessOrdersService processordersservice_service = (ProcessOrdersService) ServiceManager
				.getAllInstancesOf("ProcessOrdersService").get(0);
		ProcessCheckoutService processcheckoutservice_service = (ProcessCheckoutService) ServiceManager
				.getAllInstancesOf("ProcessCheckoutService").get(0);
		ViewNewOrdersService viewnewordersservice_service = (ViewNewOrdersService) ServiceManager
				.getAllInstancesOf("ViewNewOrdersService").get(0);
	}			
	
	/* Generate buiness logic according to functional requirement */
	
	
	
	/* temp property for controller */
			
	/* all get and set functions for temp property*/
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
