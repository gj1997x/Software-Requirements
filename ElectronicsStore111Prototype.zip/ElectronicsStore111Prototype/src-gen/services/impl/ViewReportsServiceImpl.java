package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class ViewReportsServiceImpl implements ViewReportsService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public ViewReportsServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public List<Report> viewAllReports() throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get allReports
		List<Report> allReports = new LinkedList<>();
		allReports=(List<Report>)EntityManager.getAllInstancesOf("Report");
		/* previous state in post-condition*/
 
		/* check precondition */
		if (true) 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
			refresh(); return allReports;
		}
		else
		{
			throw new PreconditionException();
		}
	}  
	
	 
	@SuppressWarnings("unchecked")
	public Report getReportType(String reportID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get r
		Report r = null;
		//no nested iterator --  iterator: any previous:any
		for (Report rep : (List<Report>)EntityManager.getAllInstancesOf("Report"))
		{
			if (rep.getReportID().equals(reportID))
			{
				r = rep;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (reportID != "") 
		{ 
			/* Logic here */
			
			
			refresh();
			// post-condition checking
			if (!(true)) {
				throw new PostconditionException();
			}
			
			refresh(); return r;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [reportID] 
	}  
	
	 
	@SuppressWarnings("unchecked")
	public boolean generateReport(String type, LocalDate startDate, LocalDate endDate, String reportID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (type != ""  && reportID != "") 
		{ 
			/* Logic here */
			Report report = null;
			report = (Report) EntityManager.createObject("Report");
			report.setReportID(reportID);
			report.setTypeOfReport(type);
			report.setDateGenerated(LocalDate.now());
			report.setReportResult("We will be integrating a third party tool that helps in creating and providing visual charts");
			//report.setDateGenerated(LocalDate.now());
			EntityManager.addObject("Report", report);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			report.getReportID() == reportID
			 && 
			report.getTypeOfReport() == type
			 && 
			report.getDateGenerated().isEqual(LocalDate.now())
			 && 
			report.getReportResult().equals("We will be integrating a third party tool that helps in creating and providing visual charts")
			 && 
			StandardOPs.includes(((List<Report>)EntityManager.getAllInstancesOf("Report")), report)
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [type, reportID] 
		//all relevant vars : report
		//all relevant entities : Report
	}  
	
	static {opINVRelatedEntity.put("generateReport", Arrays.asList("Report"));}
	 
	
	
	
	/* temp property for controller */
	private List<String> ValidReportTypes;
			
	/* all get and set functions for temp property*/
	public List<String> getValidReportTypes() {
		return ValidReportTypes;
	}	
	
	public void setValidReportTypes(List<String> validreporttypes) {
		this.ValidReportTypes = validreporttypes;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
