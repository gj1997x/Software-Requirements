package services.impl;

import services.*;
import entities.*;
import java.util.List;
import java.util.LinkedList;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.function.Predicate;
import java.util.Arrays;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BooleanSupplier;
import org.apache.commons.lang3.SerializationUtils;
import java.util.Iterator;

public class GiveFeedbackServiceImpl implements GiveFeedbackService, Serializable {
	
	
	public static Map<String, List<String>> opINVRelatedEntity = new HashMap<String, List<String>>();
	
	
	ThirdPartyServices services;
			
	public GiveFeedbackServiceImpl() {
		services = new ThirdPartyServicesImpl();
	}

	
	//Shared variable from system services
	
	/* Shared variable from system services and get()/set() methods */
			
	/* all get and set functions for temp property*/
				
	
	
	/* Generate inject for sharing temp variables between use cases in system service */
	public void refresh() {
		ElectronicsStore111System electronicsstore111system_service = (ElectronicsStore111System) ServiceManager.getAllInstancesOf("ElectronicsStore111System").get(0);
	}
	
	/* Generate buiness logic according to functional requirement */
	@SuppressWarnings("unchecked")
	public boolean giveFeedback(String textFeedback, String customerID, String feedbackID) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* previous state in post-condition*/
 
		/* check precondition */
		if (textFeedback != "" && customerID != "" && feedbackID != "") 
		{ 
			/* Logic here */
			this.setFeedback(textFeedback);
			this.setCustomerID(customerID);
			this.setFeedbackID(feedbackID);
			
			
			refresh();
			// post-condition checking
			if (!(this.getFeedback() == textFeedback
			 && 
			this.getCustomerID() == customerID
			 && 
			this.getFeedbackID() == feedbackID
			 && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [textFeedback, customerID, feedbackID] 
		//all relevant vars : this
		//all relevant entities : 
	}  
	
	static {opINVRelatedEntity.put("giveFeedback", Arrays.asList(""));}
	 
	@SuppressWarnings("unchecked")
	public boolean saveFeedback(String customerID, String textFeedback) throws PreconditionException, PostconditionException, ThirdPartyServiceException {
		
		
		/* Code generated for contract definition */
		//Get c
		Customer c = null;
		//no nested iterator --  iterator: any previous:any
		for (Customer i : (List<Customer>)EntityManager.getAllInstancesOf("Customer"))
		{
			if (i.getCustomerID() == this.getCustomerID())
			{
				c = i;
				break;
			}
				
			
		}
		//Get f
		Feedback f = null;
		//no nested iterator --  iterator: any previous:any
		for (Feedback tmp : (List<Feedback>)EntityManager.getAllInstancesOf("Feedback"))
		{
			if (tmp.getFeedbackID() == this.getFeedbackID())
			{
				f = tmp;
				break;
			}
				
			
		}
		/* previous state in post-condition*/
 
		/* check precondition */
		if (textFeedback != "" && customerID != "") 
		{ 
			/* Logic here */
			Feedback f1 = null;
			f1 = (Feedback) EntityManager.createObject("Feedback");
			f1.setFeedbackID(this.getFeedbackID());
			f1.setFeedbackContent(this.getFeedback());
			f1.setCustomerID(this.getCustomerID());
			EntityManager.addObject("Feedback", f1);
			c.setSuggest(f1);
			
			
			refresh();
			// post-condition checking
			if (!(true && 
			f1.getFeedbackID() == this.getFeedbackID()
			 && 
			f1.getFeedbackContent() == this.getFeedback()
			 && 
			f1.getCustomerID() == this.getCustomerID()
			 && 
			//StandardOPs.includes(c.getSuggest(), f)
			// && 
			true)) {
				throw new PostconditionException();
			}
			
		
			//return primitive type
			refresh();				
			return true;
		}
		else
		{
			throw new PreconditionException();
		}
		//string parameters: [customerID, textFeedback] 
		//all relevant vars : f
		//all relevant entities : Feedback
	}  
	
	static {opINVRelatedEntity.put("saveFeedback", Arrays.asList("Feedback"));}
	 
	
	
	
	/* temp property for controller */
	private String Feedback;
	private String CustomerID;
	private String FeedbackID;
			
	/* all get and set functions for temp property*/
	public String getFeedback() {
		return Feedback;
	}	
	
	public void setFeedback(String feedback) {
		this.Feedback = feedback;
	}
	public String getCustomerID() {
		return CustomerID;
	}	
	
	public void setCustomerID(String customerid) {
		this.CustomerID = customerid;
	}
	public String getFeedbackID() {
		return FeedbackID;
	}	
	
	public void setFeedbackID(String feedbackid) {
		this.FeedbackID = feedbackid;
	}
	
	/* invarints checking*/
	public final static ArrayList<String> allInvariantCheckingFunction = new ArrayList<String>(Arrays.asList());
			
}
