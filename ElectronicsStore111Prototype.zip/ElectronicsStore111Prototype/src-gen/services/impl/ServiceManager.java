package services.impl;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import services.*;
	
public class ServiceManager {
	
	private static Map<String, List> AllServiceInstance = new HashMap<String, List>();
	
	private static List<Electronics> ElectronicsInstances = new LinkedList<Electronics>();
	private static List<ThirdPartyServices> ThirdPartyServicesInstances = new LinkedList<ThirdPartyServices>();
	private static List<SignupService> SignupServiceInstances = new LinkedList<SignupService>();
	private static List<SystemLoginService> SystemLoginServiceInstances = new LinkedList<SystemLoginService>();
	private static List<CredentialsCheckService> CredentialsCheckServiceInstances = new LinkedList<CredentialsCheckService>();
	private static List<BrowseProductsService> BrowseProductsServiceInstances = new LinkedList<BrowseProductsService>();
	private static List<CheckOutService> CheckOutServiceInstances = new LinkedList<CheckOutService>();
	private static List<ReturnProductService> ReturnProductServiceInstances = new LinkedList<ReturnProductService>();
	private static List<ReviewCartService> ReviewCartServiceInstances = new LinkedList<ReviewCartService>();
	private static List<ModifyCartService> ModifyCartServiceInstances = new LinkedList<ModifyCartService>();
	private static List<GiveFeedbackService> GiveFeedbackServiceInstances = new LinkedList<GiveFeedbackService>();
	private static List<MembershipStatusService> MembershipStatusServiceInstances = new LinkedList<MembershipStatusService>();
	private static List<ScanProductsService> ScanProductsServiceInstances = new LinkedList<ScanProductsService>();
	private static List<ProcessPaymentService> ProcessPaymentServiceInstances = new LinkedList<ProcessPaymentService>();
	private static List<ProcessReturnService> ProcessReturnServiceInstances = new LinkedList<ProcessReturnService>();
	private static List<PrintReceiptService> PrintReceiptServiceInstances = new LinkedList<PrintReceiptService>();
	private static List<PaymentValidationService> PaymentValidationServiceInstances = new LinkedList<PaymentValidationService>();
	private static List<InStorePaymentValidationService> InStorePaymentValidationServiceInstances = new LinkedList<InStorePaymentValidationService>();
	private static List<ViewReportsService> ViewReportsServiceInstances = new LinkedList<ViewReportsService>();
	private static List<ManageInventoryService> ManageInventoryServiceInstances = new LinkedList<ManageInventoryService>();
	private static List<AccessFeedbackService> AccessFeedbackServiceInstances = new LinkedList<AccessFeedbackService>();
	private static List<ProcessOrdersService> ProcessOrdersServiceInstances = new LinkedList<ProcessOrdersService>();
	private static List<ProcessCheckoutService> ProcessCheckoutServiceInstances = new LinkedList<ProcessCheckoutService>();
	private static List<ViewNewOrdersService> ViewNewOrdersServiceInstances = new LinkedList<ViewNewOrdersService>();
	private static List<ElectronicsStore111System> ElectronicsStore111SystemInstances = new LinkedList<ElectronicsStore111System>();
	
	static {
		AllServiceInstance.put("Electronics", ElectronicsInstances);
		AllServiceInstance.put("ThirdPartyServices", ThirdPartyServicesInstances);
		AllServiceInstance.put("SignupService", SignupServiceInstances);
		AllServiceInstance.put("SystemLoginService", SystemLoginServiceInstances);
		AllServiceInstance.put("CredentialsCheckService", CredentialsCheckServiceInstances);
		AllServiceInstance.put("BrowseProductsService", BrowseProductsServiceInstances);
		AllServiceInstance.put("CheckOutService", CheckOutServiceInstances);
		AllServiceInstance.put("ReturnProductService", ReturnProductServiceInstances);
		AllServiceInstance.put("ReviewCartService", ReviewCartServiceInstances);
		AllServiceInstance.put("ModifyCartService", ModifyCartServiceInstances);
		AllServiceInstance.put("GiveFeedbackService", GiveFeedbackServiceInstances);
		AllServiceInstance.put("MembershipStatusService", MembershipStatusServiceInstances);
		AllServiceInstance.put("ScanProductsService", ScanProductsServiceInstances);
		AllServiceInstance.put("ProcessPaymentService", ProcessPaymentServiceInstances);
		AllServiceInstance.put("ProcessReturnService", ProcessReturnServiceInstances);
		AllServiceInstance.put("PrintReceiptService", PrintReceiptServiceInstances);
		AllServiceInstance.put("PaymentValidationService", PaymentValidationServiceInstances);
		AllServiceInstance.put("InStorePaymentValidationService", InStorePaymentValidationServiceInstances);
		AllServiceInstance.put("ViewReportsService", ViewReportsServiceInstances);
		AllServiceInstance.put("ManageInventoryService", ManageInventoryServiceInstances);
		AllServiceInstance.put("AccessFeedbackService", AccessFeedbackServiceInstances);
		AllServiceInstance.put("ProcessOrdersService", ProcessOrdersServiceInstances);
		AllServiceInstance.put("ProcessCheckoutService", ProcessCheckoutServiceInstances);
		AllServiceInstance.put("ViewNewOrdersService", ViewNewOrdersServiceInstances);
		AllServiceInstance.put("ElectronicsStore111System", ElectronicsStore111SystemInstances);
	} 
	
	public static List getAllInstancesOf(String ClassName) {
			 return AllServiceInstance.get(ClassName);
	}	
	
	public static Electronics createElectronics() {
		Electronics s = new ElectronicsImpl();
		ElectronicsInstances.add(s);
		return s;
	}
	public static ThirdPartyServices createThirdPartyServices() {
		ThirdPartyServices s = new ThirdPartyServicesImpl();
		ThirdPartyServicesInstances.add(s);
		return s;
	}
	public static SignupService createSignupService() {
		SignupService s = new SignupServiceImpl();
		SignupServiceInstances.add(s);
		return s;
	}
	public static SystemLoginService createSystemLoginService() {
		SystemLoginService s = new SystemLoginServiceImpl();
		SystemLoginServiceInstances.add(s);
		return s;
	}
	public static CredentialsCheckService createCredentialsCheckService() {
		CredentialsCheckService s = new CredentialsCheckServiceImpl();
		CredentialsCheckServiceInstances.add(s);
		return s;
	}
	public static BrowseProductsService createBrowseProductsService() {
		BrowseProductsService s = new BrowseProductsServiceImpl();
		BrowseProductsServiceInstances.add(s);
		return s;
	}
	public static CheckOutService createCheckOutService() {
		CheckOutService s = new CheckOutServiceImpl();
		CheckOutServiceInstances.add(s);
		return s;
	}
	public static ReturnProductService createReturnProductService() {
		ReturnProductService s = new ReturnProductServiceImpl();
		ReturnProductServiceInstances.add(s);
		return s;
	}
	public static ReviewCartService createReviewCartService() {
		ReviewCartService s = new ReviewCartServiceImpl();
		ReviewCartServiceInstances.add(s);
		return s;
	}
	public static ModifyCartService createModifyCartService() {
		ModifyCartService s = new ModifyCartServiceImpl();
		ModifyCartServiceInstances.add(s);
		return s;
	}
	public static GiveFeedbackService createGiveFeedbackService() {
		GiveFeedbackService s = new GiveFeedbackServiceImpl();
		GiveFeedbackServiceInstances.add(s);
		return s;
	}
	public static MembershipStatusService createMembershipStatusService() {
		MembershipStatusService s = new MembershipStatusServiceImpl();
		MembershipStatusServiceInstances.add(s);
		return s;
	}
	public static ScanProductsService createScanProductsService() {
		ScanProductsService s = new ScanProductsServiceImpl();
		ScanProductsServiceInstances.add(s);
		return s;
	}
	public static ProcessPaymentService createProcessPaymentService() {
		ProcessPaymentService s = new ProcessPaymentServiceImpl();
		ProcessPaymentServiceInstances.add(s);
		return s;
	}
	public static ProcessReturnService createProcessReturnService() {
		ProcessReturnService s = new ProcessReturnServiceImpl();
		ProcessReturnServiceInstances.add(s);
		return s;
	}
	public static PrintReceiptService createPrintReceiptService() {
		PrintReceiptService s = new PrintReceiptServiceImpl();
		PrintReceiptServiceInstances.add(s);
		return s;
	}
	public static PaymentValidationService createPaymentValidationService() {
		PaymentValidationService s = new PaymentValidationServiceImpl();
		PaymentValidationServiceInstances.add(s);
		return s;
	}
	public static InStorePaymentValidationService createInStorePaymentValidationService() {
		InStorePaymentValidationService s = new InStorePaymentValidationServiceImpl();
		InStorePaymentValidationServiceInstances.add(s);
		return s;
	}
	public static ViewReportsService createViewReportsService() {
		ViewReportsService s = new ViewReportsServiceImpl();
		ViewReportsServiceInstances.add(s);
		return s;
	}
	public static ManageInventoryService createManageInventoryService() {
		ManageInventoryService s = new ManageInventoryServiceImpl();
		ManageInventoryServiceInstances.add(s);
		return s;
	}
	public static AccessFeedbackService createAccessFeedbackService() {
		AccessFeedbackService s = new AccessFeedbackServiceImpl();
		AccessFeedbackServiceInstances.add(s);
		return s;
	}
	public static ProcessOrdersService createProcessOrdersService() {
		ProcessOrdersService s = new ProcessOrdersServiceImpl();
		ProcessOrdersServiceInstances.add(s);
		return s;
	}
	public static ProcessCheckoutService createProcessCheckoutService() {
		ProcessCheckoutService s = new ProcessCheckoutServiceImpl();
		ProcessCheckoutServiceInstances.add(s);
		return s;
	}
	public static ViewNewOrdersService createViewNewOrdersService() {
		ViewNewOrdersService s = new ViewNewOrdersServiceImpl();
		ViewNewOrdersServiceInstances.add(s);
		return s;
	}
	public static ElectronicsStore111System createElectronicsStore111System() {
		ElectronicsStore111System s = new ElectronicsStore111SystemImpl();
		ElectronicsStore111SystemInstances.add(s);
		return s;
	}
}	
