package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ReturnProductService {

	/* all system operations of the use case*/
	List<Transaction> getTransactionID(String transactionID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean productID(String productID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean getReason(String reasonOfReturn) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean saveReturn(String customerID, String transactionID, String reasonOfReturn, String returnID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getProductID();
	void setProductID(String productid);
	String getTransactionID();
	void setTransactionID(String transactionid);
	String getReason();
	void setReason(String reason);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
