package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface PrintReceiptService {

	/* all system operations of the use case*/
	boolean getUserDetails(String customerID, String transactionID, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean printReciept(String transactionID, String customerID, String orderID, String cartID, String receiptID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getCustomerID();
	void setCustomerID(String customerid);
	String getTransactionID();
	void setTransactionID(String transactionid);
	String getOrderID();
	void setOrderID(String orderid);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
