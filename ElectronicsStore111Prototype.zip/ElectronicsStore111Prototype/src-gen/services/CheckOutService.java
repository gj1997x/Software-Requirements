package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface CheckOutService {

	/* all system operations of the use case*/
	Cart cartSummary(String listOfProductID, String quantity, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean makePayment(String paymentMethod, String orderID, String transactionID, float totalAmount, String customerID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean getGuestUserDetails(String fullName, String address, int phoneNumber, String email, String customerID, String orderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean newOrder(String orderID, LocalDate dateOfPurchase, float totalPrice, List<Product> produceList) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getFullName();
	void setFullName(String fullname);
	String getAddress();
	void setAddress(String address);
	int getPhoneNumber();
	void setPhoneNumber(int phonenumber);
	String getEmail();
	void setEmail(String email);
	String getUserID();
	void setUserID(String userid);
	LocalDate getDateOfPurchase();
	void setDateOfPurchase(LocalDate dateofpurchase);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
