package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ProcessReturnService {

	/* all system operations of the use case*/
	boolean getCustomerID(String customerID, String transactionID, String reasonOfReturn, String productID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getCustomerID();
	void setCustomerID(String customerid);
	String getTransactionID();
	void setTransactionID(String transactionid);
	String getOrderID();
	void setOrderID(String orderid);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
