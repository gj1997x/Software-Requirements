package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface ManageInventoryService {

	/* all system operations of the use case*/
	List<Inventory> viewInventoryStockLevel() throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean recordRestock(String productName, String productID, int quantity) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean sendToSupplier(String supplierID, String productID, String supplierOrderID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean orderStockProducts(String productID, int quantity, String restockProductsID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean creatingNewSupplier(String supplierID, String companyName, String contactDetails) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	Supplier getExistingSupplier();
	void setExistingSupplier(Supplier existingsupplier);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
