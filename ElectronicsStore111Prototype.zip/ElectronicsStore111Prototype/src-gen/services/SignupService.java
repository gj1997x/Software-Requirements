package services;

import entities.*;  
import java.util.List;
import java.time.LocalDate;


public interface SignupService {

	/* all system operations of the use case*/
	boolean customerRegUsername(String username) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean customerRegPassword(String password) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean customerDetails(String email, String phonenumber, String address, String fullName, String userID) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	boolean saveDetails(String usename, String password, String email, String phonenumber, String address, String customerID, String fullName) throws PreconditionException, PostconditionException, ThirdPartyServiceException;
	
	/* all get and set functions for temp property*/
	String getUserName();
	void setUserName(String username);
	String getPassword();
	void setPassword(String password);
	String getFullName();
	void setFullName(String fullname);
	String getAddress();
	void setAddress(String address);
	int getPhoneNumber();
	void setPhoneNumber(int phonenumber);
	String getEmail();
	void setEmail(String email);
	
	/* all get and set functions for temp property*/
	
	/* invariant checking function */
}
